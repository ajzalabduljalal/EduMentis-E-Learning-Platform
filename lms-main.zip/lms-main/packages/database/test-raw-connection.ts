#!/usr/bin/env tsx

// Test raw pg connection
import "dotenv/config";
import pg from "pg";

const { Pool } = pg;

async function testRawConnection() {
  const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    connectionTimeoutMillis: 10000,
  });

  try {
    console.log("Testing raw PostgreSQL connection...");
    console.log(
      "Connection string:",
      process.env.DATABASE_URL?.replace(/:[^:@]+@/, ":****@"),
    );

    const client = await pool.connect();
    console.log("✓ Connected successfully!");

    const result = await client.query("SELECT version()");
    console.log("✓ Query successful!");
    console.log(
      "PostgreSQL version:",
      result.rows[0]?.version?.substring(0, 50) + "...",
    );

    client.release();
    await pool.end();

    console.log("\n✅ Raw connection test PASSED!");
    process.exit(0);
  } catch (error) {
    console.error("\n❌ Raw connection test FAILED!");
    console.error("Error:", error);
    await pool.end();
    process.exit(1);
  }
}

testRawConnection();
