import { PrismaClient } from "../generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

// Ensure DATABASE_URL is defined at runtime
if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL is not set. Please define it in your environment or .env file.",
  );
}

// Create a PostgreSQL connection pool with timeout settings for PgBouncer
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10, // Maximum pool size
  idleTimeoutMillis: 30000, // Close idle clients after 30s
  connectionTimeoutMillis: 10000, // Timeout after 10s if unable to connect
});

// Create the Prisma Pg adapter
const adapter = new PrismaPg(pool);

// In Next.js / serverless environments we want to avoid creating
// a new PrismaClient on every request in development.
// We attach it to the global object so hot reloads reuse the same instance.
const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    adapter,
    // Only show query logs when explicitly enabled via PRISMA_LOG_QUERIES=true
    log:
      process.env.PRISMA_LOG_QUERIES === "true"
        ? ["query", "error", "warn"]
        : process.env.NODE_ENV === "development"
          ? ["error", "warn"]
          : ["error"],
  });

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.prisma = prisma;
}
