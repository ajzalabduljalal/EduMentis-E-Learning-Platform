#!/usr/bin/env node

// Test Prisma connection
import { prisma } from "./src/client.js";

async function testConnection() {
  try {
    console.log("Testing database connection...");
    console.log(
      "DATABASE_URL:",
      process.env.DATABASE_URL ? "✓ Set" : "✗ Not set",
    );

    // Test raw query
    const result = await prisma.$queryRaw`SELECT 1 as test`;
    console.log("✓ Raw query successful:", result);

    // Test finding users
    const userCount = await prisma.user.count();
    console.log(`✓ User count: ${userCount}`);

    // Test finding a specific user by clerkId (if exists)
    const users = await prisma.user.findMany({ take: 1 });
    if (users.length > 0) {
      console.log("✓ Sample user found:", users[0].email);
    } else {
      console.log("✓ No users in database yet (this is ok)");
    }

    console.log("\n✅ Database connection test PASSED!");
    process.exit(0);
  } catch (error) {
    console.error("\n❌ Database connection test FAILED!");
    console.error("Error:", error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

testConnection();
