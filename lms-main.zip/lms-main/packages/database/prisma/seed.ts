import "dotenv/config";
import { PrismaClient as BasePrismaClient } from "../generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import {
  Track,
  CourseLevel,
  CourseStatus,
  QuizType,
  QuestionType,
  LessonType,
} from "../generated/prisma/client";

const adapter = new PrismaPg({
  connectionString: process.env.DATABASE_URL!,
});

const prisma = new BasePrismaClient({ adapter });

async function main() {
  console.log("Starting seed...");

  let instructor1 = await prisma.user.findUnique({
    where: { email: "sangeeth999123@gmail.com" },
  });

  let instructor2 = await prisma.user.findUnique({
    where: { email: "mohammedshebinc92@gmail.com" },
  });

  // Create instructors if they don't exist
  if (!instructor1) {
    instructor1 = await prisma.user.create({
      data: {
        clerkId: "instructor1_clerk_" + Date.now(),
        email: "sangeeth999123@gmail.com",
        name: "Sangeeth",
        role: "INSTRUCTOR",
      },
    });
    console.log(`Created instructor 1: ${instructor1.email}`);
  } else {
    console.log(`Found instructor 1: ${instructor1.email}`);
  }

  if (!instructor2) {
    instructor2 = await prisma.user.create({
      data: {
        clerkId: "instructor2_clerk_" + Date.now(),
        email: "mohammedshebinc92@gmail.com",
        name: "Mohammed",
        role: "INSTRUCTOR",
      },
    });
    console.log(`Created instructor 2: ${instructor2.email}`);
  } else {
    console.log(`Found instructor 2: ${instructor2.email}`);
  }

  // Course 1: DSA
  const dsaCourse = await prisma.course.create({
    data: {
      title: "Data Structures & Algorithms",
      slug: "dsa",
      shortDescription:
        "Master essential data structures and algorithms for coding interviews.",
      description:
        "Comprehensive course covering arrays, linked lists, trees, graphs, sorting, searching, and dynamic programming.",
      category: "Programming",
      level: CourseLevel.BEGINNER,
      price: 0,
      status: CourseStatus.PUBLISHED,
      duration: 1800,
      instructorId: instructor1.id,
    },
  });

  // DSA Modules
  const dsaModules = await Promise.all([
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Arrays and Strings",
        track: Track.BOTH,
        orderIndex: 0,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Linked Lists",
        track: Track.BOTH,
        orderIndex: 1,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Stacks and Queues",
        track: Track.BOTH,
        orderIndex: 2,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Trees and Binary Search Trees",
        track: Track.BOTH,
        orderIndex: 3,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Graphs",
        track: Track.ADVANCED,
        orderIndex: 4,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Dynamic Programming",
        track: Track.ADVANCED,
        orderIndex: 5,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dsaCourse.id,
        title: "Sorting and Searching",
        track: Track.BOTH,
        orderIndex: 6,
      },
    }),
  ]);

  // DSA Module 1 Lessons
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[0].id,
        title: "Introduction to Arrays",
        content: `<h2>Introduction to Arrays</h2>
<p>An array is a fundamental data structure that stores a collection of elements of the same type in contiguous memory locations.</p>
<h3>Key Characteristics</h3>
<ul>
<li><strong>Fixed Size:</strong> Arrays have a predetermined size</li>
<li><strong>Zero-Indexing:</strong> First element is at index 0</li>
<li><strong>Contiguous Memory:</strong> Elements stored in consecutive locations</li>
</ul>
<h3>Time Complexity</h3>
<ul>
<li><strong>Access:</strong> O(1)</li>
<li><strong>Search:</strong> O(n)</li>
<li><strong>Insertion:</strong> O(n)</li>
<li><strong>Deletion:</strong> O(n)</li>
</ul>
<pre><code>const numbers = [1, 2, 3, 4, 5];
console.log(numbers[0]); // Output: 1</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
        isFree: true,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[0].id,
        title: "Array Operations",
        content: `<h2>Array Operations</h2><p>Common operations include searching, sorting, and manipulation techniques like Two Pointers and Sliding Window.</p><h3>Two Pointer Technique</h3><pre><code>function twoSum(arr, target) {\n  let left = 0, right = arr.length - 1;\n  while (left < right) {\n    const sum = arr[left] + arr[right];\n    if (sum === target) return [left, right];\n    else if (sum < target) left++;\n    else right--;\n  }\n  return [-1, -1];\n}</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[0].id,
        title: "String Manipulation",
        content: `<h2>String Manipulation</h2><p>Strings are character arrays. Common operations include reversing, palindrome checking, and anagram detection.</p><h3>Palindrome Check</h3><pre><code>function isPalindrome(str) {\n  const cleaned = str.toLowerCase().replace(/[^a-z0-9]/g, '');\n  return cleaned === cleaned.split('').reverse().join('');\n}</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 2,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[0].id,
        title: "Practice Problems",
        content: `<h2>Practice: Arrays</h2><h3>Problem 1: Find Maximum</h3><p>Write a function to find the maximum element in an array.</p><h3>Problem 2: Remove Duplicates</h3><p>Given a sorted array, remove duplicates in-place.</p><h3>Problem 3: Rotate Array</h3><p>Rotate an array to the right by k steps.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.CODING,
        duration: 30,
        orderIndex: 3,
      },
    }),
  ]);

  // DSA Module 2 Lessons
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[1].id,
        title: "Introduction to Linked Lists",
        content: `<h2>Linked Lists</h2><p>A linked list is a linear data structure where elements are stored in nodes, each pointing to the next.</p><h3>Types</h3><ul><li>Singly Linked List</li><li>Doubly Linked List</li><li>Circular Linked List</li></ul><h3>Time Complexity</h3><ul><li>Access: O(n)</li><li>Insert at Head: O(1)</li><li>Delete: O(n) to find, O(1) to delete</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[1].id,
        title: "Linked List Operations",
        content: `<h2>Linked List Operations</h2><h3>Insert at Beginning</h3><pre><code>function insertAtHead(head, val) {\n  const newNode = new ListNode(val);\n  newNode.next = head;\n  return newNode;\n}</code></pre><h3>Reverse a Linked List</h3><pre><code>function reverseList(head) {\n  let prev = null, current = head;\n  while (current) {\n    const next = current.next;\n    current.next = prev;\n    prev = current;\n    current = next;\n  }\n  return prev;\n}</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[1].id,
        title: "Detecting Cycles",
        content: `<h2>Detecting Cycles</h2><p>Use Floyd's Tortoise and Hare algorithm to detect cycles in a linked list.</p><pre><code>function hasCycle(head) {\n  let slow = head, fast = head;\n  while (fast && fast.next) {\n    slow = slow.next;\n    fast = fast.next.next;\n    if (slow === fast) return true;\n  }\n  return false;\n}</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 2,
      },
    }),
  ]);

  // DSA Module 3 Lessons (Stacks and Queues)
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[2].id,
        title: "Introduction to Stacks",
        content: `<h2>Stacks</h2><p>A stack is LIFO (Last-In-First-Out). Operations: push, pop, peek.</p><h3>Implementation</h3><pre><code>class Stack {\n  constructor() { this.items = []; }\n  push(item) { this.items.push(item); }\n  pop() { return this.items.pop(); }\n  peek() { return this.items[this.items.length - 1]; }\n}</code></pre><h3>Applications</h3><ul><li>Function call stack</li><li>Undo/Redo</li><li>Expression evaluation</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 15,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[2].id,
        title: "Introduction to Queues",
        content: `<h2>Queues</h2><p>A queue is FIFO (First-In-First-Out). Operations: enqueue, dequeue.</p><h3>Implementation</h3><pre><code>class Queue {\n  constructor() { this.items = []; }\n  enqueue(item) { this.items.push(item); }\n  dequeue() { return this.items.shift(); }\n}</code></pre><h3>Applications</h3><ul><li>Task scheduling</li><li>BFS</li><li>Print spooling</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 15,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[2].id,
        title: "Stack and Queue Applications",
        content: `<h2>Applications</h2><h3>Valid Parentheses</h3><pre><code>function isValid(s) {\n  const stack = [];\n  const pairs = { ')': '(', '}': '{', ']': '[' };\n  for (const char of s) {\n    if (char in pairs) {\n      if (stack.pop() !== pairs[char]) return false;\n    } else { stack.push(char); }\n  }\n  return stack.length === 0;\n}</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 2,
      },
    }),
  ]);

  // DSA Module 4 (Trees)
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[3].id,
        title: "Introduction to Trees",
        content: `<h2>Trees</h2><p>A hierarchical data structure with nodes connected by edges.</p><h3>Binary Tree Traversals</h3><pre><code>// Inorder: Left -> Root -> Right\n// Preorder: Root -> Left -> Right\n// Postorder: Left -> Right -> Root\n// Level Order: BFS</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[3].id,
        title: "Binary Search Trees",
        content: `<h2>BST</h2><p>Left subtree < root < right subtree.</p><h3>Search in BST</h3><pre><code>function searchBST(root, val) {\n  if (!root || root.val === val) return root;\n  return searchBST(val < root.val ? root.left : root.right, val);\n}</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
  ]);

  // DSA Module 5 (Graphs - Advanced)
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[4].id,
        title: "Introduction to Graphs",
        content: `<h2>Graphs</h2><p>Vertices (nodes) connected by edges.</p><h3>Types</h3><ul><li>Directed vs Undirected</li><li>Weighted vs Unweighted</li><li>Cyclic vs Acyclic</li></ul><h3>Representations</h3><ul><li>Adjacency Matrix: O(V²) space</li><li>Adjacency List: O(V + E) space</li></ul>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[4].id,
        title: "Graph Traversal",
        content: `<h2>Traversal</h2><h3>DFS (Stack/Recursion)</h3><pre><code>function dfs(graph, start, visited = new Set()) {\n  visited.add(start);\n  for (const neighbor of graph[start]) {\n    if (!visited.has(neighbor)) dfs(graph, neighbor, visited);\n  }\n}</code></pre><h3>BFS (Queue)</h3><pre><code>function bfs(graph, start) {\n  const visited = new Set([start]), queue = [start];\n  while (queue.length) {\n    const vertex = queue.shift();\n    for (const neighbor of graph[vertex]) {\n      if (!visited.has(neighbor)) { visited.add(neighbor); queue.push(neighbor); }\n    }\n  }\n}</code></pre>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[4].id,
        title: "Shortest Path",
        content: `<h2>Shortest Path Algorithms</h2><h3>Dijkstra's Algorithm</h3><p>Finds shortest path from single source. O((V+E) log V) with priority queue.</p><h3>BFS for Unweighted</h3><p>Use BFS to find shortest path in unweighted graphs.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 2,
      },
    }),
  ]);

  // DSA Module 6 (Dynamic Programming - Advanced)
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[5].id,
        title: "Introduction to DP",
        content: `<h2>Dynamic Programming</h2><p>Optimization technique using overlapping subproblems and optimal substructure.</p><h3>Approaches</h3><ul><li>Top-Down (Memoization)</li><li>Bottom-Up (Tabulation)</li></ul><pre><code>// Fibonacci with memoization\nfunction fib(n, memo = {}) {\n  if (n in memo) return memo[n];\n  if (n <= 1) return n;\n  return memo[n] = fib(n-1, memo) + fib(n-2, memo);\n}</code></pre>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[5].id,
        title: "Common DP Patterns",
        content: `<h2>DP Patterns</h2><h3>Climbing Stairs</h3><pre><code>function climbStairs(n) {\n  if (n <= 2) return n;\n  const dp = [0, 1, 2];\n  for (let i = 3; i <= n; i++) dp[i] = dp[i-1] + dp[i-2];\n  return dp[n];\n}</code></pre><h3>Knapsack, LCS, Edit Distance</h3><p>Classic 2D DP problems.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 30,
        orderIndex: 1,
      },
    }),
  ]);

  // DSA Module 7 (Sorting and Searching)
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[6].id,
        title: "Sorting Algorithms",
        content: `<h2>Sorting</h2><h3>Bubble Sort: O(n²)</h3><h3>Merge Sort: O(n log n)</h3><pre><code>function mergeSort(arr) {\n  if (arr.length <= 1) return arr;\n  const mid = Math.floor(arr.length/2);\n  return merge(mergeSort(arr.slice(0,mid)), mergeSort(arr.slice(mid)));\n}</code></pre><h3>Quick Sort: O(n log n) avg</h3>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dsaModules[6].id,
        title: "Binary Search",
        content: `<h2>Binary Search</h2><p>O(log n) search in sorted arrays.</p><pre><code>function binarySearch(arr, target) {\n  let left = 0, right = arr.length - 1;\n  while (left <= right) {\n    const mid = Math.floor((left + right) / 2);\n    if (arr[mid] === target) return mid;\n    else if (arr[mid] < target) left = mid + 1;\n    else right = mid - 1;\n  }\n  return -1;\n}</code></pre><h3>Variations</h3><ul><li>First occurrence</li><li>Rotated array</li><li>Insert position</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
  ]);

  // DSA Quizzes
  const dsaEntryQuiz = await prisma.quiz.create({
    data: {
      courseId: dsaCourse.id,
      title: "Data Structures & Algorithms - Entry Assessment",
      description: "This quiz will determine your track placement.",
      quizType: QuizType.ENTRY_QUIZ,
      passingScore: 70,
      maxAttempts: 1,
    },
  });

  await prisma.question.createMany({
    data: [
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question:
          "What is the time complexity of accessing an element in an array by index?",
        options: { A: "O(1)", B: "O(n)", C: "O(log n)", D: "O(n²)" },
        correctAnswer: "A",
        explanation: "Arrays provide O(1) access via index.",
        orderIndex: 0,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which data structure follows LIFO?",
        options: { A: "Queue", B: "Stack", C: "Array", D: "Linked List" },
        correctAnswer: "B",
        explanation: "Stack is Last-In-First-Out.",
        orderIndex: 1,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is the worst-case time complexity of QuickSort?",
        options: { A: "O(n)", B: "O(n log n)", C: "O(n²)", D: "O(log n)" },
        correctAnswer: "C",
        explanation: "QuickSort is O(n²) worst case.",
        orderIndex: 2,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question:
          "Time complexity of inserting at the beginning of a linked list?",
        options: { A: "O(1)", B: "O(n)", C: "O(log n)", D: "O(n²)" },
        correctAnswer: "A",
        explanation: "O(1) - just update head pointer.",
        orderIndex: 3,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a binary tree?",
        options: {
          A: "Exactly 2 children per node",
          B: "At most 2 children per node",
          C: "Only 2 nodes",
          D: "Stored in array",
        },
        correctAnswer: "B",
        explanation: "Binary tree: each node has at most 2 children.",
        orderIndex: 4,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which sorting algorithm is stable?",
        options: {
          A: "QuickSort",
          B: "HeapSort",
          C: "MergeSort",
          D: "SelectionSort",
        },
        correctAnswer: "C",
        explanation: "MergeSort maintains relative order.",
        orderIndex: 5,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Space complexity of MergeSort?",
        options: { A: "O(1)", B: "O(log n)", C: "O(n)", D: "O(n log n)" },
        correctAnswer: "C",
        explanation: "MergeSort needs O(n) extra space.",
        orderIndex: 6,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How to detect a cycle in linked list?",
        options: {
          A: "Hash set",
          B: "Floyd's algorithm",
          C: "Count nodes",
          D: "Reverse list",
        },
        correctAnswer: "B",
        explanation: "Floyd uses two pointers at different speeds.",
        orderIndex: 7,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a hash table?",
        options: {
          A: "Tree structure",
          B: "Maps keys to values using hash function",
          C: "Sorting algorithm",
          D: "Type of array",
        },
        correctAnswer: "B",
        explanation: "Hash tables use hash functions for O(1) access.",
        orderIndex: 8,
        points: 1,
      },
      {
        quizId: dsaEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Height of balanced BST with n nodes?",
        options: { A: "n", B: "n-1", C: "log n", D: "n²" },
        correctAnswer: "C",
        explanation: "Balanced BST has O(log n) height.",
        orderIndex: 9,
        points: 1,
      },
    ],
  });

  const dsaFinalExam = await prisma.quiz.create({
    data: {
      courseId: dsaCourse.id,
      title: "Data Structures & Algorithms - Final Assessment",
      description: "Complete this exam to earn your certificate.",
      quizType: QuizType.FINAL_EXAM,
      passingScore: 70,
      maxAttempts: 3,
    },
  });

  await prisma.question.createMany({
    data: [
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Average case search in hash table?",
        options: { A: "O(1)", B: "O(n)", C: "O(log n)", D: "O(n log n)" },
        correctAnswer: "A",
        explanation: "Hash tables provide O(1) average access.",
        orderIndex: 0,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Best data structure for priority queue?",
        options: { A: "Array", B: "Linked List", C: "Heap", D: "Stack" },
        correctAnswer: "C",
        explanation: "Heap provides O(log n) enqueue/dequeue.",
        orderIndex: 1,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Max nodes in binary tree of height h?",
        options: { A: "h", B: "2h", C: "2^h - 1", D: "h²" },
        correctAnswer: "C",
        explanation: "Complete tree has 2^h - 1 nodes.",
        orderIndex: 2,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which traversal is Root-Left-Right?",
        options: {
          A: "Inorder",
          B: "Preorder",
          C: "Postorder",
          D: "Level order",
        },
        correctAnswer: "B",
        explanation: "Preorder is Root → Left → Right.",
        orderIndex: 3,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Space complexity of recursive DFS?",
        options: { A: "O(1)", B: "O(V)", C: "O(V+E)", D: "O(h)" },
        correctAnswer: "D",
        explanation: "DFS uses call stack: O(height).",
        orderIndex: 4,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which algorithm uses DP for all-pairs shortest path?",
        options: {
          A: "Dijkstra",
          B: "Bellman-Ford",
          C: "Floyd-Warshall",
          D: "BFS",
        },
        correctAnswer: "C",
        explanation: "Floyd-Warshall uses DP approach.",
        orderIndex: 5,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "BST insert average case?",
        options: { A: "O(1)", B: "O(log n)", C: "O(n)", D: "O(n log n)" },
        correctAnswer: "B",
        explanation: "Balanced BST: O(log n).",
        orderIndex: 6,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which sorting is in-place?",
        options: {
          A: "MergeSort",
          B: "QuickSort",
          C: "CountingSort",
          D: "RadixSort",
        },
        correctAnswer: "B",
        explanation: "QuickSort is in-place.",
        orderIndex: 7,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is topological sort?",
        options: {
          A: "Sort numbers",
          B: "Order DAG vertices",
          C: "Shortest path",
          D: "Sort heap",
        },
        correctAnswer: "B",
        explanation: "Toposort orders DAG for edges to point forward.",
        orderIndex: 8,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is memoization?",
        options: {
          A: "Delete memory",
          B: "Cache function results",
          C: "Sort algorithm",
          D: "Tree traversal",
        },
        correctAnswer: "B",
        explanation: "Memoization caches expensive call results.",
        orderIndex: 9,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which data structure does BFS use?",
        options: { A: "Stack", B: "Queue", C: "Heap", D: "Tree" },
        correctAnswer: "B",
        explanation: "BFS uses queue for level-order.",
        orderIndex: 10,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Time complexity of HeapSort?",
        options: { A: "O(n)", B: "O(n log n)", C: "O(n²)", D: "O(log n)" },
        correctAnswer: "B",
        explanation: "HeapSort always O(n log n).",
        orderIndex: 11,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a spanning tree?",
        options: {
          A: "Has cycles",
          B: "Connects all vertices with minimum edges",
          C: "Binary tree",
          D: "Decision tree",
        },
        correctAnswer: "B",
        explanation: "Spanning tree connects all vertices, no cycles.",
        orderIndex: 12,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Graph vs Tree difference?",
        options: {
          A: "No difference",
          B: "Graphs can have cycles",
          C: "Trees have more nodes",
          D: "Graphs always connected",
        },
        correctAnswer: "B",
        explanation: "Trees are acyclic graphs.",
        orderIndex: 13,
        points: 1,
      },
      {
        quizId: dsaFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Fibonacci DP is called?",
        options: {
          A: "Tabulation only",
          B: "Memoization only",
          C: "Both",
          D: "Neither",
        },
        correctAnswer: "C",
        explanation: "Fibonacci can use both approaches.",
        orderIndex: 14,
        points: 1,
      },
    ],
  });

  await prisma.course.update({
    where: { id: dsaCourse.id },
    data: { entryQuizId: dsaEntryQuiz.id, finalExamId: dsaFinalExam.id },
  });
  console.log("Created DSA course");

  // Course 2: Operating Systems Lab
  const osCourse = await prisma.course.create({
    data: {
      title: "Operating Systems Lab",
      slug: "operating-systems-lab",
      shortDescription: "Hands-on lab exercises for understanding OS concepts.",
      description:
        "Practical lab sessions covering process scheduling, deadlock handling, memory allocation, and file systems.",
      category: "Computer Science",
      level: CourseLevel.INTERMEDIATE,
      price: 0,
      status: CourseStatus.PUBLISHED,
      duration: 1200,
      instructorId: instructor1.id,
    },
  });

  const osModules = await Promise.all([
    prisma.module.create({
      data: {
        courseId: osCourse.id,
        title: "Process Management",
        track: Track.BOTH,
        orderIndex: 0,
      },
    }),
    prisma.module.create({
      data: {
        courseId: osCourse.id,
        title: "CPU Scheduling",
        track: Track.BOTH,
        orderIndex: 1,
      },
    }),
    prisma.module.create({
      data: {
        courseId: osCourse.id,
        title: "Synchronization",
        track: Track.ADVANCED,
        orderIndex: 2,
      },
    }),
    prisma.module.create({
      data: {
        courseId: osCourse.id,
        title: "Deadlock Handling",
        track: Track.ADVANCED,
        orderIndex: 3,
      },
    }),
    prisma.module.create({
      data: {
        courseId: osCourse.id,
        title: "Memory Management",
        track: Track.BOTH,
        orderIndex: 4,
      },
    }),
    prisma.module.create({
      data: {
        courseId: osCourse.id,
        title: "File Systems",
        track: Track.BOTH,
        orderIndex: 5,
      },
    }),
  ]);

  // OS Lessons
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: osModules[0].id,
        title: "Introduction to Processes",
        content: `<h2>Processes</h2><p>A process is an instance of a program in execution.</p><h3>Process Components</h3><ul><li>Program Code</li><li>Stack (function calls)</li><li>Heap (dynamic memory)</li><li>PCB (Process Control Block)</li></ul><h3>Process States</h3><ul><li>New → Ready → Running → Waiting → Terminated</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
        isFree: true,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[0].id,
        title: "Process Creation",
        content: `<h2>Process Creation</h2><p>fork() creates new process in Unix/Linux.</p><pre><code>#include &lt;unistd.h&gt;\npid_t pid = fork();\nif (pid == 0) { /* child */ }\nelse { /* parent */ }</code></pre><h3>Process Termination</h3><p>exit() terminates process.</p><h3>Zombie & Orphan</h3><p>Zombie: terminated but parent not called wait(). Orphan: parent terminated first.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[0].id,
        title: "IPC",
        content: `<h2>Inter-Process Communication</h2><h3>Pipes</h3><pre><code>int pipefd[2];\npipe(pipefd);\n// Parent writes, child reads</code></pre><h3>Types</h3><ul><li>Pipes: Simple communication</li><li>Message Queues: Message boundaries</li><li>Shared Memory: Fastest</li><li>Sockets: Network</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 2,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[1].id,
        title: "CPU Scheduling Basics",
        content: `<h2>CPU Scheduling</h2><h3>Types</h3><ul><li>Long-term: Job selection</li><li>Short-term: CPU allocation</li><li>Medium-term: Swapping</li></ul><h3>Criteria</h3><ul><li>CPU Utilization</li><li>Throughput</li><li>Turnaround Time</li><li>Waiting Time</li><li>Response Time</li></ul><h3>Preemptive vs Non-Preemptive</h3><p>Preemptive: OS can interrupt running process.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[1].id,
        title: "Scheduling Algorithms",
        content: `<h2>Algorithms</h2><h3>FCFS: First-Come-First-Served</h3><h3>SJF: Shortest Job First</h3><h3>Priority Scheduling</h3><h3>Round Robin</h3><pre><code>// RR with quantum=4\n// P1(4) → P2(4) → P3(4) → P1(4) → ...</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[2].id,
        title: "Synchronization",
        content: `<h2>Synchronization</h2><h3>Critical Section</h3><p>Code accessing shared resources must be mutual exclusive.</p><h3>Requirements</h3><ul><li>Mutual Exclusion</li><li>Progress</li><li>Bounded Waiting</li></ul><h3>Solutions</h3><ul><li>Peterson's Algorithm</li><li>Test-and-Set</li><li>Compare-and-Swap</li></ul>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[2].id,
        title: "Semaphores",
        content: `<h2>Semaphores</h2><pre><code>wait(S) { S--; if (S<0) block(); }\nsignal(S) { S++; if (S<=0) wakeup(); }</code></pre><h3>Binary Semaphore (Mutex)</h3><pre><code>sem_wait(&mutex);\n// critical section\nsem_post(&mutex);</code></pre><h3>Dining Philosophers</h3><p>Classic synchronization problem.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[3].id,
        title: "Deadlock Concepts",
        content: `<h2>Deadlock</h2><h3>Necessary Conditions</h3><ol><li>Mutual Exclusion</li><li>Hold and Wait</li><li>No Preemption</li><li>Circular Wait</li></ol><h3>Resource Allocation Graph</h3><p>Cycle with single-instance resources = deadlock.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[3].id,
        title: "Deadlock Handling",
        content: `<h2>Handling</h2><h3>Prevention</h3><ul><li>Eliminate Hold and Wait</li><li>Define resource ordering</li></ul><h3>Avoidance</h3><p>Banker's Algorithm - check safe state before allocation.</p><h3>Detection & Recovery</h3><p>Periodically check for deadlock, then abort process.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[4].id,
        title: "Memory Management",
        content: `<h2>Memory Management</h2><h3>Allocation Methods</h3><ul><li>Fixed Partitioning</li><li>Dynamic Partitioning</li><li>Paging</li><li>Segmentation</li></ul><h3>Fragmentation</h3><ul><li>External: Non-contiguous free space</li><li>Internal: Allocated > needed</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[4].id,
        title: "Paging and Virtual Memory",
        content: `<h2>Paging</h2><p>Fixed-size pages mapped to frames.</p><h3>Address Translation</h3><pre><code>Logical: [Page Number][Offset]\nPhysical: [Frame Number][Offset]</code></pre><h3>Page Replacement</h3><ul><li>FIFO</li><li>LRU</li><li>Optimal</li></ul><h3>Thrashing</h3><p>Excessive page faults.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: osModules[5].id,
        title: "File Systems",
        content: `<h2>File Systems</h2><h3>File Operations</h3><ul><li>Create, Open, Read, Write, Close, Delete</li></ul><h3>Access Methods</h3><ul><li>Sequential</li><li>Direct/Random</li><li>Indexed</li></ul><h3>Allocation</h3><ul><li>Contiguous</li><li>Linked</li><li>Indexed</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
  ]);

  // OS Quizzes
  const osEntryQuiz = await prisma.quiz.create({
    data: {
      courseId: osCourse.id,
      title: "OS Lab - Entry Assessment",
      description: "This quiz will determine your track placement.",
      quizType: QuizType.ENTRY_QUIZ,
      passingScore: 70,
      maxAttempts: 1,
    },
  });
  await prisma.question.createMany({
    data: [
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a process?",
        options: {
          A: "Program on disk",
          B: "Program in execution",
          C: "CPU",
          D: "Memory",
        },
        correctAnswer: "B",
        explanation: "Process is program in execution.",
        orderIndex: 0,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which algorithm gives priority to shortest jobs?",
        options: { A: "FCFS", B: "SJF", C: "Round Robin", D: "Priority" },
        correctAnswer: "B",
        explanation: "SJF selects shortest burst time.",
        orderIndex: 1,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is deadlock?",
        options: {
          A: "Crash",
          B: "Processes waiting for each other",
          C: "CPU overload",
          D: "Memory overflow",
        },
        correctAnswer: "B",
        explanation: "Deadlock is circular waiting.",
        orderIndex: 2,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Semaphore purpose?",
        options: {
          A: "Memory allocation",
          B: "Synchronization",
          C: "File management",
          D: "Network",
        },
        correctAnswer: "B",
        explanation: "Semaphores provide synchronization.",
        orderIndex: 3,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is paging?",
        options: {
          A: "Delete pages",
          B: "Fixed-size pages",
          C: "Compress memory",
          D: "Contiguous allocation",
        },
        correctAnswer: "B",
        explanation: "Paging uses fixed-size pages.",
        orderIndex: 4,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is page fault?",
        options: {
          A: "Virus",
          B: "Page not in memory",
          C: "Disk error",
          D: "CPU error",
        },
        correctAnswer: "B",
        explanation: "Page fault when page not in memory.",
        orderIndex: 5,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "NOT a deadlock condition?",
        options: {
          A: "Mutual Exclusion",
          B: "Hold and Wait",
          C: "Preemption",
          D: "Circular Wait",
        },
        correctAnswer: "C",
        explanation: "Preemption is NOT a condition.",
        orderIndex: 6,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is thrashing?",
        options: {
          A: "CPU overheating",
          B: "Excessive page faults",
          C: "Process termination",
          D: "Memory leak",
        },
        correctAnswer: "B",
        explanation: "Thrashing is excessive swapping.",
        orderIndex: 7,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is context switch?",
        options: {
          A: "Change user",
          B: "Save/load process state",
          C: "Switch apps",
          D: "Change CPU freq",
        },
        correctAnswer: "B",
        explanation: "Context switch saves process state.",
        orderIndex: 8,
      },
      {
        quizId: osEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Virtual memory?",
        options: {
          A: "RAM only",
          B: "Disk as extra memory",
          C: "Cache",
          D: "Registers",
        },
        correctAnswer: "B",
        explanation: "Virtual memory uses disk.",
        orderIndex: 9,
      },
    ],
  });

  const osFinalExam = await prisma.quiz.create({
    data: {
      courseId: osCourse.id,
      title: "OS Lab - Final Assessment",
      description: "Complete this exam to earn your certificate.",
      quizType: QuizType.FINAL_EXAM,
      passingScore: 70,
      maxAttempts: 3,
    },
  });
  await prisma.question.createMany({
    data: [
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Long-term scheduler?",
        options: {
          A: "Ready queue",
          B: "Job to memory",
          C: "CPU allocation",
          D: "I/O handling",
        },
        correctAnswer: "B",
        explanation: "Long-term selects jobs for memory.",
        orderIndex: 0,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Round Robin uses?",
        options: {
          A: "Priority queue",
          B: "FIFO queue",
          C: "Stack",
          D: "Linked list",
        },
        correctAnswer: "B",
        explanation: "RR uses FIFO queue.",
        orderIndex: 1,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Banker algorithm?",
        options: {
          A: "Memory",
          B: "Deadlock avoidance",
          C: "CPU scheduling",
          D: "File system",
        },
        correctAnswer: "B",
        explanation: "Banker avoids deadlock.",
        orderIndex: 2,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Page table contains?",
        options: {
          A: "Process info",
          B: "Frame numbers",
          C: "CPU registers",
          D: "Disk locations",
        },
        correctAnswer: "B",
        explanation: "Page table maps pages to frames.",
        orderIndex: 3,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Zombie process?",
        options: {
          A: "High CPU",
          B: "Terminated, not waited",
          C: "Infinite loop",
          D: "Orphan",
        },
        correctAnswer: "B",
        explanation: "Zombie: terminated, parent not waited.",
        orderIndex: 4,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "TLB purpose?",
        options: {
          A: "Store files",
          B: "Cache page table",
          C: "Manage memory",
          D: "Handle interrupts",
        },
        correctAnswer: "B",
        explanation: "TLB caches page table entries.",
        orderIndex: 5,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "External fragmentation?",
        options: {
          A: "Paging",
          B: "Contiguous allocation",
          C: "Linked",
          D: "Indexed",
        },
        correctAnswer: "B",
        explanation: "Contiguous causes external fragmentation.",
        orderIndex: 6,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Critical section?",
        options: {
          A: "Kernel code",
          B: "Shared resource code",
          C: "Interrupt handler",
          D: "Main function",
        },
        correctAnswer: "B",
        explanation: "Critical section accesses shared resources.",
        orderIndex: 7,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "FIFO page replacement?",
        options: {
          A: "Optimal",
          B: "Simple but not optimal",
          C: "Complex",
          D: "Random",
        },
        correctAnswer: "B",
        explanation: "FIFO is simple but not optimal.",
        orderIndex: 8,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is inode?",
        options: {
          A: "I/O number",
          B: "File system structure",
          C: "Process ID",
          D: "Memory address",
        },
        correctAnswer: "B",
        explanation: "Inode stores file metadata.",
        orderIndex: 9,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Monitor in OS?",
        options: {
          A: "Display",
          B: "Synchronization construct",
          C: "Memory unit",
          D: "CPU component",
        },
        correctAnswer: "B",
        explanation: "Monitor is synchronization construct.",
        orderIndex: 10,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Mutual exclusion primitive?",
        options: { A: "Semaphore", B: "Thread", C: "Process", D: "Signal" },
        correctAnswer: "A",
        explanation: "Binary semaphore is mutex.",
        orderIndex: 11,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Segmentation?",
        options: {
          A: "Paging",
          B: "Variable-size segments",
          C: "Disk storage",
          D: "CPU mode",
        },
        correctAnswer: "B",
        explanation: "Segmentation uses variable-size segments.",
        orderIndex: 12,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Race condition?",
        options: {
          A: "Competition",
          B: "Incorrect timing",
          C: "Crash",
          D: "Memory error",
        },
        correctAnswer: "B",
        explanation: "Race condition is timing issue.",
        orderIndex: 13,
      },
      {
        quizId: osFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "exit() purpose?",
        options: {
          A: "Start process",
          B: "Terminate process",
          C: "Wait for process",
          D: "Create process",
        },
        correctAnswer: "B",
        explanation: "exit() terminates process.",
        orderIndex: 14,
      },
    ],
  });

  await prisma.course.update({
    where: { id: osCourse.id },
    data: { entryQuizId: osEntryQuiz.id, finalExamId: osFinalExam.id },
  });
  console.log("Created OS Lab course");

  // Course 3: DBMS
  const dbmsCourse = await prisma.course.create({
    data: {
      title: "Database Management Systems",
      slug: "dbms",
      shortDescription:
        "Learn SQL, database design, normalization, transactions, and query optimization.",
      description:
        "Complete DBMS course covering SQL, ER modeling, normalization, indexes, transactions, and optimization.",
      category: "Database",
      level: CourseLevel.BEGINNER,
      price: 0,
      status: CourseStatus.PUBLISHED,
      duration: 1500,
      instructorId: instructor2.id,
    },
  });

  const dbmsModules = await Promise.all([
    prisma.module.create({
      data: {
        courseId: dbmsCourse.id,
        title: "Introduction to Databases",
        track: Track.BOTH,
        orderIndex: 0,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dbmsCourse.id,
        title: "SQL Fundamentals",
        track: Track.BOTH,
        orderIndex: 1,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dbmsCourse.id,
        title: "ER Modeling and Design",
        track: Track.BOTH,
        orderIndex: 2,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dbmsCourse.id,
        title: "Normalization",
        track: Track.ADVANCED,
        orderIndex: 3,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dbmsCourse.id,
        title: "Indexes and Performance",
        track: Track.ADVANCED,
        orderIndex: 4,
      },
    }),
    prisma.module.create({
      data: {
        courseId: dbmsCourse.id,
        title: "Transactions and Concurrency",
        track: Track.ADVANCED,
        orderIndex: 5,
      },
    }),
  ]);

  // DBMS Lessons
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[0].id,
        title: "What is a Database?",
        content: `<h2>Database</h2><p>Organized collection of structured data.</p><h3>DBMS Features</h3><ul><li>Data Abstraction</li><li>Integrity</li><li>Concurrency Control</li><li>Security</li><li>Backup & Recovery</li></ul><h3>Types</h3><ul><li>Relational: MySQL, PostgreSQL</li><li>NoSQL: MongoDB, Redis</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
        isFree: true,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[0].id,
        title: "Data Models",
        content: `<h2>Data Models</h2><h3>Relational Model</h3><ul><li>Relation = Table</li><li>Tuple = Row</li><li>Attribute = Column</li><li>Primary Key = Unique ID</li><li>Foreign Key = Reference</li></ul><h3>Schema vs Instance</h3><p>Schema = structure, Instance = actual data.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[1].id,
        title: "Basic SQL Queries",
        content: `<h2>SQL Queries</h2><pre><code>SELECT * FROM employees;\nSELECT name, salary FROM employees WHERE dept = 'IT';\nSELECT * FROM employees ORDER BY salary DESC;\nSELECT * FROM employees LIMIT 10 OFFSET 5;</code></pre><h3>WHERE Clauses</h3><p>=, <>, <, >, LIKE, IN, BETWEEN</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[1].id,
        title: "SQL Joins",
        content: `<h2>Joins</h2><h3>INNER JOIN</h3><pre><code>SELECT e.name, d.name FROM employees e\nINNER JOIN departments d ON e.dept_id = d.id;</code></pre><h3>Types</h3><ul><li>INNER: Matching rows</li><li>LEFT: All left + matching right</li><li>RIGHT: All right + matching left</li><li>FULL: All rows</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[1].id,
        title: "Aggregate Functions",
        content: `<h2>Aggregates</h2><pre><code>SELECT COUNT(*) FROM employees;\nSELECT AVG(salary), SUM(salary) FROM employees;\nSELECT dept, COUNT(*) FROM employees GROUP BY dept\nHAVING COUNT(*) > 5;</code></pre><h3>Functions</h3><ul><li>COUNT, SUM, AVG</li><li>MIN, MAX</li></ul><h3>GROUP BY</h3><p>Groups rows for aggregate functions.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 2,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[2].id,
        title: "ER Model",
        content: `<h2>ER Model</h2><h3>Components</h3><ul><li>Entity: Object (Rectangle)</li><li>Attribute: Property (Ellipse)</li><li>Relationship: Connection (Diamond)</li></ul><h3>Cardinality</h3><ul><li>1:1 - One to One</li><li>1:N - One to Many</li><li>N:M - Many to Many</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[2].id,
        title: "ER to Relational Mapping",
        content: `<h2>Mapping</h2><h3>Rules</h3><ul><li>Strong Entity: Create table with PK</li><li>Weak Entity: Include FK to owner</li><li>1:N: Add FK to N-side</li><li>N:M: Create relationship table</li></ul><pre><code>Student(student_id, name)\nCourse(course_id, title)\nEnrollment(student_id, course_id)</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[3].id,
        title: "Normalization",
        content: `<h2>Normalization</h2><h3>Goals</h3><ul><li>Eliminate redundancy</li><li>Reduce anomalies</li></ul><h3>Normal Forms</h3><ol><li>1NF: Atomic values</li><li>2NF: No partial dependencies</li><li>3NF: No transitive dependencies</li><li>BCNF: Every determinant is candidate key</li></ol>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[3].id,
        title: "Normalization Examples",
        content: `<h2>Examples</h2><h3>1NF</h3><p>Remove lists from columns: Student(courses) → StudentCourse(student_id, course)</p><h3>2NF</h3><p>Remove partial dependencies from composite PK.</p><h3>3NF</h3><p>Remove transitive dependencies: student_id → dept → dept_head</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[4].id,
        title: "Indexes",
        content: `<h2>Indexes</h2><pre><code>CREATE INDEX idx_name ON employees(name);\nCREATE UNIQUE INDEX idx_email ON users(email);\nCREATE INDEX idx_dept_sal ON employees(dept, salary);</code></pre><h3>Types</h3><ul><li>B-Tree: Default, range queries</li><li>Hash: Exact match only</li><li>Full-Text: Text search</li></ul><h3>Trade-offs</h3><p>Faster reads, slower writes.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[4].id,
        title: "Query Optimization",
        content: `<h2>Optimization</h2><pre><code>EXPLAIN SELECT * FROM employees WHERE id = 5;</code></pre><h3>Tips</h3><ul><li>Use indexes on WHERE columns</li><li>Avoid SELECT *</li><li>Use EXISTS instead of IN</li><li>Limit result set size</li></ul><h3>EXPLAIN</h3><p>Analyze query execution plan.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[5].id,
        title: "Transactions",
        content: `<h2>Transactions</h2><p>ACID properties:</p><ul><li>Atomicity: All or nothing</li><li>Consistency: Valid state</li><li>Isolation: Concurrent appears sequential</li><li>Durability: Committed data persists</li></ul><pre><code>BEGIN;\nUPDATE accounts SET balance = balance - 100 WHERE id = 1;\nUPDATE accounts SET balance = balance + 100 WHERE id = 2;\nCOMMIT;</code></pre>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: dbmsModules[5].id,
        title: "Concurrency Control",
        content: `<h2>Concurrency</h2><h3>Problems</h3><ul><li>Lost Update</li><li>Dirty Read</li><li>Non-repeatable Read</li><li>Phantom Read</li></ul><h3>Solutions</h3><ul><li>Locks: Shared, Exclusive</li><li>Isolation Levels: READ UNCOMMITTED, READ COMMITTED, REPEATABLE READ, SERIALIZABLE</li></ul><h3>Deadlock</h3><p>Two transactions waiting for each other.</p>`,
        track: Track.ADVANCED,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
  ]);

  // DBMS Quizzes
  const dbmsEntryQuiz = await prisma.quiz.create({
    data: {
      courseId: dbmsCourse.id,
      title: "DBMS - Entry Assessment",
      description: "This quiz will determine your track placement.",
      quizType: QuizType.ENTRY_QUIZ,
      passingScore: 70,
      maxAttempts: 1,
    },
  });
  await prisma.question.createMany({
    data: [
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a database?",
        options: {
          A: "Collection of files",
          B: "Organized data in DBMS",
          C: "Programming language",
          D: "Operating system",
        },
        correctAnswer: "B",
        explanation: "Database is organized data managed by DBMS.",
        orderIndex: 0,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What does DBMS stand for?",
        options: {
          A: "Database Management System",
          B: "Data Backup Management System",
          C: "Digital Base Management System",
          D: "Database Memory System",
        },
        correctAnswer: "A",
        explanation: "DBMS = Database Management System.",
        orderIndex: 1,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which is a relational database?",
        options: { A: "MongoDB", B: "MySQL", C: "Redis", D: "Cassandra" },
        correctAnswer: "B",
        explanation: "MySQL is a relational database.",
        orderIndex: 2,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a primary key?",
        options: {
          A: "First column",
          B: "Unique identifier",
          C: "Foreign reference",
          D: "Index",
        },
        correctAnswer: "B",
        explanation: "Primary key uniquely identifies each row.",
        orderIndex: 3,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "SQL is?",
        options: {
          A: "Programming language",
          B: "Query language",
          C: "Markup language",
          D: "Scripting language",
        },
        correctAnswer: "B",
        explanation: "SQL is a query language for databases.",
        orderIndex: 4,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "SELECT statement is?",
        options: { A: "DDL", B: "DML", C: "DCL", D: "TCL" },
        correctAnswer: "B",
        explanation: "SELECT is DML (Data Manipulation Language).",
        orderIndex: 5,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "JOIN combines?",
        options: {
          A: "Columns",
          B: "Rows from tables",
          C: "Databases",
          D: "Indexes",
        },
        correctAnswer: "B",
        explanation: "JOIN combines rows from multiple tables.",
        orderIndex: 6,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is normalization?",
        options: {
          A: "Data type conversion",
          B: "Reduce redundancy",
          C: "Increase data",
          D: "Backup process",
        },
        correctAnswer: "B",
        explanation: "Normalization reduces data redundancy.",
        orderIndex: 7,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "1NF requires?",
        options: {
          A: "No duplicates",
          B: "Atomic values",
          C: "No nulls",
          D: "Primary key",
        },
        correctAnswer: "B",
        explanation: "1NF requires atomic (indivisible) values.",
        orderIndex: 8,
      },
      {
        quizId: dbmsEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Foreign key?",
        options: {
          A: "Primary key in another table",
          B: "Alternative key",
          C: "Random key",
          D: "Encryption key",
        },
        correctAnswer: "A",
        explanation: "Foreign key references primary key of another table.",
        orderIndex: 9,
      },
    ],
  });

  const dbmsFinalExam = await prisma.quiz.create({
    data: {
      courseId: dbmsCourse.id,
      title: "DBMS - Final Assessment",
      description: "Complete this exam to earn your certificate.",
      quizType: QuizType.FINAL_EXAM,
      passingScore: 70,
      maxAttempts: 3,
    },
  });
  await prisma.question.createMany({
    data: [
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "ACID properties?",
        options: {
          A: "Atomic, Consistent, Isolated, Durable",
          B: "Advanced, Complete, Integrated, Dynamic",
          C: "Automatic, Complete, Indexed, Distributed",
          D: "Array, Column, Index, Data",
        },
        correctAnswer: "A",
        explanation: "ACID: Atomicity, Consistency, Isolation, Durability.",
        orderIndex: 0,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Index purpose?",
        options: {
          A: "Store more data",
          B: "Speed up retrieval",
          C: "Compress data",
          D: "Encrypt data",
        },
        correctAnswer: "B",
        explanation: "Indexes speed up data retrieval.",
        orderIndex: 1,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "View is?",
        options: {
          A: "Stored data",
          B: "Virtual table",
          C: "Index",
          D: "Backup",
        },
        correctAnswer: "B",
        explanation: "View is a virtual table based on query.",
        orderIndex: 2,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Clustered index?",
        options: {
          A: "Sorted data storage",
          B: "Multiple indexes",
          C: "Unique index",
          D: "Partial index",
        },
        correctAnswer: "A",
        explanation: "Clustered index sorts data physically.",
        orderIndex: 3,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Transaction rollback?",
        options: {
          A: "Save changes",
          B: "Undo changes",
          C: "Delete table",
          D: "Create backup",
        },
        correctAnswer: "B",
        explanation: "ROLLBACK undoes transaction changes.",
        orderIndex: 4,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Deadlock in DB?",
        options: {
          A: "Two users",
          B: "Circular waiting",
          C: "System crash",
          D: "Full disk",
        },
        correctAnswer: "B",
        explanation: "Deadlock is circular waiting for resources.",
        orderIndex: 5,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Inner join returns?",
        options: {
          A: "All rows",
          B: "Matching rows only",
          C: "First row",
          D: "Last row",
        },
        correctAnswer: "B",
        explanation: "INNER JOIN returns only matching rows.",
        orderIndex: 6,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "GROUP BY used with?",
        options: {
          A: "SELECT only",
          B: "Aggregate functions",
          C: "WHERE",
          D: "ORDER BY",
        },
        correctAnswer: "B",
        explanation: "GROUP BY groups for aggregate functions.",
        orderIndex: 7,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a trigger?",
        options: {
          A: "Index",
          B: "Stored procedure",
          C: "Automatic action",
          D: "Backup",
        },
        correctAnswer: "C",
        explanation: "Trigger automatically fires on events.",
        orderIndex: 8,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Denormalization?",
        options: {
          A: "Add more tables",
          B: "Reduce tables/introduce redundancy",
          C: "Create indexes",
          D: "Normalize more",
        },
        correctAnswer: "B",
        explanation: "Denormalization adds redundancy for performance.",
        orderIndex: 9,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "CAP theorem is?",
        options: {
          A: "Database design",
          B: "Consistency, Availability, Partition tolerance",
          C: "SQL commands",
          D: "Index types",
        },
        correctAnswer: "B",
        explanation: "CAP: Consistency, Availability, Partition tolerance.",
        orderIndex: 10,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Stored procedure?",
        options: {
          A: "Data storage",
          B: "Precompiled SQL code",
          C: "Backup method",
          D: "Index type",
        },
        correctAnswer: "B",
        explanation: "Stored procedure is precompiled SQL code.",
        orderIndex: 11,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Cursor is?",
        options: {
          A: "Pointer to result set",
          B: "Index",
          C: "Trigger",
          D: "View",
        },
        correctAnswer: "A",
        explanation: "Cursor is pointer to result set row.",
        orderIndex: 12,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "WAL in databases?",
        options: {
          A: "Write After Read",
          B: "Write Ahead Logging",
          C: "Wide Area Link",
          D: "Workload Analysis",
        },
        correctAnswer: "B",
        explanation: "WAL = Write Ahead Logging for durability.",
        orderIndex: 13,
      },
      {
        quizId: dbmsFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Shard in databases?",
        options: {
          A: "Index type",
          B: "Horizontal partition",
          C: "Backup",
          D: "View",
        },
        correctAnswer: "B",
        explanation: "Shard is horizontal partition of data.",
        orderIndex: 14,
      },
    ],
  });

  await prisma.course.update({
    where: { id: dbmsCourse.id },
    data: { entryQuizId: dbmsEntryQuiz.id, finalExamId: dbmsFinalExam.id },
  });
  console.log("Created DBMS course");

  // Course 4: Python Programming
  const pythonCourse = await prisma.course.create({
    data: {
      title: "Python Programming",
      slug: "python-programming",
      shortDescription:
        "Learn Python from scratch with hands-on projects and exercises.",
      description:
        "Beginner-friendly Python course covering basics, data structures, OOP, and simple projects.",
      category: "Programming",
      level: CourseLevel.BEGINNER,
      price: 0,
      status: CourseStatus.PUBLISHED,
      duration: 1200,
      instructorId: instructor2.id,
    },
  });

  const pythonModules = await Promise.all([
    prisma.module.create({
      data: {
        courseId: pythonCourse.id,
        title: "Python Basics",
        track: Track.BOTH,
        orderIndex: 0,
      },
    }),
    prisma.module.create({
      data: {
        courseId: pythonCourse.id,
        title: "Control Flow",
        track: Track.BOTH,
        orderIndex: 1,
      },
    }),
    prisma.module.create({
      data: {
        courseId: pythonCourse.id,
        title: "Functions and Modules",
        track: Track.BOTH,
        orderIndex: 2,
      },
    }),
    prisma.module.create({
      data: {
        courseId: pythonCourse.id,
        title: "Data Structures in Python",
        track: Track.BOTH,
        orderIndex: 3,
      },
    }),
    prisma.module.create({
      data: {
        courseId: pythonCourse.id,
        title: "Object-Oriented Programming",
        track: Track.BOTH,
        orderIndex: 4,
      },
    }),
    prisma.module.create({
      data: {
        courseId: pythonCourse.id,
        title: "File Handling and Exceptions",
        track: Track.BOTH,
        orderIndex: 5,
      },
    }),
  ]);

  // Python Lessons
  await Promise.all([
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[0].id,
        title: "Getting Started with Python",
        content: `<h2>Python Basics</h2><p>Python is a high-level, interpreted programming language.</p><h3>Hello World</h3><pre><code>print("Hello, World!")</code></pre><h3>Variables</h3><pre><code>x = 5\nname = "John"\nprice = 19.99\nis_active = True</code></pre><h3>Data Types</h3><ul><li>int, float, str, bool</li><li>list, tuple, dict, set</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
        isFree: true,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[0].id,
        title: "Data Types and Operators",
        content: `<h2>Data Types</h2><h3>Numbers</h3><pre><code>a = 10      # int\nb = 3.14    # float\nc = 2 + 3j  # complex</code></pre><h3>Strings</h3><pre><code>s = "Hello"\ns[0]       # H\ns[0:3]     # Hel\n"Hello " + "World"  # Hello World</code></pre><h3>Operators</h3><ul><li>Arithmetic: +, -, *, /, //, %, **</li><li>Comparison: ==, !=, <, >, <=, >=</li><li>Logical: and, or, not</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[1].id,
        title: "Conditionals",
        content: `<h2>Conditionals</h2><pre><code>if x > 0:\n    print("Positive")\nelif x < 0:\n    print("Negative")\nelse:\n    print("Zero")</code></pre><h3>Ternary Operator</h3><pre><code>status = "Adult" if age >= 18 else "Minor"</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 15,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[1].id,
        title: "Loops",
        content: `<h2>Loops</h2><h3>For Loop</h3><pre><code>for i in range(5):\n    print(i)  # 0,1,2,3,4\n\nfor item in items:\n    print(item)</code></pre><h3>While Loop</h3><pre><code>while condition:\n    # code</code></pre><h3>Loop Control</h3><ul><li>break - exit loop</li><li>continue - skip iteration</li><li>pass - do nothing</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[2].id,
        title: "Functions",
        content: `<h2>Functions</h2><pre><code>def greet(name):\n    return f"Hello, {name}!"\n\n# Default arguments\ndef power(base, exp=2):\n    return base ** exp\n\n# Lambda functions\nsquare = lambda x: x ** 2</code></pre><h3>Arguments</h3><ul><li>Positional</li><li>Keyword</li><li>*args (variable positional)</li><li>**kwargs (variable keyword)</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[2].id,
        title: "Modules and Packages",
        content: `<h2>Modules</h2><h3>Import</h3><pre><code>import math\nfrom datetime import datetime\nfrom os import path as os_path</code></pre><h3>Create Module</h3><pre><code># mymodule.py\ndef add(a, b):\n    return a + b\n\n# Usage\nimport mymodule\nmymodule.add(1, 2)</code></pre><h3>Built-in Modules</h3><ul><li>math, random</li><li>datetime, time</li><li>os, sys</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[3].id,
        title: "Lists and Tuples",
        content: `<h2>Lists</h2><pre><code>numbers = [1, 2, 3, 4, 5]\nnumbers.append(6)\nnumbers.insert(0, 0)\nnumbers.remove(3)\nprint(numbers[1:3])  # slicing</code></pre><h3>List Comprehension</h3><pre><code>squares = [x**2 for x in range(10)]\nevens = [x for x in range(20) if x % 2 == 0]</code></pre><h3>Tuples</h3><pre><code>point = (x, y)  # immutable</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[3].id,
        title: "Dictionaries and Sets",
        content: `<h2>Dictionaries</h2><pre><code>person = {"name": "John", "age": 30}\nperson["city"] = "NYC\nprint(person.get("name"))\nfor key, value in person.items():\n    print(f"{key}: {value}")</code></pre><h3>Sets</h3><pre><code>fruits = {"apple", "banana", "cherry"}\nfruits.add("orange")\nfruits.remove("banana")\nprint(fruits & other_set)  # intersection</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[4].id,
        title: "Classes and Objects",
        content: `<h2>OOP Basics</h2><pre><code>class Person:\n    def __init__(self, name, age):\n        self.name = name\n        self.age = age\n    \n    def greet(self):\n        return f"Hello, I'm {self.name}"\n\nperson = Person("John", 30)\nprint(person.greet())</code></pre><h3>Attributes</h3><ul><li>instance attributes (self.x)</li><li>class attributes</li></ul><h3>Methods</h3><ul><li>instance methods</li><li>class methods (@classmethod)</li><li>static methods (@staticmethod)</li></ul>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[4].id,
        title: "Inheritance and Polymorphism",
        content: `<h2>Inheritance</h2><pre><code>class Animal:\n    def speak(self):\n        pass\n\nclass Dog(Animal):\n    def speak(self):\n        return "Woof!"\n\nclass Cat(Animal):\n    def speak(self):\n        return "Meow!"</code></pre><h3>Super</h3><pre><code>class Child(Parent):\n    def __init__(self):\n        super().__init__()</code></pre><h3>Polymorphism</h3><p>Same method, different behavior.</p>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 25,
        orderIndex: 1,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[5].id,
        title: "File Handling",
        content: `<h2>File I/O</h2><h3>Reading</h3><pre><code>with open("file.txt", "r") as f:\n    content = f.read()\n    # or line by line\n    for line in f:\n        print(line)</code></pre><h3>Writing</h3><pre><code>with open("output.txt", "w") as f:\n    f.write("Hello!")</code></pre><h3>JSON</h3><pre><code>import json\ndata = {"name": "John"}\njson.dumps(data)\njson.loads('{"name": "John"}')</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 0,
      },
    }),
    prisma.lesson.create({
      data: {
        moduleId: pythonModules[5].id,
        title: "Exception Handling",
        content: `<h2>Exceptions</h2><pre><code>try:\n    result = 10 / 0\nexcept ZeroDivisionError:\n    print("Cannot divide by zero!")\nexcept Exception as e:\n    print(f"Error: {e}")\nelse:\n    print("No errors")\nfinally:\n    print("Always runs")</code></pre><h3>Raise Exception</h3><pre><code>if x < 0:\n    raise ValueError("x must be positive")</code></pre><h3>Custom Exceptions</h3><pre><code>class MyError(Exception):\n    pass</code></pre>`,
        track: Track.BOTH,
        lessonType: LessonType.TEXT,
        duration: 20,
        orderIndex: 1,
      },
    }),
  ]);

  // Python Quizzes
  const pythonEntryQuiz = await prisma.quiz.create({
    data: {
      courseId: pythonCourse.id,
      title: "Python - Entry Assessment",
      description: "This quiz will determine your track placement.",
      quizType: QuizType.ENTRY_QUIZ,
      passingScore: 70,
      maxAttempts: 1,
    },
  });
  await prisma.question.createMany({
    data: [
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you print in Python?",
        options: {
          A: "console.log()",
          B: "print()",
          C: "echo()",
          D: "printf()",
        },
        correctAnswer: "B",
        explanation: "print() is Python output function.",
        orderIndex: 0,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which is NOT a Python data type?",
        options: { A: "int", B: "str", C: "char", D: "bool" },
        correctAnswer: "C",
        explanation: "Python has no char type.",
        orderIndex: 1,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you create a list?",
        options: { A: "{}", B: "[]", C: "()", D: "<>" },
        correctAnswer: "B",
        explanation: "[] creates a list in Python.",
        orderIndex: 2,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: 'What does "==" check?',
        options: {
          A: "Assignment",
          B: "Equality",
          C: "Not equal",
          D: "Greater",
        },
        correctAnswer: "B",
        explanation: "== checks equality.",
        orderIndex: 3,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you define a function?",
        options: { A: "function", B: "def", C: "func", D: "define" },
        correctAnswer: "B",
        explanation: "def keyword defines functions.",
        orderIndex: 4,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "Which loop is NOT in Python?",
        options: { A: "for", B: "while", C: "do-while", D: "foreach" },
        correctAnswer: "C",
        explanation: "Python has no do-while loop.",
        orderIndex: 5,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you access dict value?",
        options: {
          A: "dict[0]",
          B: "dict.key",
          C: 'dict["key"]',
          D: "dict->key",
        },
        correctAnswer: "C",
        explanation: 'Use dict["key"] to access values.',
        orderIndex: 6,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is self?",
        options: {
          A: "Global variable",
          B: "Instance reference",
          C: "Class variable",
          D: "Function",
        },
        correctAnswer: "B",
        explanation: "self references the instance.",
        orderIndex: 7,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you handle exceptions?",
        options: { A: "catch", B: "try-except", C: "handle", D: "error" },
        correctAnswer: "B",
        explanation: "Python uses try-except.",
        orderIndex: 8,
      },
      {
        quizId: pythonEntryQuiz.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a module?",
        options: { A: "Class", B: "Python file", C: "Data type", D: "Loop" },
        correctAnswer: "B",
        explanation: "Module is a Python file.",
        orderIndex: 9,
      },
    ],
  });

  const pythonFinalExam = await prisma.quiz.create({
    data: {
      courseId: pythonCourse.id,
      title: "Python - Final Assessment",
      description: "Complete this exam to earn your certificate.",
      quizType: QuizType.FINAL_EXAM,
      passingScore: 70,
      maxAttempts: 3,
    },
  });
  await prisma.question.createMany({
    data: [
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is list comprehension?",
        options: {
          A: "Creating lists from loops",
          B: "Understanding lists",
          C: "Lists in memory",
          D: "List indexing",
        },
        correctAnswer: "A",
        explanation: "List comprehension creates lists from iterables.",
        orderIndex: 0,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is *args?",
        options: {
          A: "Keyword arguments",
          B: "Variable positional arguments",
          C: "Required arguments",
          D: "Default arguments",
        },
        correctAnswer: "B",
        explanation: "*args accepts variable positional arguments.",
        orderIndex: 1,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is inheritance?",
        options: {
          A: "Copy data",
          B: "Class relationship",
          C: "Variable scope",
          D: "Function call",
        },
        correctAnswer: "B",
        explanation: "Inheritance creates parent-child class relationship.",
        orderIndex: 2,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What does __init__ do?",
        options: {
          A: "Initialize class",
          B: "Delete object",
          C: "Import module",
          D: "Define variable",
        },
        correctAnswer: "A",
        explanation: "__init__ is constructor method.",
        orderIndex: 3,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you open file for writing?",
        options: {
          A: 'open("file", "r")',
          B: 'open("file", "w")',
          C: 'open("file", "x")',
          D: 'open("file", "read")',
        },
        correctAnswer: "B",
        explanation: '"w" opens file for writing.',
        orderIndex: 4,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is polymorphism?",
        options: {
          A: "Many forms",
          B: "Single form",
          C: "Data types",
          D: "Loops",
        },
        correctAnswer: "A",
        explanation:
          "Polymorphism means many forms - same interface, different behavior.",
        orderIndex: 5,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a set?",
        options: {
          A: "Ordered collection",
          B: "Unordered unique elements",
          C: "Key-value pairs",
          D: "Sequence",
        },
        correctAnswer: "B",
        explanation: "Set is unordered collection of unique elements.",
        orderIndex: 6,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What does raise do?",
        options: {
          A: "Stop program",
          B: "Throw exception",
          C: "Return value",
          D: "Print error",
        },
        correctAnswer: "B",
        explanation: "raise throws an exception.",
        orderIndex: 7,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is lambda?",
        options: {
          A: "Function name",
          B: "Anonymous function",
          C: "Variable",
          D: "Class",
        },
        correctAnswer: "B",
        explanation: "lambda creates anonymous functions.",
        orderIndex: 8,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "How do you check file exists?",
        options: {
          A: "file.exists()",
          B: "os.path.exists()",
          C: "path.file()",
          D: "exists.file()",
        },
        correctAnswer: "B",
        explanation: "os.path.exists() checks file existence.",
        orderIndex: 9,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is encapsulation?",
        options: {
          A: "Hide complexity",
          B: "Inherit",
          C: "Override",
          D: "Import",
        },
        correctAnswer: "A",
        explanation: "Encapsulation hides internal details.",
        orderIndex: 10,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is a tuple?",
        options: {
          A: "Mutable list",
          B: "Immutable sequence",
          C: "Dictionary",
          D: "Set",
        },
        correctAnswer: "B",
        explanation: "Tuple is immutable sequence.",
        orderIndex: 11,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What does finally do?",
        options: {
          A: "Runs last",
          B: "Runs always",
          C: "Runs first",
          D: "Runs never",
        },
        correctAnswer: "B",
        explanation: "finally always executes.",
        orderIndex: 12,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is decorator?",
        options: {
          A: "Class",
          B: "Function modifier",
          C: "Variable",
          D: "Loop",
        },
        correctAnswer: "B",
        explanation: "Decorator modifies function behavior.",
        orderIndex: 13,
      },
      {
        quizId: pythonFinalExam.id,
        questionType: QuestionType.MULTIPLE_CHOICE,
        question: "What is try-except-else?",
        options: {
          A: "Loop structure",
          B: "If-else",
          C: "Error handling",
          D: "Class definition",
        },
        correctAnswer: "C",
        explanation: "try-except-else handles exceptions.",
        orderIndex: 14,
      },
    ],
  });

  await prisma.course.update({
    where: { id: pythonCourse.id },
    data: { entryQuizId: pythonEntryQuiz.id, finalExamId: pythonFinalExam.id },
  });
  console.log("Created Python course");

  console.log("Seed completed successfully!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
