/**
 * Text Embedding Generation
 *
 * DISABLED: Will implement later
 *
 * NOTE: This feature has been temporarily disabled due to issues with the
 * text-embedding-001 model not being available in the Gemini API.
 * We plan to implement it in the future with an updated embedding model.
 */

// TODO: Re-implement with updated Gemini embedding model

export const EMBEDDING_DIMENSION = 768;

// Keep utility functions for future use
export function cosineSimilarity(a: number[], b: number[]): number {
  if (a.length !== b.length) {
    throw new Error("Embeddings must have the same dimension");
  }

  let dotProduct = 0;
  let normA = 0;
  let normB = 0;

  for (let i = 0; i < a.length; i++) {
    const aVal = a[i] ?? 0;
    const bVal = b[i] ?? 0;
    dotProduct += aVal * bVal;
    normA += aVal * aVal;
    normB += bVal * bVal;
  }

  const normProduct = Math.sqrt(normA) * Math.sqrt(normB);

  if (normProduct === 0) {
    return 0;
  }

  return dotProduct / normProduct;
}

export function normalizeEmbedding(embedding: number[]): number[] {
  const magnitude = Math.sqrt(
    embedding.reduce((sum, val) => sum + val * val, 0),
  );

  if (magnitude === 0) {
    return embedding;
  }

  return embedding.map((val) => val / magnitude);
}

export function embeddingToString(embedding: number[]): string {
  const float32Array = new Float32Array(embedding);
  const base64 = Buffer.from(float32Array.buffer).toString("base64");
  return base64;
}

export function stringToEmbedding(str: string): number[] {
  const buffer = Buffer.from(str, "base64");
  const float32Array = new Float32Array(
    buffer.buffer,
    buffer.byteOffset,
    buffer.length / 4,
  );
  return Array.from(float32Array);
}

// Placeholder function for future implementation
export async function generateEmbedding(text: string): Promise<number[]> {
  throw new Error(
    "Embedding generation is currently disabled. Will implement later with updated Gemini API.",
  );
}

export async function generateEmbeddings(
  texts: string[],
  options?: { batchSize?: number },
): Promise<number[][]> {
  throw new Error(
    "Embedding generation is currently disabled. Will implement later with updated Gemini API.",
  );
}

export function calculateSimilarityScores(
  queryEmbedding: number[],
  candidates: { id: string; embedding: number[] }[],
): { id: string; score: number }[] {
  const scores = candidates.map((candidate) => ({
    id: candidate.id,
    score: cosineSimilarity(queryEmbedding, candidate.embedding),
  }));

  return scores.sort((a, b) => b.score - a.score);
}
