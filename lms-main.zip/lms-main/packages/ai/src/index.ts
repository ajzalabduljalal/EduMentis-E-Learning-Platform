/**
 * @repo/ai
 * AI utilities for the LMS platform using Google Gemini
 *
 * Exports:
 * - Gemini client configuration
 * - Embedding generation with caching
 * - Semantic search
 * - Quiz generation
 */

export * from "./gemini";
export * from "./embeddings";
export * from "./search";
export * from "./quiz-generator";

// Types re-export
export type { SearchResult, SearchOptions } from "./search";

export type { GeneratedQuestion, GeneratedQuiz } from "./quiz-generator";
