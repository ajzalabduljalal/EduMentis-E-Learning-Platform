/**
 * AI Quiz Generation from Lesson Content
 *
 * Generates MCQ quizzes from lesson content using Gemini
 */

import { generateContent, isConfigured, MODEL_CONFIG } from "./gemini";

// Quiz question structure
export interface GeneratedQuestion {
  question: string;
  options: {
    A: string;
    B: string;
    C: string;
    D: string;
  };
  correctAnswer: "A" | "B" | "C" | "D";
  explanation: string;
}

export interface GeneratedQuiz {
  title: string;
  description: string;
  questions: GeneratedQuestion[];
}

/**
 * System prompt for quiz generation
 */
const QUIZ_GENERATION_SYSTEM = `You are an expert educator specializing in creating assessments for online learning. Your task is to generate high-quality multiple choice questions from lesson content.

Guidelines:
1. Questions should test understanding, not just recall
2. All options should be plausible (no obviously wrong answers)
3. Correct answer should be clearly correct
4. Include a brief explanation for each answer
5. Questions should be clear and unambiguous
6. Use simple language appropriate for the difficulty level
7. Focus on key concepts and important details
8. Include both factual and conceptual questions

Return ONLY valid JSON in the exact format specified, with no additional text.`;

/**
 * Generate a quiz from lesson content
 */
export async function generateQuizFromLesson(
  lessonTitle: string,
  lessonContent: string,
  options?: {
    numQuestions?: number;
    difficulty?: "easy" | "medium" | "hard";
    topic?: string;
  },
): Promise<GeneratedQuiz> {
  if (!isConfigured()) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const numQuestions = options?.numQuestions ?? 5;
  const difficulty = options?.difficulty ?? "medium";

  // Truncate content to avoid token limits
  const truncatedContent = lessonContent.slice(0, 4000);

  const prompt = `${QUIZ_GENERATION_SYSTEM}

Generate ${numQuestions} multiple choice questions based on the following lesson:

Title: ${lessonTitle}
${options?.topic ? `Topic: ${options.topic}` : ""}
Content:
${truncatedContent}

Difficulty: ${difficulty}

Return JSON in this exact format:
{
  "title": "Quiz: [Lesson Title]",
  "description": "A ${difficulty} quiz testing understanding of [topic]",
  "questions": [
    {
      "question": "Question text here?",
      "options": {
        "A": "First option",
        "B": "Second option", 
        "C": "Third option",
        "D": "Fourth option"
      },
      "correctAnswer": "A",
      "explanation": "Why this answer is correct"
    }
  ]
}`;

  const response = await generateContent(prompt, {
    temperature: 0.7,
    maxTokens: 4000,
  });

  // Parse the JSON response
  try {
    // Try to extract JSON from response (in case model adds extra text)
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No valid JSON found in response");
    }

    const quiz = JSON.parse(jsonMatch[0]) as GeneratedQuiz;

    // Validate the structure
    if (!quiz.title || !quiz.questions || !Array.isArray(quiz.questions)) {
      throw new Error("Invalid quiz structure");
    }

    // Validate each question
    for (const question of quiz.questions) {
      if (
        !question.question ||
        !question.options ||
        !question.correctAnswer ||
        !question.explanation
      ) {
        throw new Error("Invalid question structure");
      }

      // Ensure correctAnswer is valid
      if (!["A", "B", "C", "D"].includes(question.correctAnswer)) {
        question.correctAnswer = "A"; // Default to A if invalid
      }
    }

    return quiz;
  } catch (error) {
    console.error("Error parsing quiz JSON:", error);
    console.error("Raw response:", response);
    throw new Error("Failed to generate valid quiz");
  }
}

/**
 * System prompt for module review quiz
 */
const REVIEW_QUIZ_SYSTEM = `You are an expert educator creating review quizzes for learning modules. Your task is to generate comprehensive review questions that test understanding across multiple lessons.

Guidelines:
1. Create questions that connect concepts across lessons
2. Mix factual recall with application questions
3. Include some questions that require synthesizing information
4. All options should be plausible
5. Include clear explanations

Return ONLY valid JSON in the exact format specified.`;

/**
 * Generate a module-level review quiz
 */
export async function generateModuleReviewQuiz(
  moduleTitle: string,
  lessons: { title: string; content: string }[],
  options?: {
    numQuestions?: number;
    difficulty?: "easy" | "medium" | "hard";
  },
): Promise<GeneratedQuiz> {
  if (!isConfigured()) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const numQuestions = options?.numQuestions ?? 10;
  const difficulty = options?.difficulty ?? "medium";

  // Combine lesson content with titles
  const lessonsText = lessons
    .map(
      (lesson, index) =>
        `Lesson ${index + 1}: ${lesson.title}\n${lesson.content.slice(0, 1500)}`,
    )
    .join("\n\n---\n\n");

  const truncatedLessons = lessonsText.slice(0, 6000);

  const prompt = `${REVIEW_QUIZ_SYSTEM}

Generate a ${numQuestions}-question review quiz for the following module:

Module Title: ${moduleTitle}

Lessons:
${truncatedLessons}

Difficulty: ${difficulty}

This quiz should test understanding across ALL lessons in the module. Include questions that connect concepts from different lessons.

Return JSON in this exact format:
{
  "title": "Review Quiz: ${moduleTitle}",
  "description": "A comprehensive ${difficulty} review quiz covering all lessons in this module",
  "questions": [
    {
      "question": "Question text here?",
      "options": {
        "A": "First option",
        "B": "Second option", 
        "C": "Third option",
        "D": "Fourth option"
      },
      "correctAnswer": "A",
      "explanation": "Why this answer is correct"
    }
  ]
}`;

  const response = await generateContent(prompt, {
    temperature: 0.7,
    maxTokens: 5000,
  });

  // Parse the JSON response
  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No valid JSON found in response");
    }

    const quiz = JSON.parse(jsonMatch[0]) as GeneratedQuiz;

    // Validate the structure
    if (!quiz.title || !quiz.questions || !Array.isArray(quiz.questions)) {
      throw new Error("Invalid quiz structure");
    }

    return quiz;
  } catch (error) {
    console.error("Error parsing quiz JSON:", error);
    throw new Error("Failed to generate valid review quiz");
  }
}

/**
 * Generate a course-level assessment preview
 */
export async function generateCourseAssessmentPreview(
  courseTitle: string,
  modules: { title: string; lessons: { title: string }[] }[],
  options?: {
    numQuestions?: number;
  },
): Promise<GeneratedQuiz> {
  if (!isConfigured()) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const numQuestions = options?.numQuestions ?? 15;

  // Just get module and lesson titles for overview
  const overview = modules
    .map(
      (module, mIdx) =>
        `Module ${mIdx + 1}: ${module.title}\n  Lessons: ${module.lessons
          .map((l) => l.title)
          .join(", ")}`,
    )
    .join("\n\n");

  const prompt = `Generate a ${numQuestions}-question course assessment preview for "${courseTitle}".

The course contains:
${overview}

This is a preview/assessment blueprint. Generate questions that would test comprehensive understanding of the entire course material.

Return JSON in this exact format:
{
  "title": "Course Assessment: ${courseTitle}",
  "description": "A comprehensive assessment covering all modules in this course",
  "questions": [
    {
      "question": "Question text here?",
      "options": {
        "A": "First option",
        "B": "Second option", 
        "C": "Third option",
        "D": "Fourth option"
      },
      "correctAnswer": "A",
      "explanation": "Why this answer is correct"
    }
  ]
}`;

  const response = await generateContent(prompt, {
    temperature: 0.7,
    maxTokens: 5000,
  });

  try {
    const jsonMatch = response.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error("No valid JSON found in response");
    }

    return JSON.parse(jsonMatch[0]) as GeneratedQuiz;
  } catch (error) {
    console.error("Error parsing quiz JSON:", error);
    throw new Error("Failed to generate course assessment preview");
  }
}
