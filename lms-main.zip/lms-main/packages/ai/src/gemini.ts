/**
 * Gemini API Client Configuration
 *
 * Provides initialization and helper functions for Google Gemini AI
 */

import { GoogleGenerativeAI } from "@google/generative-ai";

// Environment variable check
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  console.warn("GEMINI_API_KEY not set - AI features will not work");
}

/**
 * Gemini model configurations
 */
export const MODEL_CONFIG = {
  /** Standard chat model for tutor and content generation */
  chat: "gemini-2.5-flash",

  /** Fast model for simple tasks */
  fast: "gemini-2.5-flash",

  /** Model for generating embeddings (currently unavailable - use alternative) */
  embedding: "text-embedding-004",
} as const;

export type ModelType = keyof typeof MODEL_CONFIG;

/**
 * Singleton Gemini AI client
 */
let genAI: GoogleGenerativeAI | null = null;

/**
 * Get or initialize the Gemini AI client
 */
export function getGenAI(): GoogleGenerativeAI {
  if (!GEMINI_API_KEY) {
    throw new Error("GEMINI_API_KEY environment variable is not set");
  }

  if (!genAI) {
    genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
  }

  return genAI;
}

/**
 * Get a specific model instance
 */
export function getModel(modelType: ModelType = "chat") {
  const ai = getGenAI();
  return ai.getGenerativeModel({ model: MODEL_CONFIG[modelType] });
}

/**
 * Check if Gemini API is configured
 */
export function isConfigured(): boolean {
  return !!GEMINI_API_KEY;
}

/**
 * Streaming chat helper
 *
 * @param prompt - The prompt to send
 * @param context - Optional context to prepend
 * @param onChunk - Callback for each chunk of the response
 */
export async function* streamChat(
  prompt: string,
  context?: string,
  systemInstruction?: string,
): AsyncGenerator<string> {
  const model = getModel("chat");

  const contents: { role: string; parts: { text: string }[] }[] = [];

  if (context) {
    contents.push({
      role: "user",
      parts: [{ text: context }],
    });
  }

  contents.push({
    role: "user",
    parts: [{ text: prompt }],
  });

  const generationConfig = {
    temperature: 0.7,
    topP: 0.95,
    topK: 40,
    maxOutputTokens: 2048,
  };

  const chatSession = model.startChat({
    generationConfig,
    history: contents.slice(0, -1),
  });

  const lastMessage = contents[contents.length - 1];
  if (!lastMessage) {
    throw new Error("No message to send");
  }

  const result = await chatSession.sendMessageStream(
    lastMessage.parts[0]?.text ?? "",
  );

  for await (const chunk of result.stream) {
    yield chunk.text();
  }
}

/**
 * Non-streaming chat helper
 */
export async function generateContent(
  prompt: string,
  options?: {
    temperature?: number;
    maxTokens?: number;
    systemInstruction?: string;
  },
): Promise<string> {
  const model = getModel("chat");

  const generationConfig = {
    temperature: options?.temperature ?? 0.7,
    maxOutputTokens: options?.maxTokens ?? 2048,
  };

  const result = await model.generateContent({
    contents: [{ role: "user", parts: [{ text: prompt }] }],
    generationConfig,
  });

  const response = result.response;
  return response.text();
}
