/**
 * Semantic Search Implementation
 *
 * DISABLED: Will implement later
 *
 * NOTE: This feature has been temporarily disabled due to issues with the
 * text-embedding-001 model. We plan to implement it in the future with
 * an updated embedding model.
 */

// TODO: Re-implement semantic search with updated Gemini embedding model

/*
 * Previous implementation commented out for future reference:
 *
 * Used embeddings for semantic search across lessons and courses
 * with caching support
 *
 * Main functions that were available:
 * - semanticSearch(query, options)
 * - rebuildSearchIndex()
 * - getCachedEmbedding(contentType, contentId)
 * - cacheEmbedding(contentType, contentId, contentHash, embedding)
 */

export interface SearchResult {
  id: string;
  type: "lesson" | "course" | "module";
  title: string;
  content: string;
  url: string;
  score: number;
  courseId?: string;
  moduleId?: string;
}

export interface SearchOptions {
  limit?: number;
  threshold?: number;
  contentTypes?: ("lesson" | "course" | "module")[];
}

// Placeholder function for future implementation
export async function semanticSearch(
  query: string,
  options: SearchOptions = {},
): Promise<SearchResult[]> {
  throw new Error(
    "Semantic search is currently disabled. Use simple keyword search instead.",
  );
}
