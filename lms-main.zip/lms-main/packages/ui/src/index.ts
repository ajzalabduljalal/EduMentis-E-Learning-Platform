/**
 * @repo/ui - Shared UI Components
 * Built with Radix UI and Tailwind CSS
 *
 * Usage:
 * ```ts
 * import { Button } from "@repo/ui/components/button";
 * import { Card, CardHeader, CardContent } from "@repo/ui/components/card";
 * ```
 */

// Export utility functions
export { cn } from "./lib/utils";

// Export components
export { Button, buttonVariants } from "./components/button";
export type { ButtonProps } from "./components/button";

export {
  Card,
  CardHeader,
  CardFooter,
  CardTitle,
  CardDescription,
  CardContent,
} from "./components/card";

export { Input } from "./components/input";
export { Label } from "./components/label";
export { Badge } from "./components/badge";
export { Textarea } from "./components/textarea";
export { Skeleton } from "./components/skeleton";
export { Separator } from "./components/separator";

// New components
export { Progress } from "./components/progress";
export { Avatar, AvatarImage, AvatarFallback } from "./components/avatar";
export { Tabs, TabsList, TabsTrigger, TabsContent } from "./components/tabs";
export {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from "./components/accordion";
export {
  Dialog,
  DialogPortal,
  DialogOverlay,
  DialogClose,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogFooter,
  DialogTitle,
  DialogDescription,
} from "./components/dialog";
export { RadioGroup, RadioGroupItem } from "./components/radio-group";
export { Checkbox } from "./components/checkbox";
export {
  Select,
  SelectGroup,
  SelectValue,
  SelectTrigger,
  SelectContent,
  SelectLabel,
  SelectItem,
  SelectSeparator,
} from "./components/select";
export {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuCheckboxItem,
  DropdownMenuRadioItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuGroup,
  DropdownMenuPortal,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuRadioGroup,
} from "./components/dropdown-menu";
export {
  type ToastProps,
  type ToastActionElement,
  ToastProvider,
  ToastViewport,
  Toast,
  ToastTitle,
  ToastDescription,
  ToastClose,
  ToastAction,
} from "./components/toast";
export { Toaster } from "./components/toaster";

// Hooks
export { useToast, toast } from "./hooks/use-toast";
