import * as React from "react";

import { cn } from "../lib/utils";

const Badge = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    variant?: "default" | "secondary" | "success" | "warning" | "error" | "beginner" | "intermediate" | "advanced";
  }
>(({ className, variant = "default", ...props }, ref) => {
  const variantStyles = {
    default: "bg-primary-100 text-primary-700 border-primary-200",
    secondary: "bg-slate-100 text-slate-700 border-slate-200",
    success: "bg-success-50 text-success-700 border-success",
    warning: "bg-warning-50 text-warning-700 border-warning",
    error: "bg-error-50 text-error-700 border-error",
    // Level badges for courses
    beginner: "bg-success-50 text-success-700 border-success/20",
    intermediate: "bg-warning-50 text-warning-700 border-warning/20",
    advanced: "bg-error-50 text-error-700 border-error/20",
  };

  return (
    <div
      ref={ref}
      className={cn(
        "inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors",
        variantStyles[variant],
        className,
      )}
      {...props}
    />
  );
});
Badge.displayName = "Badge";

export { Badge };
