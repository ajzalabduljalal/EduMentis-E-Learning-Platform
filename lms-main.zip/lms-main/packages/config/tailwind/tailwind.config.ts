import type { Config } from "tailwindcss";

/**
 * Shared Tailwind CSS configuration for LMS Platform
 * Modern EdTech design inspired by Vercel, Linear, Coursera
 * 2025-2026 trends: Indigo primary, Slate neutrals, premium feel
 */
const config: Omit<Config, "content"> = {
  theme: {
    extend: {
      colors: {
        // Primary color - Indigo (modern EdTech standard)
        primary: {
          50: "#eef2ff",
          100: "#e0e7ff",
          200: "#c7d2fe",
          300: "#a5b4fc",
          400: "#818cf8",
          500: "#6366f1",
          600: "#4f46e5", // Main primary
          DEFAULT: "#4f46e5",
          700: "#4338ca",
          800: "#3730a3",
          900: "#312e81",
          950: "#1e1b4b",
        },
        // Accent color - Bright Mint/Teal (Tambo-inspired)
        accent: {
          DEFAULT: "#7FFFC3", // Bright mint - primary accent
          hover: "#80C1A2", // Muted teal - hover state
          light: "#B6FFDD", // Light mint - backgrounds
          dark: "#0F1A17", // Very dark green/black - dark contrast
        },
        // Zinc neutrals (matching reference design rgb(9, 9, 11))
        zinc: {
          50: "#fafafa",
          100: "#f4f4f5",
          200: "#e4e4e7",
          300: "#d4d4d8",
          400: "#a1a1aa",
          500: "#71717a",
          600: "#52525b",
          700: "#3f3f46",
          800: "#27272a",
          900: "#18181b",
          950: "#09090b",
        },
        // Slate neutrals (cooler, more premium than gray)
        slate: {
          50: "#f8fafc",
          100: "#f1f5f9",
          200: "#e2e8f0",
          300: "#cbd5e1",
          400: "#94a3b8",
          500: "#64748b",
          600: "#475569",
          700: "#334155",
          800: "#1e293b",
          900: "#0f172a",
          950: "#020617",
        },
        // Text colors - Tambo-inspired dark green/black
        text: {
          primary: "#0F1A17", // Very dark green/black from Tambo
          secondary: "#71717a", // zinc-500
          tertiary: "#a1a1aa", // zinc-400
          inverse: "#ffffff",
        },
        // Background colors - Pale teal tints
        bg: {
          primary: "#ffffff",
          secondary: "#F2F8F6", // Off-white with teal hint
          tertiary: "#E5F0ED", // Almost white teal
          quaternary: "#D8E9E4", // Very pale teal
          inverse: "#0F1A17", // Very dark green/black
        },
        // Border colors
        border: {
          DEFAULT: "#e4e4e7", // zinc-200
          light: "#f4f4f5", // zinc-100
          dark: "#d4d4d8", // zinc-300
        },
        // Semantic colors - Emerald, Amber, Rose
        success: {
          50: "#ecfdf5",
          100: "#d1fae5",
          DEFAULT: "#10b981", // Emerald-500
          600: "#059669",
          700: "#047857",
        },
        warning: {
          50: "#fffbeb",
          100: "#fef3c7",
          DEFAULT: "#f59e0b", // Amber-500
          600: "#d97706",
          700: "#b45309",
        },
        error: {
          50: "#fff1f2",
          100: "#ffe4e6",
          DEFAULT: "#f43f5e", // Rose-500
          600: "#e11d48",
          700: "#be123c",
        },
        // Ring color for focus states
        ring: {
          DEFAULT: "#14b8a6", // Match accent color
          offset: "#ffffff",
        },
      },
      fontFamily: {
        sans: [
          '"Figtree"',
          "ui-sans-serif",
          "system-ui",
          "-apple-system",
          "BlinkMacSystemFont",
          '"Segoe UI"',
          "Roboto",
          '"Helvetica Neue"',
          "Arial",
          "sans-serif",
        ],
        mono: [
          '"JetBrains Mono"',
          '"Fira Code"',
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "Monaco",
          "Consolas",
          '"Liberation Mono"',
          '"Courier New"',
          "monospace",
        ],
      },
      fontSize: {
        xs: ["0.75rem", { lineHeight: "1rem" }],
        sm: ["0.875rem", { lineHeight: "1.25rem" }],
        base: ["1rem", { lineHeight: "1.5rem" }], // 16px / 24px = 1.5 (matches reference)
        lg: ["1.125rem", { lineHeight: "1.75rem" }],
        xl: ["1.25rem", { lineHeight: "1.75rem" }],
        "2xl": ["1.5rem", { lineHeight: "2rem" }],
        "3xl": ["1.875rem", { lineHeight: "2.25rem" }],
        "4xl": ["2.25rem", { lineHeight: "2.5rem" }],
        "5xl": ["3rem", { lineHeight: "1" }],
      },
      lineHeight: {
        tight: "1.25",
        normal: "1.5", // Match reference (24px / 16px)
        relaxed: "1.75",
      },
      spacing: {
        // 8px-based spacing system
        "18": "4.5rem", // 72px
        "22": "5.5rem", // 88px
      },
      borderRadius: {
        none: "0",
        sm: "0.25rem", // 4px
        DEFAULT: "0.5rem", // 8px
        lg: "0.75rem", // 12px
        xl: "1rem", // 16px
      },
      boxShadow: {
        // Subtle, premium shadows
        sm: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
        DEFAULT: "0 1px 3px 0 rgba(0, 0, 0, 0.1)",
        md: "0 2px 4px 0 rgba(0, 0, 0, 0.1)",
        lg: "0 4px 6px -1px rgba(0, 0, 0, 0.1)",
        xl: "0 8px 12px -2px rgba(0, 0, 0, 0.1)",
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        "fade-in": {
          from: { opacity: "0" },
          to: { opacity: "1" },
        },
        "slide-in": {
          from: { transform: "translateY(10px)", opacity: "0" },
          to: { transform: "translateY(0)", opacity: "1" },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "fade-in": "fade-in 0.3s ease-out",
        "slide-in": "slide-in 0.4s ease-out",
      },
    },
  },
  plugins: [],
};

export default config;
