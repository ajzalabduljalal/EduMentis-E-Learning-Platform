/**
 * @repo/types/ai
 * TypeScript types for AI-related operations
 */

import type { Track } from "@repo/db";

// ============================================
// SEARCH TYPES
// ============================================

export interface AISearchRequest {
  query: string;
  limit?: number;
  threshold?: number;
  contentTypes?: ("lesson" | "course" | "module")[];
}

export interface AISearchResult {
  id: string;
  type: "lesson" | "course" | "module";
  title: string;
  content: string;
  url: string;
  score: number;
  courseId?: string;
  moduleId?: string;
}

export interface AISearchResponse {
  query: string;
  results: AISearchResult[];
  total: number;
}

// ============================================
// QUIZ GENERATION TYPES
// ============================================

export interface GenerateQuizRequest {
  lessonId: string;
  numQuestions?: number;
  difficulty?: "easy" | "medium" | "hard";
  saveToDatabase?: boolean;
}

export interface GenerateReviewRequest {
  moduleId: string;
  numQuestions?: number;
  difficulty?: "easy" | "medium" | "hard";
  saveToDatabase?: boolean;
}

export interface GeneratedQuestion {
  question: string;
  options: {
    A: string;
    B: string;
    C: string;
    D: string;
  };
  correctAnswer: "A" | "B" | "C" | "D";
  explanation: string;
}

export interface GeneratedQuiz {
  title: string;
  description: string;
  questions: GeneratedQuestion[];
}

export interface QuizGenerationResponse {
  generated: GeneratedQuiz;
  saved?: {
    quizId: string;
    quizTitle: string;
  };
  moduleId?: string;
  moduleTitle?: string;
  lessonsCount?: number;
}

// ============================================
// TUTOR TYPES
// ============================================

export interface TutorContext {
  currentLesson: {
    title: string;
    content: string;
  };
  courseTrack: Track;
  recentQuizPerformance: {
    quizType: string;
    score: number;
    weakTopics: string[];
  }[];
  conversationHistory: {
    role: "user" | "assistant";
    content: string;
  }[];
}

export interface TutorMessage {
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

export interface TutorSession {
  id: string;
  userId: string;
  courseId?: string;
  lessonId?: string;
  startedAt: Date;
  endedAt?: Date;
  messages: TutorMessage[];
}
