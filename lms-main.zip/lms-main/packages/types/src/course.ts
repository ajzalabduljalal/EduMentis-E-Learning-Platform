/**
 * Course-related types
 * This file will be expanded as we build out the course features
 */

import type { Status, LearningTrack, Progress } from "./common";

/**
 * Course category
 */
export interface CourseCategory {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

/**
 * Basic course information
 * Will be expanded with modules, lessons, quizzes, etc.
 */
export interface Course {
  id: string;
  title: string;
  slug: string;
  description: string;
  status: Status;
  categoryId: string;
  thumbnailUrl?: string;
  createdAt: Date | string;
  updatedAt: Date | string;
}

/**
 * User course enrollment
 */
export interface CourseEnrollment {
  id: string;
  userId: string;
  courseId: string;
  enrolledTrack: LearningTrack;
  progress: Progress;
  enrolledAt: Date | string;
  completedAt?: Date | string;
  certificateUrl?: string;
}

/**
 * Placeholder for future quiz types
 */
export interface Quiz {
  id: string;
  courseId: string;
  title: string;
  type: "entry" | "final" | "lesson";
  // Will be expanded with questions, answers, etc.
}
