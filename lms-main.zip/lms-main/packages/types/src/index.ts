/**
 * @repo/types
 * Shared types for the LMS platform
 *
 * Usage:
 * ```ts
 * import type { ApiResponse, User, Course } from "@repo/types";
 * import { CourseStatus } from "@repo/types";
 * ```
 */

// Re-export everything
export * from "./common";
export * from "./user";
export * from "./course";
export * from "./admin";
export * from "./ai";

// Admin types - explicit exports for better IDE autocomplete
export type {
  CreateCourseInput,
  UpdateCourseInput,
  CourseWithStats,
  CreateModuleInput,
  UpdateModuleInput,
  ReorderModulesInput,
  ModuleWithStats,
  CreateLessonInput,
  UpdateLessonInput,
  ReorderLessonsInput,
  LessonWithDetails,
  CreateQuizInput,
  UpdateQuizInput,
  CreateQuestionInput,
  UpdateQuestionInput,
  ReorderQuestionsInput,
  QuizWithDetails,
  Question,
} from "./admin";

// AI types
export type {
  AISearchRequest,
  AISearchResult,
  AISearchResponse,
  GenerateQuizRequest,
  GenerateReviewRequest,
  GeneratedQuestion,
  GeneratedQuiz,
  QuizGenerationResponse,
  TutorContext,
  TutorMessage,
  TutorSession,
} from "./ai";

// Prisma enums - convenient re-exports
// NOTE: these come from @repo/db which bundles Prisma
// DON'T use in Client Components - stick with string literals
// Safe to use in Server Components and API routes
export {
  CourseStatus,
  CourseLevel,
  Track,
  LessonType,
  QuizType,
  QuestionType,
  AssessmentStatus,
} from "@repo/db";
