/**
 * Common utility types used across the LMS platform
 */

/**
 * Standard API response format
 */
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
}

/**
 * Paginated response format
 */
export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
  totalPages: number;
}

/**
 * Pagination request parameters
 */
export interface PaginationParams {
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortOrder?: "asc" | "desc";
}

/**
 * Generic filter parameters
 */
export interface FilterParams {
  search?: string;
  category?: string;
  status?: string;
  [key: string]: string | number | boolean | undefined;
}

/**
 * Date range filter
 */
export interface DateRange {
  from: Date | string;
  to: Date | string;
}

/**
 * Upload file metadata
 */
export interface FileMetadata {
  filename: string;
  size: number;
  mimeType: string;
  url: string;
  uploadedAt: Date | string;
}

/**
 * Progress tracking
 */
export interface Progress {
  completed: number;
  total: number;
  percentage: number;
}

/**
 * Status types
 */
export type Status = "draft" | "published" | "archived";

/**
 * User role types
 */
export type UserRole = "student" | "instructor" | "admin";

/**
 * Learning track types
 */
export type LearningTrack = "basic" | "advanced" | "both";
