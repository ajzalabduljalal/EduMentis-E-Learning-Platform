/**
 * @repo/types/admin
 * TypeScript types for admin panel operations - courses, modules, lessons, quizzes
 */

import type {
  CourseStatus,
  CourseLevel,
  Track,
  LessonType,
  QuizType,
  QuestionType,
} from "@repo/db";

// ============================================
// COURSE TYPES
// ============================================

export interface CreateCourseInput {
  title: string;
  slug: string;
  description?: string;
  shortDescription?: string;
  imageUrl?: string;
  price: number;
  status: CourseStatus;
  level: CourseLevel;
  category?: string;
  duration?: number;
}

export interface UpdateCourseInput extends Partial<
  Omit<CreateCourseInput, "courseId">
> {
  id: string;
}

export interface CourseWithStats {
  id: string;
  title: string;
  slug: string;
  description?: string;
  shortDescription?: string;
  imageUrl?: string;
  price: number;
  status: CourseStatus;
  level: CourseLevel;
  category?: string;
  duration?: number;
  createdAt: Date;
  updatedAt: Date;
  publishedAt?: Date;
  _count?: {
    modules: number;
    userProgress: number;
  };
}

// ============================================
// MODULE TYPES
// ============================================

export interface CreateModuleInput {
  courseId: string;
  title: string;
  description?: string;
  track: Track;
  orderIndex: number;
}

export interface UpdateModuleInput extends Partial<
  Omit<CreateModuleInput, "courseId">
> {
  id: string;
}

export interface ReorderModulesInput {
  courseId: string;
  modules: Array<{ id: string; orderIndex: number }>;
}

export interface ModuleWithStats {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  track: Track;
  orderIndex: number;
  createdAt: Date;
  updatedAt: Date;
  _count?: {
    lessons: number;
  };
}

// ============================================
// LESSON TYPES
// ============================================

export interface CreateLessonInput {
  moduleId: string;
  title: string;
  description?: string;
  content: string; // rich text HTML
  track: Track;
  lessonType: LessonType;
  duration?: number;
  orderIndex: number;
  isFree: boolean;
}

export interface UpdateLessonInput extends Partial<
  Omit<CreateLessonInput, "moduleId">
> {
  id: string;
}

export interface ReorderLessonsInput {
  moduleId: string;
  lessons: Array<{ id: string; orderIndex: number }>;
}

export interface LessonWithDetails {
  id: string;
  moduleId: string;
  title: string;
  description?: string;
  content: string;
  track: Track;
  lessonType: LessonType;
  duration?: number | null;
  orderIndex: number;
  isFree: boolean;
  videoUrl: string | null;
  createdAt: Date;
  updatedAt: Date;
}

// ============================================
// QUIZ TYPES
// ============================================

export interface CreateQuizInput {
  courseId: string;
  title: string;
  description?: string;
  quizType: QuizType;
  passingScore: number;
  maxAttempts: number;
  timeLimit?: number;
  isRandomized: boolean;
}

export interface UpdateQuizInput extends Partial<
  Omit<CreateQuizInput, "courseId">
> {
  id: string;
}

export interface CreateQuestionInput {
  quizId: string;
  questionType: QuestionType;
  question: string;
  orderIndex: number;
  points: number;
  options?: Record<string, string>;
  correctAnswer?: string;
  testCases?: Array<{ input: string; expectedOutput: string }>;
  starterCode?: string;
  maxLength?: number;
  explanation?: string;
}

export interface UpdateQuestionInput extends Partial<
  Omit<CreateQuestionInput, "quizId">
> {
  id: string;
}

export interface ReorderQuestionsInput {
  quizId: string;
  questions: Array<{ id: string; orderIndex: number }>;
}

export interface QuizWithDetails {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  quizType: QuizType;
  passingScore: number;
  maxAttempts: number;
  timeLimit?: number;
  isRandomized: boolean;
  createdAt: Date;
  updatedAt: Date;
  _count?: {
    questions: number;
  };
}

export interface Question {
  id: string;
  quizId: string;
  questionType: QuestionType;
  question: string;
  points: number;
  orderIndex: number;
  options: Record<string, string> | null;
  correctAnswer: string | null;
  explanation: string | null;
  testCases: Array<{ input: string; expectedOutput: string }> | null;
  starterCode: string | null;
  maxLength: number | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface UpdateCourseInput extends Partial<CreateCourseInput> {
  id: string;
}

export interface CourseWithStats {
  id: string;
  title: string;
  slug: string;
  description?: string;
  shortDescription?: string;
  imageUrl?: string;
  price: number;
  status: CourseStatus;
  level: CourseLevel;
  category?: string;
  duration?: number;
  createdAt: Date;
  updatedAt: Date;
  publishedAt?: Date;
  _count?: {
    modules: number;
    userProgress: number;
  };
}

// ============================================
// MODULE TYPES
// ============================================

export interface CreateModuleInput {
  courseId: string;
  title: string;
  description?: string;
  track: Track;
  orderIndex: number;
}

export interface UpdateModuleInput extends Partial<
  Omit<CreateModuleInput, "courseId">
> {
  id: string;
}

export interface ReorderModulesInput {
  courseId: string;
  modules: Array<{ id: string; orderIndex: number }>;
}

export interface ModuleWithStats {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  track: Track;
  orderIndex: number;
  createdAt: Date;
  updatedAt: Date;
  _count?: {
    lessons: number;
  };
}

// ============================================
// LESSON TYPES
// ====================================== ======

export interface CreateLessonInput {
  moduleId: string;
  title: string;
  description?: string;
  content: string; // Rich text HTML
  track: Track;
  lessonType: LessonType;
  duration?: number;
  orderIndex: number;
  isFree: boolean;
}

export interface UpdateLessonInput extends Partial<
  Omit<CreateLessonInput, "moduleId">
> {
  id: string;
}

export interface ReorderLessonsInput {
  moduleId: string;
  lessons: Array<{ id: string; orderIndex: number }>;
}

export interface LessonWithDetails {
  id: string;
  moduleId: string;
  title: string;
  description?: string;
  content: string;
  track: Track;
  lessonType: LessonType;
  duration?: number | null;
  orderIndex: number;
  isFree: boolean;
  videoUrl: string | null;
  createdAt: Date;
  updatedAt: Date;
}

// ============================================
// QUIZ TYPES
// ============================================

export interface CreateQuizInput {
  courseId: string;
  title: string;
  description?: string;
  quizType: QuizType;
  passingScore: number;
  maxAttempts: number;
  timeLimit?: number;
  isRandomized: boolean;
}

export interface UpdateQuizInput extends Partial<
  Omit<CreateQuizInput, "courseId">
> {
  id: string;
}

export interface CreateQuestionInput {
  quizId: string;
  questionType: QuestionType;
  question: string;
  orderIndex: number;
  points: number;
  options?: Record<string, string>;
  correctAnswer?: string;
  testCases?: Array<{ input: string; expectedOutput: string }>;
  starterCode?: string;
  maxLength?: number;
  explanation?: string;
}

export interface UpdateQuestionInput extends Partial<
  Omit<CreateQuestionInput, "quizId">
> {
  id: string;
}

export interface ReorderQuestionsInput {
  quizId: string;
  questions: Array<{ id: string; orderIndex: number }>;
}

export interface QuizWithDetails {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  quizType: QuizType;
  passingScore: number;
  maxAttempts: number;
  timeLimit?: number;
  isRandomized: boolean;
  createdAt: Date;
  updatedAt: Date;
  _count?: {
    questions: number;
  };
}

export interface Question {
  id: string;
  quizId: string;
  questionType: QuestionType;
  question: string;
  points: number;
  orderIndex: number;
  options: Record<string, string> | null;
  correctAnswer: string | null;
  explanation: string | null;
  testCases: Array<{ input: string; expectedOutput: string }> | null;
  starterCode: string | null;
  maxLength: number | null;
  createdAt: Date;
  updatedAt: Date;
}
