/**
 * User-related types
 */

import type { UserRole } from "./common";

/**
 * User profile
 */
export interface User {
  id: string;
  email: string;
  name: string | null;
  role: UserRole;
  avatarUrl?: string;
  createdAt: Date | string;
  updatedAt: Date | string;
}

/**
 * User preferences
 */
export interface UserPreferences {
  userId: string;
  emailNotifications: boolean;
  pushNotifications: boolean;
  theme: "light" | "dark" | "system";
  language: string;
}

/**
 * User profile update payload
 */
export interface UpdateUserProfile {
  name?: string;
  avatarUrl?: string;
}
