import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";
import { clerkConfig } from "./config";

// Route matchers for public/ignored routes
const isPublicRoute = createRouteMatcher(clerkConfig.publicRoutes);
const isIgnoredRoute = createRouteMatcher(clerkConfig.ignoredRoutes);

/**
 * Shared Clerk middleware - use this in your apps' proxy.ts
 * Skips auth for ignored routes, protects everything else
 */
export const proxy = clerkMiddleware(async (auth, req) => {
  // ignored routes get passed through no questions asked
  if (isIgnoredRoute(req)) {
    return;
  }

  // everything else needs auth
  if (!isPublicRoute(req)) {
    await auth.protect();
  }
});

export { clerkMiddleware, createRouteMatcher };
