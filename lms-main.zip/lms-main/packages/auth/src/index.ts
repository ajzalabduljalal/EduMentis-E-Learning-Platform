/**
 * @repo/auth
 * Shared auth setup with Clerk - components, hooks, and role helpers
 *
 * Usage in Next.js apps:
 * ```ts
 * import { ClerkProvider, SignInButton } from "@repo/auth";
 * import { auth, currentUser } from "@repo/auth";
 * ```
 */

// Clerk components
export {
  ClerkProvider,
  SignInButton,
  SignUpButton,
  SignOutButton,
  SignIn,
  SignUp,
  UserButton,
  UserProfile,
} from "@clerk/nextjs";

// Server-side auth functions
export { auth, currentUser } from "@clerk/nextjs/server";

// React hooks for client components
export {
  useAuth,
  useUser,
  useClerk,
  useSignIn,
  useSignUp,
} from "@clerk/nextjs";

// Our config
export { clerkConfig } from "./config";
export type { ClerkConfig } from "./config";

// Middleware proxy
export { proxy, clerkMiddleware, createRouteMatcher } from "./proxy";

// Role helpers
export {
  getUserRole,
  requireAuth,
  requireAdmin,
  requireInstructor,
  hasRole,
} from "./roles";
export type { UserRole } from "./roles";

// User sync utilities
export { getOrCreateUser, getCurrentDbUser } from "./user";
