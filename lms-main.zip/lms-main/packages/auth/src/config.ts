/**
 * Clerk Configuration
 * Shared configuration for Clerk authentication across apps
 */

export const clerkConfig = {
  // Public routes that don't require authentication
  publicRoutes: ["/", "/sign-in(.*)", "/sign-up(.*)", "/api/webhooks(.*)"],

  // Routes that should ignore authentication
  ignoredRoutes: ["/api/webhooks(.*)", "/_next(.*)", "/favicon.ico"],

  // Default redirect URLs
  signInUrl: process.env.NEXT_PUBLIC_CLERK_SIGN_IN_URL || "/sign-in",
  signUpUrl: process.env.NEXT_PUBLIC_CLERK_SIGN_UP_URL || "/sign-up",
  afterSignInUrl: "/dashboard",
  afterSignUpUrl: "/dashboard",
};

export type ClerkConfig = typeof clerkConfig;
