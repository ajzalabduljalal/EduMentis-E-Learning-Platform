import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export type UserRole = "STUDENT" | "INSTRUCTOR" | "ADMIN";

/**
 * Get role from Clerk public metadata
 * // TODO: sync with db User model in prod
 */
export async function getUserRole(): Promise<UserRole | null> {
  const usr = await currentUser();

  if (!usr) return null;

  // role stored in public metadata (set via Clerk Dashboard)
  const role = usr.publicMetadata?.role as UserRole | undefined;

  return role || "STUDENT"; // default to student if not set
}

/**
 * Require auth + optional role
 * Redirects to sign-in if not authed, or with error param if wrong role
 */
export async function requireAuth(opts?: {
  role?: UserRole;
  redirectTo?: string;
}): Promise<{ userId: string; role: UserRole }> {
  const { userId } = await auth();

  if (!userId) {
    redirect(opts?.redirectTo || "/sign-in");
  }

  const role = await getUserRole();

  if (opts?.role && role !== opts.role) {
    redirect("/sign-in?error=unauthorized"); // TODO: maybe show a nicer error page?
  }

  return { userId, role: role || "STUDENT" };
}

/**
 * Check if user has required role (supports hierarchy)
 */
export async function hasRole(requiredRole: UserRole): Promise<boolean> {
  const role = await getUserRole();
  if (!role) return false;

  // ADMIN > INSTRUCTOR > STUDENT
  const hierarchy: Record<UserRole, number> = {
    STUDENT: 1,
    INSTRUCTOR: 2,
    ADMIN: 3,
  };

  return hierarchy[role] >= hierarchy[requiredRole];
}

/**
 * Require admin role
 */
export async function requireAdmin() {
  return requireAuth({ role: "ADMIN" });
}

/**
 * Require instructor OR admin
 */
export async function requireInstructor() {
  const { userId, role } = await requireAuth();

  if (role !== "INSTRUCTOR" && role !== "ADMIN") {
    redirect("/sign-in?error=unauthorized");
  }

  return { userId, role };
}
