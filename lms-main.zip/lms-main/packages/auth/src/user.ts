import { auth, currentUser } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";

/**
 * Get the current user from the database, creating them if they don't exist.
 * This ensures that any user who signs in via Clerk is automatically
 * added to the local database.
 */
export async function getOrCreateUser() {
  const { userId } = await auth();
  const user = await currentUser();

  if (!userId || !user) {
    return null;
  }

  // Check if user exists in database
  let dbUser = await prisma.user.findUnique({
    where: { clerkId: userId },
  });

  if (!dbUser) {
    // Create user in database from Clerk data
    const email =
      user.emailAddresses?.[0]?.emailAddress || `${userId}@placeholder.com`;
    const name =
      `${user.firstName || ""} ${user.lastName || ""}`.trim() || null;
    const imageUrl = user.imageUrl || null;

    dbUser = await prisma.user.create({
      data: {
        clerkId: userId,
        email,
        name,
        imageUrl,
      },
    });
  }

  return dbUser;
}

/**
 * Get the current user from database only (no creation).
 * Returns null if user doesn't exist.
 */
export async function getCurrentDbUser() {
  const { userId } = await auth();

  if (!userId) {
    return null;
  }

  return prisma.user.findUnique({
    where: { clerkId: userId },
  });
}
