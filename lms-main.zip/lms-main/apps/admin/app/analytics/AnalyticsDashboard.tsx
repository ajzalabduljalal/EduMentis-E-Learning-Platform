"use client";

import { useEffect, useState } from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  BookOpen,
  Users,
  GraduationCap,
  TrendingUp,
  CheckCircle2,
  Clock,
} from "lucide-react";

interface AnalyticsOverview {
  totalCourses: number;
  publishedCourses: number;
  totalEnrollments: number;
  completedEnrollments: number;
  completionRate: number;
  totalStudents: number;
  recentEnrollments: number;
  averageQuizScore: number;
  totalQuizAttempts: number;
  totalAssessmentAttempts: number;
}

interface TopCourse {
  courseId: string;
  courseName: string;
  enrollmentCount: number;
}

interface AnalyticsData {
  overview: AnalyticsOverview;
  topCourses: TopCourse[];
}

const COLORS = ["#18181b", "#3f3f46", "#71717a", "#a1a1aa", "#d4d4d8"];

export function AnalyticsDashboard() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function fetchAnalytics() {
      try {
        const response = await fetch("/api/analytics/overview");
        const result = await response.json();

        if (!response.ok || !result.success) {
          throw new Error(result.error || "Failed to fetch analytics");
        }

        setData(result.data);
      } catch (err) {
        console.error("Failed to fetch analytics:", err);
        setError(
          err instanceof Error ? err.message : "Failed to load analytics",
        );
      } finally {
        setLoading(false);
      }
    }

    fetchAnalytics();
  }, []);

  if (loading) {
    return (
      <div className="text-center py-8 text-zinc-600">Loading analytics...</div>
    );
  }

  if (error || !data) {
    return (
      <div className="text-center py-8 text-red-600">
        {error || "Failed to load analytics"}
      </div>
    );
  }

  const { overview, topCourses } = data;

  // Prepare chart data
  const courseData = [
    { name: "Published", value: overview.publishedCourses },
    { name: "Draft", value: overview.totalCourses - overview.publishedCourses },
  ];

  const completionData = [
    { name: "Completed", value: overview.completedEnrollments },
    {
      name: "In Progress",
      value: overview.totalEnrollments - overview.completedEnrollments,
    },
  ];

  return (
    <div className="space-y-8">
      {/* Key Metrics Grid */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Courses"
          value={overview.totalCourses}
          subtitle={`${overview.publishedCourses} published`}
          icon={<BookOpen className="h-5 w-5 text-zinc-600" />}
          trend={null}
        />
        <StatCard
          title="Total Students"
          value={overview.totalStudents}
          subtitle={`${overview.recentEnrollments} new this week`}
          icon={<Users className="h-5 w-5 text-zinc-600" />}
          trend={{ value: overview.recentEnrollments, isPositive: true }}
        />
        <StatCard
          title="Completion Rate"
          value={`${overview.completionRate}%`}
          subtitle={`${overview.completedEnrollments} of ${overview.totalEnrollments} enrollments`}
          icon={<CheckCircle2 className="h-5 w-5 text-zinc-600" />}
          trend={null}
        />
        <StatCard
          title="Avg Quiz Score"
          value={`${overview.averageQuizScore}%`}
          subtitle={`From ${overview.totalQuizAttempts} attempts`}
          icon={<GraduationCap className="h-5 w-5 text-zinc-600" />}
          trend={null}
        />
      </div>

      {/* Charts Grid */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Top Courses Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-zinc-950">
              Top Courses by Enrollment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={topCourses}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e4e4e7" />
                <XAxis
                  dataKey="courseName"
                  angle={-45}
                  textAnchor="end"
                  height={100}
                  tick={{ fontSize: 12 }}
                />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "white",
                    border: "1px solid #e4e4e7",
                    borderRadius: "6px",
                  }}
                />
                <Bar
                  dataKey="enrollmentCount"
                  fill="#18181b"
                  name="Enrollments"
                />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Completion Status */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl font-semibold text-zinc-950">
              Course Completion Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={completionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) =>
                    `${name}: ${percent ? (percent * 100).toFixed(0) : 0}%`
                  }
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {completionData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={COLORS[index % COLORS.length]}
                    />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              <div className="flex justify-between items-center text-sm">
                <span className="text-zinc-600">Total Enrollments</span>
                <span className="font-semibold text-zinc-950">
                  {overview.totalEnrollments}
                </span>
              </div>
              <div className="flex justify-between items-center text-sm">
                <span className="text-zinc-600">Completed</span>
                <span className="font-semibold text-zinc-950">
                  {overview.completedEnrollments}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Additional Stats Row */}
      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-600">
                  Total Enrollments
                </p>
                <p className="text-2xl font-bold text-zinc-950 mt-1">
                  {overview.totalEnrollments}
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-zinc-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-600">
                  Quiz Attempts
                </p>
                <p className="text-2xl font-bold text-zinc-950 mt-1">
                  {overview.totalQuizAttempts}
                </p>
              </div>
              <Clock className="h-8 w-8 text-zinc-400" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-600">
                  Assessment Submissions
                </p>
                <p className="text-2xl font-bold text-zinc-950 mt-1">
                  {overview.totalAssessmentAttempts}
                </p>
              </div>
              <GraduationCap className="h-8 w-8 text-zinc-400" />
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

interface StatCardProps {
  title: string;
  value: number | string;
  subtitle: string;
  icon: React.ReactNode;
  trend: { value: number; isPositive: boolean } | null;
}

function StatCard({ title, value, subtitle, icon, trend }: StatCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <p className="text-sm font-medium text-zinc-600">{title}</p>
          {icon}
        </div>
        <p className="text-3xl font-bold text-zinc-950 mb-1">{value}</p>
        <p className="text-xs text-zinc-500">{subtitle}</p>
        {trend && (
          <div
            className={`mt-2 text-xs font-medium ${trend.isPositive ? "text-green-600" : "text-red-600"}`}
          >
            {trend.isPositive ? "↑" : "↓"} {trend.value} new
          </div>
        )}
      </CardContent>
    </Card>
  );
}
