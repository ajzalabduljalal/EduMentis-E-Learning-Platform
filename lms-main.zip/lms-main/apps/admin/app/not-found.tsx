import Link from "next/link";
import { Home, ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-bg-primary p-4">
      <div className="text-center max-w-md">
        {/* Error Code */}
        <h1 className="text-8xl font-bold text-text-primary mb-4">404</h1>

        {/* Title */}
        <h2 className="text-2xl font-semibold text-text-primary mb-2">
          Page Not Found
        </h2>

        {/* Description */}
        <p className="text-text-secondary mb-8">
          Sorry, the page you&apos;re looking for doesn&apos;t exist or has been
          moved.
        </p>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            href="/admin"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-zinc-900 text-white font-medium rounded-md hover:bg-zinc-800 transition-colors"
          >
            <Home className="h-4 w-4" />
            Go to Dashboard
          </Link>

          <Link
            href="/admin/courses"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-white border border-border text-text-primary font-medium rounded-md hover:bg-bg-secondary transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Manage Courses
          </Link>
        </div>
      </div>
    </div>
  );
}
