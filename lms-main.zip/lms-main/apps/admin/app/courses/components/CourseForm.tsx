"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type {
  CreateCourseInput,
  ApiResponse,
  CourseWithStats,
} from "@repo/types";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Label } from "@repo/ui/components/label";

interface CourseFormProps {
  course?: CourseWithStats;
}

export function CourseForm({ course }: CourseFormProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState<CreateCourseInput>({
    title: course?.title || "",
    slug: course?.slug || "",
    description: course?.description || "",
    shortDescription: course?.shortDescription || "",
    imageUrl: course?.imageUrl || "",
    price: course?.price || 0,
    status: course?.status || "DRAFT",
    level: course?.level || "BEGINNER",
    category: course?.category || "",
    duration: course?.duration || undefined,
  });

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) => {
    const { name, value, type } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "number" ? (value ? parseFloat(value) : undefined) : value,
    }));

    // Auto-generate slug from title
    if (name === "title" && !course) {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/(^-|-$)/g, "");
      setFormData((prev) => ({ ...prev, slug }));
    }
  };

  const handleSubmit = async (e: React.FormEvent, status?: string) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const dataToSubmit = {
        ...formData,
        status: status || formData.status,
      };

      const url = course ? `/api/courses/${course.id}` : "/api/courses";
      const method = course ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(dataToSubmit),
      });

      const data: ApiResponse<CourseWithStats> = await response.json();

      if (data.success) {
        router.push("/courses");
        router.refresh();
      } else {
        setError(data.error || "Failed to save course");
      }
    } catch (err) {
      setError("Failed to save course");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={(e) => handleSubmit(e)} className="space-y-8">
      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-6">
          <p className="text-sm font-medium text-red-700">{error}</p>
        </div>
      )}

      <div className="rounded-lg border border-border bg-bg-primary p-8 space-y-6">
        <h2 className="text-lg font-semibold text-text-primary">
          Basic Information
        </h2>

        {/* Title */}
        <div>
          <Label htmlFor="title">
            Course Title <span className="text-red-500">*</span>
          </Label>
          <Input
            type="text"
            id="title"
            name="title"
            value={formData.title}
            onChange={handleChange}
            required
            placeholder="Introduction to React"
            className="mt-2"
          />
        </div>

        {/* Slug */}
        <div>
          <Label htmlFor="slug">
            URL Slug <span className="text-red-500">*</span>
          </Label>
          <Input
            type="text"
            id="slug"
            name="slug"
            value={formData.slug}
            onChange={handleChange}
            required
            disabled={!!course}
            placeholder="introduction-to-react"
            className="mt-2"
          />
          <p className="mt-2 text-xs text-text-secondary">
            {course
              ? "Slug cannot be changed after creation"
              : "Auto-generated from title, but you can customize it"}
          </p>
        </div>

        {/* Short Description */}
        <div>
          <Label htmlFor="shortDescription">Short Description</Label>
          <Input
            type="text"
            id="shortDescription"
            name="shortDescription"
            value={formData.shortDescription || ""}
            onChange={handleChange}
            maxLength={160}
            placeholder="A brief one-liner about the course"
            className="mt-2"
          />
          <p className="mt-2 text-xs text-text-secondary">
            Max 160 characters - shown in course cards
          </p>
        </div>

        {/* Description */}
        <div>
          <Label htmlFor="description">Full Description</Label>
          <Textarea
            id="description"
            name="description"
            value={formData.description || ""}
            onChange={handleChange}
            rows={5}
            placeholder="Detailed description of what students will learn..."
            className="mt-2"
          />
        </div>

        {/* Image URL */}
        <div>
          <Label htmlFor="imageUrl">Thumbnail Image URL</Label>
          <Input
            type="url"
            id="imageUrl"
            name="imageUrl"
            value={formData.imageUrl || ""}
            onChange={handleChange}
            placeholder="https://example.com/image.jpg"
            className="mt-2"
          />
          <p className="mt-2 text-xs text-text-secondary">
            Optional - provide a URL to the course thumbnail
          </p>
        </div>
      </div>

      <div className="rounded-lg border border-border bg-bg-primary p-8 space-y-6">
        <h2 className="text-lg font-semibold text-text-primary">
          Course Details
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Category */}
          <div>
            <Label htmlFor="category">Category</Label>
            <Input
              type="text"
              id="category"
              name="category"
              value={formData.category || ""}
              onChange={handleChange}
              placeholder="Programming, Design, Business..."
              className="mt-2"
            />
          </div>

          {/* Level */}
          <div>
            <Label htmlFor="level">Level</Label>
            <Select
              value={formData.level}
              onValueChange={(value) =>
                setFormData({ ...formData, level: value as any })
              }
            >
              <SelectTrigger className="w-full mt-2">
                <SelectValue placeholder="Select level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="BEGINNER">Beginner</SelectItem>
                <SelectItem value="INTERMEDIATE">Intermediate</SelectItem>
                <SelectItem value="ADVANCED">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Price */}
          <div>
            <Label htmlFor="price">Price (₹)</Label>
            <Input
              type="number"
              id="price"
              name="price"
              value={formData.price ?? ""}
              onChange={handleChange}
              min="0"
              step="0.01"
              placeholder="0.00"
              className="mt-2"
            />
            <p className="mt-2 text-xs text-text-secondary">
              Set to 0 for free courses
            </p>
          </div>

          {/* Duration */}
          <div>
            <Label htmlFor="duration">Duration (minutes)</Label>
            <Input
              type="number"
              id="duration"
              name="duration"
              value={formData.duration || ""}
              onChange={handleChange}
              min="0"
              placeholder="120"
              className="mt-2"
            />
            <p className="mt-2 text-xs text-text-secondary">
              Estimated total course duration
            </p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-end gap-4 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => router.push("/courses")}
          disabled={loading}
        >
          Cancel
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={(e) => handleSubmit(e, "DRAFT")}
          disabled={loading}
        >
          {loading ? "Saving..." : "Save as Draft"}
        </Button>
        <Button
          type="button"
          onClick={(e) => handleSubmit(e, "PUBLISHED")}
          disabled={loading}
        >
          {loading
            ? "Publishing..."
            : course
              ? "Update & Publish"
              : "Create & Publish"}
        </Button>
      </div>
    </form>
  );
}
