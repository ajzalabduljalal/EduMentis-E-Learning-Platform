"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Edit2, Trash2, Eye, Users, BookOpen } from "lucide-react";
import type {
  CourseWithStats,
  PaginatedResponse,
  ApiResponse,
} from "@repo/types";
import Image from "next/image";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { useToast } from "@repo/ui/hooks/use-toast";

type CourseStatus = "DRAFT" | "PUBLISHED" | "ARCHIVED";

export function CourseList() {
  const { toast } = useToast();
  const [courses, setCourses] = useState<CourseWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [statusFilter, setStatusFilter] = useState<CourseStatus | "ALL">("ALL");

  useEffect(() => {
    fetchCourses();
  }, [page, statusFilter]);

  const fetchCourses = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams({
        page: page.toString(),
        pageSize: "10",
      });

      if (statusFilter !== "ALL") {
        params.append("status", statusFilter);
      }

      const response = await fetch(`/api/courses?${params.toString()}`);
      const data: ApiResponse<PaginatedResponse<CourseWithStats>> =
        await response.json();

      if (data.success && data.data) {
        setCourses(data.data.items);
        setTotalPages(data.data.totalPages);
      } else {
        setError(data.error || "Failed to fetch courses");
      }
    } catch (err) {
      setError("Failed to fetch courses");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (courseId: string) => {
    if (!confirm("Are you sure you want to delete this course?")) {
      return;
    }

    try {
      const response = await fetch(`/api/courses/${courseId}`, {
        method: "DELETE",
      });
      const data: ApiResponse = await response.json();

      if (data.success) {
        toast({
          variant: "success",
          title: "Course deleted successfully",
          description: "The course has been permanently removed.",
        });
        fetchCourses();
      } else {
        toast({
          variant: "destructive",
          title: "Failed to delete course",
          description:
            data.error || "An error occurred while deleting the course.",
        });
      }
    } catch (err) {
      toast({
        variant: "destructive",
        title: "Failed to delete course",
        description: "An unexpected error occurred. Please try again.",
      });
      console.error(err);
    }
  };

  const getStatusBadge = (status: CourseStatus) => {
    const styles = {
      DRAFT: "bg-zinc-100 text-zinc-700 border border-zinc-200",
      PUBLISHED: "bg-green-50 text-green-700 border border-green-200",
      ARCHIVED: "bg-red-50 text-red-700 border border-red-200",
    };

    return (
      <span
        className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${styles[status]}`}
      >
        {status}
      </span>
    );
  };

  if (loading && courses.length === 0) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="text-center">
          <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-accent border-r-transparent"></div>
          <p className="mt-4 text-sm text-text-secondary">Loading courses...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-6">
        <p className="text-sm text-red-700">{error}</p>
      </div>
    );
  }

  if (courses.length === 0) {
    return (
      <div className="rounded-lg border border-dashed border-border bg-bg-primary p-16 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-bg-secondary">
          <BookOpen className="h-7 w-7 text-text-secondary" />
        </div>
        <h3 className="mt-5 text-base font-semibold text-text-primary">
          No courses yet
        </h3>
        <p className="mt-2 text-base text-text-secondary">
          Get started by creating your first course.
        </p>
        <Link
          href="/courses/new"
          className="mt-6 inline-flex items-center gap-2 rounded-lg bg-zinc-900 px-5 py-2.5 text-sm font-semibold text-white hover:bg-zinc-800 transition-smooth shadow-sm"
        >
          Create Course
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex items-center gap-4">
        <label className="text-sm font-semibold text-text-primary">
          Status:
        </label>
        <Select
          value={statusFilter}
          onValueChange={(value) =>
            setStatusFilter(value as CourseStatus | "ALL")
          }
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Statuses</SelectItem>
            <SelectItem value="DRAFT">Draft</SelectItem>
            <SelectItem value="PUBLISHED">Published</SelectItem>
            <SelectItem value="ARCHIVED">Archived</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Course Table */}
      <div className="overflow-hidden rounded-lg border border-border bg-bg-primary shadow-sm">
        <table className="min-w-full divide-y divide-border">
          <thead className="bg-bg-secondary">
            <tr>
              <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Course
              </th>
              <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Status
              </th>
              <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Modules
              </th>
              <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Students
              </th>
              <th className="px-6 py-4 text-left text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Updated
              </th>
              <th className="px-6 py-4 text-right text-xs font-semibold uppercase tracking-wider text-text-secondary">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border bg-bg-primary">
            {courses.map((course) => (
              <tr
                key={course.id}
                className="hover:bg-bg-secondary/50 transition-smooth"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    {course.imageUrl &&
                      (() => {
                        try {
                          new URL(course.imageUrl);
                          return (
                            <Image
                              src={course.imageUrl}
                              alt={course.title}
                              width={48}
                              height={48}
                              className="rounded-lg object-cover"
                            />
                          );
                        } catch {
                          return null;
                        }
                      })()}
                    <div>
                      <div className="text-sm font-semibold text-text-primary">
                        {course.title}
                      </div>
                      <div className="text-xs text-text-secondary mt-0.5">
                        {course.slug}
                      </div>
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">{getStatusBadge(course.status)}</td>
                <td className="px-6 py-4 text-sm font-medium text-text-primary">
                  {course._count?.modules || 0}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2 text-sm font-medium text-text-primary">
                    <Users className="h-4 w-4 text-text-secondary" />
                    {course._count?.userProgress || 0}
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-text-secondary">
                  {new Date(course.updatedAt).toLocaleDateString()}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center justify-end gap-2">
                    <Link
                      href={`/courses/${course.id}/edit`}
                      className="rounded-lg p-2 text-text-secondary hover:bg-bg-secondary hover:text-text-primary transition-smooth"
                      title="Edit course"
                    >
                      <Edit2 className="h-4 w-4" />
                    </Link>
                    <Link
                      href={`/courses/${course.slug}/modules`}
                      className="rounded-lg p-2 text-text-secondary hover:bg-bg-secondary hover:text-text-primary transition-smooth"
                      title="Manage modules"
                    >
                      <Eye className="h-4 w-4" />
                    </Link>
                    <button
                      onClick={() => handleDelete(course.id)}
                      className="rounded-lg p-2 text-text-secondary hover:bg-red-50 hover:text-red-600 transition-smooth disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Delete course"
                      disabled={
                        !!course._count?.userProgress &&
                        course._count.userProgress > 0
                      }
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-3">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={page === 1}
            className="rounded-lg border border-border bg-bg-primary px-4 py-2 text-sm font-medium text-text-primary hover:bg-bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-smooth"
          >
            Previous
          </button>
          <span className="text-sm font-medium text-text-secondary">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="rounded-lg border border-border bg-bg-primary px-4 py-2 text-sm font-medium text-text-primary hover:bg-bg-secondary disabled:opacity-50 disabled:cursor-not-allowed transition-smooth"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
}
