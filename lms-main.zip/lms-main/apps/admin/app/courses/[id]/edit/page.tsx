import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import { notFound } from "next/navigation";
import { CourseForm } from "../../components/CourseForm";
import Link from "next/link";
import { ArrowLeft, BookOpen, Save, Award } from "lucide-react";
import type { CourseWithStats } from "@repo/types";

export default async function EditCoursePage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireInstructor();
  const { id } = await params;

  // Fetch course with stats
  const course = await prisma.course.findUnique({
    where: { id },
    include: {
      _count: {
        select: {
          modules: true,
          userProgress: true,
        },
      },
    },
  });

  if (!course) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-10">
          <Link
            href="/courses"
            className="inline-flex items-center gap-2 text-sm font-semibold text-text-secondary hover:text-text-primary transition-smooth mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Courses
          </Link>

          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4 mb-4">
            <h1 className="text-2xl font-semibold tracking-tight text-text-primary">
              Edit Course
            </h1>
            <div className="flex gap-3">
              <Link
                href={`/courses/${id}/modules`}
                className="flex items-center justify-center gap-2 rounded-lg border border-border bg-bg-primary px-4 py-2.5 text-sm font-semibold text-text-primary hover:bg-bg-secondary transition-smooth"
              >
                <BookOpen className="h-4 w-4" />
                Manage Modules
              </Link>
              <Link
                href={`/courses/${id}/quizzes`}
                className="flex items-center justify-center gap-2 rounded-lg border border-border bg-bg-primary px-4 py-2.5 text-sm font-semibold text-text-primary hover:bg-bg-secondary transition-smooth"
              >
                <Award className="h-4 w-4" />
                Manage Quizzes
              </Link>
            </div>
          </div>
          <p className="text-base text-text-secondary">
            Update the course details below
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
        <CourseForm course={course as CourseWithStats} />
      </div>
    </div>
  );
}
