"use client";

import { useState } from "react";
import {
  Plus,
  Trash2,
  CheckCircle2,
  Code,
  AlignLeft,
  ListChecks,
  CheckSquare,
  FunctionSquare,
  Save,
  Loader2,
} from "lucide-react";
import type {
  Question,
  CreateQuestionInput,
  UpdateQuestionInput,
} from "@repo/types";
import { useToast } from "@repo/ui/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Label } from "@repo/ui/components/label";

type QuestionType = "MULTIPLE_CHOICE" | "TEXT" | "CODE" | "FILE_UPLOAD";

// Helper for Enum if needed
const QUESTION_TYPES = {
  MULTIPLE_CHOICE: "MULTIPLE_CHOICE",
  TEXT: "TEXT",
  CODE: "CODE",
};

interface QuestionEditorProps {
  quizId: string;
  courseId: string;
  question?: Question;
  onSave: () => void;
  onCancel: () => void;
}

export function QuestionEditor({
  quizId,
  courseId,
  question,
  onSave,
  onCancel,
}: QuestionEditorProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    questionType: (question?.questionType || "MULTIPLE_CHOICE") as string,
    question: question?.question || "",
    points: question?.points || 10,
    explanation: question?.explanation || "",
    // MCQ/Multiple Select
    options: (question?.options as Record<string, string>) || {
      option1: "",
      option2: "",
    },
    correctAnswer: question?.correctAnswer || "option1",
    // Code
    starterCode: question?.starterCode || "",
    testCases: (question?.testCases || []) as Array<{
      input: string;
      expectedOutput: string;
    }>,
  });

  // Helper to add option
  const addOption = () => {
    const newKey = `option${Object.keys(formData.options).length + 1}`;
    setFormData({
      ...formData,
      options: { ...formData.options, [newKey]: "" },
    });
  };

  // Helper to remove option
  const removeOption = (key: string) => {
    const newOptions = { ...formData.options };
    delete newOptions[key];
    setFormData({
      ...formData,
      options: newOptions,
    });
  };

  // Helper to add test case
  const addTestCase = () => {
    setFormData({
      ...formData,
      testCases: [...formData.testCases, { input: "", expectedOutput: "" }],
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const url = question
        ? `/api/courses/${courseId}/quizzes/${quizId}/questions/${question.id}`
        : `/api/courses/${courseId}/quizzes/${quizId}/questions`;

      const method = question ? "PUT" : "POST";

      // Clean up payload
      const payload: any = {
        questionType: formData.questionType,
        question: formData.question,
        points: Number(formData.points),
        explanation: formData.explanation,
      };

      if (["MULTIPLE_CHOICE"].includes(formData.questionType)) {
        payload.options = formData.options;
        payload.correctAnswer = formData.correctAnswer;
      }

      if (formData.questionType === "CODE") {
        payload.starterCode = formData.starterCode;
        payload.testCases = formData.testCases;
      }

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          variant: "success",
          title: question
            ? "Question updated successfully"
            : "Question added successfully",
          description: question
            ? "Your question has been updated."
            : "The question has been added to the quiz.",
        });
        onSave();
      } else {
        setError(data.error || "Failed to save question");
        toast({
          variant: "destructive",
          title: "Failed to save question",
          description:
            data.error || "An error occurred while saving the question.",
        });
      }
    } catch (err) {
      console.error(err);
      setError("Failed to save question");
      toast({
        variant: "destructive",
        title: "Failed to save question",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-bg-primary border border-border rounded-lg p-6 space-y-6"
    >
      <h3 className="text-lg font-medium text-text-primary">
        {question ? "Edit Question" : "Add New Question"}
      </h3>

      {error && (
        <div className="p-3 bg-red-50 text-red-600 rounded text-sm border border-red-200">
          {error}
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        {/* Question Type */}
        <div>
          <Label>Question Type</Label>
          <Select
            value={formData.questionType}
            onValueChange={(value) =>
              setFormData({ ...formData, questionType: value })
            }
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select question type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="MULTIPLE_CHOICE">Multiple Choice</SelectItem>
              <SelectItem value="TEXT">Short Answer (Text)</SelectItem>
              <SelectItem value="CODE">Coding Challenge</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Points */}
        <div>
          <Label htmlFor="points">Points</Label>
          <Input
            id="points"
            type="number"
            value={formData.points}
            onChange={(e) =>
              setFormData({ ...formData, points: Number(e.target.value) })
            }
            min="0"
            className="mt-2"
          />
        </div>

        {/* Question Text */}
        <div className="col-span-2">
          <Label htmlFor="question">Question Text</Label>
          <Textarea
            id="question"
            value={formData.question}
            onChange={(e) =>
              setFormData({ ...formData, question: e.target.value })
            }
            required
            rows={3}
            placeholder="What is the output of..."
            className="mt-2"
          />
        </div>

        {/* Dynamic Fields based on Type */}
        {["MULTIPLE_CHOICE"].includes(formData.questionType) && (
          <div className="col-span-2 space-y-4">
            <Label>Options</Label>
            {Object.entries(formData.options).map(([key, value], index) => (
              <div key={key} className="flex items-center gap-3">
                <span className="text-text-tertiary w-6 text-center">
                  {index + 1}.
                </span>
                <Input
                  type="text"
                  value={value}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      options: { ...formData.options, [key]: e.target.value },
                    })
                  }
                  placeholder={`Option ${index + 1}`}
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeOption(key)}
                  className="text-text-tertiary hover:text-red-500"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                {formData.questionType === "MULTIPLE_CHOICE" && (
                  <input
                    type="radio"
                    name="correctAnswer"
                    checked={formData.correctAnswer === key}
                    onChange={() =>
                      setFormData({ ...formData, correctAnswer: key })
                    }
                    className="h-4 w-4 text-accent focus:ring-accent"
                  />
                )}
              </div>
            ))}
            <Button
              type="button"
              variant="ghost"
              onClick={addOption}
              className="text-sm"
            >
              <Plus className="h-4 w-4" /> Add Option
            </Button>
          </div>
        )}

        {/* Explanation */}
        <div className="col-span-2">
          <Label htmlFor="explanation">Explanation (Optional)</Label>
          <Textarea
            id="explanation"
            value={formData.explanation}
            onChange={(e) =>
              setFormData({ ...formData, explanation: e.target.value })
            }
            rows={2}
            placeholder="Explain why the answer is correct..."
            className="mt-2"
          />
        </div>
      </div>

      <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
        <Button type="button" variant="ghost" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4" />
              Save Question
            </>
          )}
        </Button>
      </div>
    </form>
  );
}
