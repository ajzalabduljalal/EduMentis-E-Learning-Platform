import { requireInstructor } from "@repo/auth";
import { prisma, QuizType } from "@repo/db";
import Link from "next/link";
import { ArrowLeft, Brain, Award } from "lucide-react";
import { QuizForm } from "./components/QuizForm";

export default async function QuizzesPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  await requireInstructor();
  const { id: courseId } = await params;

  const course = await prisma.course.findUnique({
    where: { id: courseId },
    select: { title: true, entryQuizId: true, finalExamId: true },
  });

  if (!course) return null;

  const quizzes = await prisma.quiz.findMany({
    where: { courseId },
    orderBy: { createdAt: "desc" },
    include: {
      _count: {
        select: { questions: true },
      },
    },
  });

  const entryQuiz = quizzes.find((q) => q.quizType === QuizType.ENTRY_QUIZ);
  const finalExam = quizzes.find((q) => q.quizType === QuizType.FINAL_EXAM);

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-5xl px-6 py-8">
          <Link
            href={`/courses/${courseId}/edit`}
            className="inline-flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-smooth mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Course
          </Link>
          <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
            Quizzes & Exams
          </h1>
          <p className="mt-2 text-sm text-text-secondary">
            Manage entry placement quizzes and final certification exams
          </p>
        </div>
      </div>

      <div className="mx-auto max-w-5xl px-6 py-8 space-y-8">
        {/* Entry Quiz Section */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-text-primary flex items-center gap-2">
              <Brain className="h-5 w-5 text-accent" />
              Entry Placement Quiz
            </h2>
          </div>

          {entryQuiz ? (
            <QuizCard quiz={entryQuiz} courseId={courseId} />
          ) : (
            <div className="rounded-lg border border-dashed border-border p-8 text-center bg-bg-secondary/30">
              <p className="text-text-secondary mb-4">
                No entry quiz created. Create one to allow students to skip
                basics.
              </p>
              <QuizForm courseId={courseId} initialType="ENTRY_QUIZ" />
            </div>
          )}
        </section>

        <hr className="border-border" />

        {/* Final Exam Section */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-text-primary flex items-center gap-2">
              <Award className="h-5 w-5 text-accent" />
              Final Certification Exam
            </h2>
          </div>

          {finalExam ? (
            <QuizCard quiz={finalExam} courseId={courseId} />
          ) : (
            <div className="rounded-lg border border-dashed border-border p-8 text-center bg-bg-secondary/30">
              <p className="text-text-secondary mb-4">
                No final exam created. Students need this to get certified.
              </p>
              <QuizForm courseId={courseId} initialType="FINAL_EXAM" />
            </div>
          )}
        </section>
      </div>
    </div>
  );
}

function QuizCard({ quiz, courseId }: { quiz: any; courseId: string }) {
  return (
    <div className="group flex items-center justify-between p-6 rounded-lg border border-border bg-bg-primary hover:border-accent transition-smooth">
      <div>
        <h3 className="text-lg font-medium text-text-primary">{quiz.title}</h3>
        <p className="text-sm text-text-secondary line-clamp-1 mt-1">
          {quiz.description || "No description"}
        </p>
        <div className="flex items-center gap-4 mt-2 text-xs text-text-tertiary">
          <span>{quiz._count.questions} Questions</span>
          <span>
            {quiz.timeLimit ? `${quiz.timeLimit} mins` : "No time limit"}
          </span>
          <span>Pass: {quiz.passingScore}%</span>
        </div>
      </div>
      <Link
        href={`/courses/${courseId}/quizzes/${quiz.id}/edit`}
        className="px-4 py-2 rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 transition-smooth font-medium text-sm"
      >
        Edit Quiz
      </Link>
    </div>
  );
}
