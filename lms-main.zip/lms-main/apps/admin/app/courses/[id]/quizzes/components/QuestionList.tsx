"use client";

import { useState } from "react";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import {
  GripVertical,
  Pencil,
  Trash2,
  ListChecks,
  CheckSquare,
} from "lucide-react";
import type { Question } from "@repo/types";

type QuestionType = "MULTIPLE_CHOICE" | "TEXT" | "CODE" | "FILE_UPLOAD";

interface QuestionListProps {
  questions: Question[];
  onEdit: (question: Question) => void;
  onDelete: (questionId: string) => void;
  onReorder: (questions: Question[]) => void;
}

interface SortableQuestionProps {
  question: Question;
  onEdit: (question: Question) => void;
  onDelete: (questionId: string) => void;
}

const questionTypeStylesMap: Record<
  QuestionType,
  { label: string; color: string }
> = {
  MULTIPLE_CHOICE: {
    label: "Multiple Choice",
    color: "bg-blue-100 text-blue-700",
  },
  TEXT: { label: "Text", color: "bg-green-100 text-green-700" },
  CODE: { label: "Code", color: "bg-gray-100 text-gray-700" },
  FILE_UPLOAD: { label: "File Upload", color: "bg-yellow-100 text-yellow-700" },
};

function SortableQuestion({
  question,
  onEdit,
  onDelete,
}: {
  question: Question;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition } =
    useSortable({ id: question.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const TypeBadge = questionTypeStylesMap[
    question.questionType as QuestionType
  ] || {
    label: "Unknown",
    color: "bg-gray-100 text-text-tertiary",
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-4 p-4 bg-bg-primary border border-border rounded-lg group hover:border-accent transition-smooth"
    >
      <button
        {...attributes}
        {...listeners}
        className="text-text-tertiary hover:text-text-primary cursor-grab active:cursor-grabbing"
      >
        <GripVertical className="h-5 w-5" />
      </button>

      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <span
            className={`text-xs px-2 py-0.5 rounded font-medium ${TypeBadge.color}`}
          >
            {TypeBadge.label}
          </span>
          <span className="text-xs text-text-tertiary">
            {question.points} pts
          </span>
        </div>
        <p className="text-sm font-medium text-text-primary line-clamp-1">
          {question.question}
        </p>
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={onEdit}
          className="p-2 rounded-lg hover:bg-bg-secondary text-text-secondary hover:text-text-primary transition-smooth"
        >
          <Pencil className="h-4 w-4" />
        </button>
        <button
          onClick={onDelete}
          className="p-2 rounded-lg hover:bg-red-50 text-text-secondary hover:text-red-600 transition-smooth"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function QuestionList({
  questions,
  onEdit,
  onDelete,
  onReorder,
}: QuestionListProps) {
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  function handleDragEnd(event: DragEndEvent) {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = questions.findIndex((q) => q.id === active.id);
      const newIndex = questions.findIndex((q) => q.id === over.id);

      const newOrder = arrayMove(questions, oldIndex, newIndex);
      onReorder(newOrder);
    }
  }

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <SortableContext
        items={questions.map((q) => q.id)}
        strategy={verticalListSortingStrategy}
      >
        <div className="space-y-3">
          {questions.map((question) => (
            <SortableQuestion
              key={question.id}
              question={question}
              onEdit={() => onEdit(question)}
              onDelete={() => onDelete(question.id)}
            />
          ))}
        </div>
      </SortableContext>
    </DndContext>
  );
}
