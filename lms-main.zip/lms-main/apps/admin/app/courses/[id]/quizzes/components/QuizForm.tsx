"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Brain,
  Settings,
  Clock,
  Award,
  RotateCcw,
  Shuffle,
  Save,
  Loader2,
} from "lucide-react";
import type { QuizWithDetails, CreateQuizInput } from "@repo/types";
import { useToast } from "@repo/ui/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";

type QuizType = "ENTRY_QUIZ" | "LESSON_QUIZ" | "FINAL_EXAM" | "PRACTICE";

// Helper to handle enum if not available on client
const QUIZ_TYPES = {
  ENTRY_QUIZ: "ENTRY_QUIZ",
  LESSON_QUIZ: "LESSON_QUIZ",
  FINAL_EXAM: "FINAL_EXAM",
  PRACTICE: "PRACTICE",
};

interface QuizFormProps {
  courseId: string;
  quiz?: QuizWithDetails;
  // Initial type for create mode
  initialType?: "ENTRY_QUIZ" | "FINAL_EXAM";
}

export function QuizForm({ courseId, quiz, initialType }: QuizFormProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    title: quiz?.title || "",
    description: quiz?.description || "",
    quizType: (quiz?.quizType || initialType || "LESSON_QUIZ") as string,
    passingScore: quiz?.passingScore || 70,
    maxAttempts: quiz?.maxAttempts || 3,
    timeLimit: quiz?.timeLimit || 60,
    isRandomized: quiz?.isRandomized ?? false,
  });

  const isEditing = !!quiz;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const url = isEditing
        ? `/api/courses/${courseId}/quizzes/${quiz.id}`
        : `/api/courses/${courseId}/quizzes`;

      const method = isEditing ? "PUT" : "POST";

      const payload = {
        ...formData,
        passingScore: Number(formData.passingScore),
        maxAttempts: Number(formData.maxAttempts),
        timeLimit: formData.timeLimit ? Number(formData.timeLimit) : undefined,
        courseId: !isEditing ? courseId : undefined,
      };

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          variant: "success",
          title: isEditing
            ? "Quiz updated successfully"
            : "Quiz created successfully",
          description: isEditing
            ? "Your quiz settings have been saved."
            : "You can now add questions to your quiz.",
        });
        if (!isEditing) {
          // Redirect to edit page to add questions
          router.push(`/courses/${courseId}/quizzes/${data.data.id}/edit`);
        } else {
          router.refresh();
        }
      } else {
        setError(data.error || "Failed to save quiz");
        toast({
          variant: "destructive",
          title: "Failed to save quiz",
          description: data.error || "An error occurred while saving the quiz.",
        });
      }
    } catch (err) {
      console.error(err);
      setError("Failed to save quiz");
      toast({
        variant: "destructive",
        title: "Failed to save quiz",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8 max-w-3xl">
      {error && (
        <div className="rounded-lg bg-red-50 p-4 text-sm text-red-600 border border-red-200">
          {error}
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        {/* Basic Info */}
        <div className="col-span-2 space-y-4">
          <h3 className="text-lg font-medium text-text-primary flex items-center gap-2">
            <Brain className="h-5 w-5 text-accent" />
            Basic Information
          </h3>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Quiz Title
            </label>
            <input
              type="text"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              required
              className="w-full rounded-lg border border-border bg-bg-primary px-4 py-2 text-text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
              placeholder="e.g., Final Certification Exam"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Description
            </label>
            <textarea
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              rows={3}
              className="w-full rounded-lg border border-border bg-bg-primary px-4 py-2 text-text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
              placeholder="Describe what this quiz covers..."
            />
          </div>
        </div>

        {/* Settings */}
        <div className="col-span-2 space-y-4 pt-4 border-t border-border">
          <h3 className="text-lg font-medium text-text-primary flex items-center gap-2">
            <Settings className="h-5 w-5 text-accent" />
            Quiz Settings
          </h3>

          <div className="grid gap-6 md:grid-cols-2">
            {/* Type (ReadOnly if editing or fixed initial) */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2">
                Quiz Type
              </label>
              <Select
                value={formData.quizType}
                onValueChange={(value) =>
                  setFormData({ ...formData, quizType: value })
                }
                disabled={isEditing || !!initialType}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select quiz type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ENTRY_QUIZ">
                    Entry Quiz (Placement)
                  </SelectItem>
                  <SelectItem value="FINAL_EXAM">
                    Final Exam (Certification)
                  </SelectItem>
                  <SelectItem value="LESSON_QUIZ">
                    Lesson Quiz (Practice)
                  </SelectItem>
                  <SelectItem value="PRACTICE">General Practice</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Passing Score */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2 flex items-center gap-2">
                <Award className="h-4 w-4 text-text-tertiary" />
                Passing Score (%)
              </label>
              <input
                type="number"
                value={formData.passingScore}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    passingScore: Number(e.target.value),
                  })
                }
                min="0"
                max="100"
                required
                className="w-full rounded-lg border border-border bg-bg-primary px-4 py-2 text-text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
              />
            </div>

            {/* Time Limit */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2 flex items-center gap-2">
                <Clock className="h-4 w-4 text-text-tertiary" />
                Time Limit (minutes)
              </label>
              <input
                type="number"
                value={formData.timeLimit}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    timeLimit: Number(e.target.value),
                  })
                }
                min="1"
                className="w-full rounded-lg border border-border bg-bg-primary px-4 py-2 text-text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
                placeholder="e.g. 60 (Leave empty for no limit)"
              />
              <p className="mt-1 text-xs text-text-secondary">
                0 or empty for no limit
              </p>
            </div>

            {/* Max Attempts */}
            <div>
              <label className="block text-sm font-medium text-text-primary mb-2 flex items-center gap-2">
                <RotateCcw className="h-4 w-4 text-text-tertiary" />
                Max Attempts
              </label>
              <input
                type="number"
                value={formData.maxAttempts}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    maxAttempts: Number(e.target.value),
                  })
                }
                min="1"
                required
                className="w-full rounded-lg border border-border bg-bg-primary px-4 py-2 text-text-primary focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/20"
              />
            </div>
          </div>

          {/* Checkboxes */}
          <div className="flex items-center gap-2 pt-2">
            <input
              type="checkbox"
              id="isRandomized"
              checked={formData.isRandomized}
              onChange={(e) =>
                setFormData({ ...formData, isRandomized: e.target.checked })
              }
              className="h-4 w-4 rounded border-border text-accent focus:ring-accent"
            />
            <label
              htmlFor="isRandomized"
              className="text-sm font-medium text-text-primary flex items-center gap-2"
            >
              <Shuffle className="h-4 w-4 text-text-tertiary" />
              Randomize Question Order
            </label>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center justify-end gap-3 pt-4 border-t border-border">
        {isEditing && (
          <button
            type="button"
            onClick={() => router.back()}
            className="rounded-lg border border-border bg-bg-primary px-6 py-2 text-sm font-medium text-text-primary hover:bg-bg-secondary transition-smooth"
          >
            Cancel
          </button>
        )}
        <button
          type="submit"
          disabled={loading}
          className="inline-flex items-center gap-2 rounded-lg bg-zinc-900 px-6 py-2 text-sm font-medium text-white hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed transition-smooth"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="h-4 w-4" />
              {isEditing ? "Save Settings" : "Create Quiz"}
            </>
          )}
        </button>
      </div>
    </form>
  );
}
