"use client";

import { useState } from "react";
import { Sparkles, Loader2 } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { useRouter } from "next/navigation";
import { useToast } from "@repo/ui/hooks/use-toast";

interface GenerateQuizButtonProps {
  lessonId?: string;
  courseId: string;
  onSuccess?: (quizId: string) => void;
}

export function GenerateQuizButton({
  lessonId,
  courseId,
  onSuccess,
}: GenerateQuizButtonProps) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const handleGenerate = async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/ai/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lessonId,
          numQuestions: 5,
          difficulty: "medium",
          saveToDatabase: true,
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          variant: "success",
          title: "Quiz generated successfully",
          description:
            "The AI has generated quiz questions based on the lesson content.",
        });
        if (onSuccess) {
          onSuccess(data.data.saved.quizId);
        } else {
          router.refresh();
        }
      } else {
        setError(data.error || "Failed to generate quiz");
        toast({
          variant: "destructive",
          title: "Failed to generate quiz",
          description:
            data.error || "An error occurred while generating the quiz.",
        });
      }
    } catch (err) {
      setError("An error occurred while generating the quiz");
      toast({
        variant: "destructive",
        title: "Failed to generate quiz",
        description: "An unexpected error occurred. Please try again.",
      });
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Button
        type="button"
        variant="outline"
        onClick={handleGenerate}
        disabled={loading}
        className="gap-2"
      >
        {loading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            Generating...
          </>
        ) : (
          <>
            <Sparkles className="h-4 w-4" />
            Generate with AI
          </>
        )}
      </Button>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>
  );
}
