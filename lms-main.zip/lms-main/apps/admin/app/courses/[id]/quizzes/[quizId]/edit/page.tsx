"use client";

import { useState, useEffect } from "react";
import { QuizForm } from "../../components/QuizForm";
import { QuestionList } from "../../components/QuestionList";
import { QuestionEditor } from "../../components/QuestionEditor";
import { useRouter } from "next/navigation";
import { ArrowLeft, Settings, ListChecks, Plus, Loader2 } from "lucide-react";
import type { QuizWithDetails, Question } from "@repo/types";

export default function QuizEditPage({
  params,
}: {
  params: Promise<{ id: string; quizId: string }>;
}) {
  // Unwrapping params
  const [unwrappedParams, setUnwrappedParams] = useState<{
    id: string;
    quizId: string;
  } | null>(null);
  const [activeTab, setActiveTab] = useState<"settings" | "questions">(
    "questions",
  );
  const [quiz, setQuiz] = useState<
    (QuizWithDetails & { questions: Question[] }) | null
  >(null);
  const [loading, setLoading] = useState(true);

  // Editor State
  const [editingQuestion, setEditingQuestion] = useState<Question | undefined>(
    undefined,
  );
  const [isEditorOpen, setIsEditorOpen] = useState(false);

  useEffect(() => {
    params.then(setUnwrappedParams);
  }, [params]);

  useEffect(() => {
    if (unwrappedParams) {
      fetchQuiz();
    }
  }, [unwrappedParams]);

  const fetchQuiz = async () => {
    if (!unwrappedParams) return;
    try {
      const res = await fetch(
        `/api/courses/${unwrappedParams.id}/quizzes/${unwrappedParams.quizId}`,
      );
      const data = await res.json();
      if (data.success) {
        setQuiz(data.data);
      }
    } catch (error) {
      console.error("Failed to fetch quiz", error);
    } finally {
      setLoading(false);
    }
  };

  const handleReorder = async (questions: Question[]) => {
    if (!unwrappedParams) return;
    // Optimistic update
    if (quiz) {
      setQuiz({ ...quiz, questions });
    }

    try {
      await fetch(
        `/api/courses/${unwrappedParams.id}/quizzes/${unwrappedParams.quizId}/questions/reorder`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            questions: questions.map((q, i) => ({ id: q.id, orderIndex: i })),
          }),
        },
      );
    } catch (error) {
      console.error("Failed to reorder", error);
      // Revert?
      fetchQuiz();
    }
  };

  const handleDeleteQuestion = async (questionId: string) => {
    if (
      !unwrappedParams ||
      !confirm("Are you sure you want to delete this question?")
    )
      return;

    try {
      await fetch(
        `/api/courses/${unwrappedParams.id}/quizzes/${unwrappedParams.quizId}/questions/${questionId}`,
        {
          method: "DELETE",
        },
      );
      fetchQuiz();
    } catch (error) {
      console.error("Failed to delete", error);
    }
  };

  const handleEditQuestion = (question: Question) => {
    setEditingQuestion(question);
    setIsEditorOpen(true);
  };

  const handleAddQuestion = () => {
    setEditingQuestion(undefined);
    setIsEditorOpen(true);
  };

  const handleEditorClose = () => {
    setIsEditorOpen(false);
    setEditingQuestion(undefined);
  };

  const handleEditorSave = () => {
    handleEditorClose();
    fetchQuiz();
  };

  if (!unwrappedParams || loading) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-accent mx-auto mb-4" />
          <p className="text-sm text-text-secondary">Loading quiz...</p>
        </div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center">
        <div className="text-center">
          <p className="text-lg font-medium text-text-primary mb-2">
            Quiz not found
          </p>
          <p className="text-sm text-text-secondary">
            The quiz you're looking for doesn't exist or you don't have access
            to it.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary sticky top-0 z-10">
        <div className="mx-auto max-w-5xl px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => window.history.back()}
                className="p-2 -ml-2 text-text-secondary hover:text-text-primary rounded-full hover:bg-bg-secondary transition-smooth"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <div>
                <h1 className="text-xl font-semibold text-text-primary">
                  {quiz.title}
                </h1>
                <p className="text-sm text-text-secondary">
                  {quiz.quizType === "ENTRY_QUIZ"
                    ? "Entry Placement Quiz"
                    : quiz.quizType === "FINAL_EXAM"
                      ? "Final Certification Exam"
                      : "Quiz"}
                </p>
              </div>
            </div>
            <div className="flex bg-bg-secondary p-1 rounded-lg">
              <button
                onClick={() => setActiveTab("questions")}
                className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                  activeTab === "questions"
                    ? "bg-bg-primary text-text-primary shadow-sm"
                    : "text-text-secondary hover:text-text-primary"
                }`}
              >
                <div className="flex items-center gap-2">
                  <ListChecks className="h-4 w-4" />
                  Questions
                </div>
              </button>
              <button
                onClick={() => setActiveTab("settings")}
                className={`px-4 py-1.5 text-sm font-medium rounded-md transition-all ${
                  activeTab === "settings"
                    ? "bg-bg-primary text-text-primary shadow-sm"
                    : "text-text-secondary hover:text-text-primary"
                }`}
              >
                <div className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Settings
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-5xl px-6 py-8">
        {activeTab === "settings" ? (
          <QuizForm courseId={unwrappedParams.id} quiz={quiz} />
        ) : (
          <div className="space-y-6">
            {isEditorOpen ? (
              <QuestionEditor
                quizId={quiz.id}
                courseId={unwrappedParams.id}
                question={editingQuestion}
                onSave={handleEditorSave}
                onCancel={handleEditorClose}
              />
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-medium text-text-primary">
                    Questions ({quiz.questions.length})
                  </h2>
                  <button
                    onClick={handleAddQuestion}
                    className="inline-flex items-center gap-2 rounded-lg bg-zinc-900 px-4 py-2 text-sm font-medium text-white hover:bg-zinc-800 transition-smooth"
                  >
                    <Plus className="h-4 w-4" />
                    Add Question
                  </button>
                </div>

                {quiz.questions.length > 0 ? (
                  <QuestionList
                    questions={quiz.questions}
                    onEdit={handleEditQuestion}
                    onDelete={handleDeleteQuestion}
                    onReorder={handleReorder}
                  />
                ) : (
                  <div className="rounded-lg border border-dashed border-border p-12 text-center">
                    <p className="text-text-tertiary">
                      No questions yet. Add one to get started.
                    </p>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
