import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { ModuleList } from "./components/ModuleList";

export default async function ModulesPage({
    params,
}: {
    params: Promise<{ id: string }>;
}) {
    await requireInstructor();
    const { id } = await params;

    // Get course details
    const course = await prisma.course.findUnique({
        where: { id },
        select: {
            id: true,
            title: true,
            slug: true,
        },
    });

    if (!course) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <p className="text-text-secondary">Course not found</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-bg-primary">
            {/* Header */}
            <div className="border-b border-border bg-bg-primary">
                <div className="mx-auto max-w-7xl px-6 py-6">
                    <Link
                        href={`/courses/${id}/edit`}
                        className="inline-flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-smooth mb-4"
                    >
                        <ArrowLeft className="h-4 w-4" />
                        Back to Course
                    </Link>
                    <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
                        Modules: {course.title}
                    </h1>
                    <p className="mt-2 text-sm text-text-secondary">
                        Manage course modules and organize your content
                    </p>
                </div>
            </div>

            {/* Module List */}
            <div className="mx-auto max-w-7xl px-6 py-8">
                <ModuleList courseId={course.id} />
            </div>
        </div>
    );
}
