"use client";

import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Link from "@tiptap/extension-link";
import Image from "@tiptap/extension-image";
import CodeBlockLowlight from "@tiptap/extension-code-block-lowlight";
import { common, createLowlight } from "lowlight";
import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bold,
  Italic,
  List,
  ListOrdered,
  Quote,
  Undo,
  Redo,
  Code,
  Link as LinkIcon,
  Image as ImageIcon,
  Heading1,
  Heading2,
  Sparkles,
  Loader2,
} from "lucide-react";
import { useToast } from "@repo/ui/hooks/use-toast";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Label } from "@repo/ui/components/label";

const lowlight = createLowlight(common);

interface LessonEditorProps {
  mode: "create" | "edit";
  courseId: string;
  moduleId: string;
  lesson?: {
    id: string;
    title: string;
    content: string;
    track: "BASIC" | "ADVANCED" | "BOTH";
    type: "TEXT" | "INTERACTIVE" | "CODING";
    duration?: number | null;
    isFree?: boolean;
    hasQuiz?: boolean;
    quizQuestionsCount?: number;
  };
}

export function LessonEditor({
  mode,
  courseId,
  moduleId,
  lesson,
}: LessonEditorProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [generatingQuiz, setGeneratingQuiz] = useState(false);
  const [generatedQuiz, setGeneratedQuiz] = useState<any>(null);
  const [savingQuiz, setSavingQuiz] = useState(false);

  const [formData, setFormData] = useState({
    title: lesson?.title || "",
    track: lesson?.track || "BOTH",
    type: lesson?.type || "TEXT",
    duration: lesson?.duration || "",
    isFree: lesson?.isFree || false,
  });

  const editor = useEditor({
    immediatelyRender: false,
    extensions: [
      StarterKit,
      Link.configure({
        openOnClick: false,
      }),
      Image,
      CodeBlockLowlight.configure({
        lowlight,
      }),
    ],
    content: lesson?.content || "",
    editorProps: {
      attributes: {
        class:
          "prose prose-zinc prose-lg max-w-none focus:outline-none min-h-[300px] p-4 [&>h1]:text-2xl [&>h1]:font-semibold [&>h1]:mb-4 [&>h2]:text-xl [&>h2]:font-semibold [&>h2]:mb-3 [&>h3]:text-lg [&>h3]:font-semibold [&>h3]:mb-2 [&>p]:mb-4 [&>p]:leading-relaxed [&>ul]:mb-4 [&>ol]:mb-4 [&>pre]:bg-zinc-900 [&>pre]:text-zinc-100 [&>pre]:p-4 [&>pre]:rounded-lg [&>pre]:overflow-x-auto [&>code]:text-sm [&>code]:bg-zinc-100 [&>code]:px-1.5 [&>code]:py-0.5 [&>code]:rounded [&>blockquote]:border-l-4 [&>blockquote]:border-zinc-300 [&>blockquote]:pl-4 [&>blockquote]:italic",
      },
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    if (!editor) return;

    try {
      const url =
        mode === "create"
          ? `/api/courses/${courseId}/modules/${moduleId}/lessons`
          : `/api/courses/${courseId}/modules/${moduleId}/lessons/${lesson?.id}`;

      const method = mode === "create" ? "POST" : "PUT";

      const payload = {
        ...formData,
        content: editor.getHTML(),
        duration: formData.duration ? Number(formData.duration) : undefined,
        moduleId: mode === "create" ? moduleId : undefined,
        lessonType: formData.type, // Map type to lessonType for API
      };

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (data.success) {
        router.push(`/courses/${courseId}/modules/${moduleId}/lessons`);
        router.refresh();
      } else {
        setError(data.error || "Failed to save lesson");
      }
    } catch (err) {
      console.error(err);
      setError("Failed to save lesson");
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateQuiz = async () => {
    if (!lesson?.id) {
      setError("Please save the lesson first before generating a quiz");
      return;
    }

    setGeneratingQuiz(true);
    setError(null);

    try {
      const response = await fetch("/api/ai/generate-quiz", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          lessonId: lesson.id,
          numQuestions: 5,
          difficulty: "medium",
          saveToDatabase: false,
        }),
      });

      const data = await response.json();

      if (data.success) {
        setGeneratedQuiz(data.data.generated);
      } else {
        setError(data.error || "Failed to generate quiz");
      }
    } catch (err) {
      console.error(err);
      setError("Failed to generate quiz");
    } finally {
      setGeneratingQuiz(false);
    }
  };

  if (!editor) {
    return null;
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {error && (
        <div className="rounded-lg bg-red-50 p-4 text-sm text-red-600 border border-red-200">
          {error}
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-2">
        {/* Title */}
        <div className="col-span-2">
          <Label htmlFor="title">Lesson Title</Label>
          <Input
            id="title"
            type="text"
            value={formData.title}
            onChange={(e) =>
              setFormData({ ...formData, title: e.target.value })
            }
            required
            placeholder="e.g., Introduction to React"
            className="mt-2"
          />
        </div>

        {/* Track */}
        <div>
          <Label htmlFor="track">Track</Label>
          <Select
            value={formData.track}
            onValueChange={(value) =>
              setFormData({ ...formData, track: value as any })
            }
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select track" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="BASIC">Basic</SelectItem>
              <SelectItem value="ADVANCED">Advanced</SelectItem>
              <SelectItem value="BOTH">Both</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Type */}
        <div>
          <Label htmlFor="type">Lesson Type</Label>
          <Select
            value={formData.type}
            onValueChange={(value) =>
              setFormData({ ...formData, type: value as any })
            }
          >
            <SelectTrigger className="w-full mt-2">
              <SelectValue placeholder="Select lesson type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="TEXT">Text</SelectItem>
              <SelectItem value="INTERACTIVE">Interactive</SelectItem>
              <SelectItem value="CODING">Coding</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Duration */}
        <div>
          <Label htmlFor="duration">Duration (minutes)</Label>
          <Input
            id="duration"
            type="number"
            value={formData.duration}
            onChange={(e) =>
              setFormData({ ...formData, duration: e.target.value })
            }
            placeholder="e.g., 15"
            className="mt-2"
          />
        </div>

        {/* Is Free */}
        <div className="flex items-center gap-2 pt-8">
          <input
            type="checkbox"
            id="isFree"
            checked={formData.isFree}
            onChange={(e) =>
              setFormData({ ...formData, isFree: e.target.checked })
            }
            className="h-4 w-4 rounded border-border text-accent focus:ring-accent"
          />
          <Label htmlFor="isFree">Free Preview Lesson</Label>
        </div>
      </div>

      {/* Rich Text Editor */}
      <div className="rounded-lg border border-border bg-bg-primary overflow-hidden">
        <div className="border-b border-border bg-bg-secondary p-2 flex flex-wrap gap-1">
          <EditorButton
            onClick={() => editor.chain().focus().toggleBold().run()}
            isActive={editor.isActive("bold")}
            icon={Bold}
            title="Bold"
          />
          <EditorButton
            onClick={() => editor.chain().focus().toggleItalic().run()}
            isActive={editor.isActive("italic")}
            icon={Italic}
            title="Italic"
          />
          <div className="w-px h-6 bg-border mx-1 my-auto" />
          <EditorButton
            onClick={() =>
              editor.chain().focus().toggleHeading({ level: 1 }).run()
            }
            isActive={editor.isActive("heading", { level: 1 })}
            icon={Heading1}
            title="Heading 1"
          />
          <EditorButton
            onClick={() =>
              editor.chain().focus().toggleHeading({ level: 2 }).run()
            }
            isActive={editor.isActive("heading", { level: 2 })}
            icon={Heading2}
            title="Heading 2"
          />
          <div className="w-px h-6 bg-border mx-1 my-auto" />
          <EditorButton
            onClick={() => editor.chain().focus().toggleBulletList().run()}
            isActive={editor.isActive("bulletList")}
            icon={List}
            title="Bullet List"
          />
          <EditorButton
            onClick={() => editor.chain().focus().toggleOrderedList().run()}
            isActive={editor.isActive("orderedList")}
            icon={ListOrdered}
            title="Ordered List"
          />
          <div className="w-px h-6 bg-border mx-1 my-auto" />
          <EditorButton
            onClick={() => editor.chain().focus().toggleBlockquote().run()}
            isActive={editor.isActive("blockquote")}
            icon={Quote}
            title="Quote"
          />
          <EditorButton
            onClick={() => editor.chain().focus().toggleCodeBlock().run()}
            isActive={editor.isActive("codeBlock")}
            icon={Code}
            title="Code Block"
          />
          <div className="w-px h-6 bg-border mx-1 my-auto" />
          <EditorButton
            onClick={() => {
              const url = window.prompt("URL");
              if (url) {
                editor.chain().focus().setLink({ href: url }).run();
              }
            }}
            isActive={editor.isActive("link")}
            icon={LinkIcon}
            title="Link"
          />
          <EditorButton
            onClick={() => {
              const url = window.prompt("Image URL");
              if (url) {
                editor.chain().focus().setImage({ src: url }).run();
              }
            }}
            isActive={false}
            icon={ImageIcon}
            title="Image"
          />
        </div>
        <div className="p-4 min-h-[400px]">
          <EditorContent editor={editor} />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between pt-4">
        <div className="flex items-center gap-3">
          {mode === "edit" && lesson?.id && (
            <Button
              type="button"
              variant="outline"
              onClick={handleGenerateQuiz}
              disabled={generatingQuiz}
            >
              <Sparkles className="h-4 w-4" />
              {generatingQuiz
                ? "Generating..."
                : lesson.hasQuiz
                  ? `Regenerate Quiz (${lesson.quizQuestionsCount} questions)`
                  : "Generate Quiz with AI"}
            </Button>
          )}
        </div>
        <div className="flex items-center gap-3">
          <Button type="button" variant="outline" onClick={() => router.back()}>
            Cancel
          </Button>
          <Button type="submit" disabled={loading}>
            {loading
              ? "Saving..."
              : mode === "create"
                ? "Create Lesson"
                : "Save Changes"}
          </Button>
        </div>
      </div>

      {/* Generated Quiz Preview */}
      {generatedQuiz && (
        <div className="mt-8 rounded-lg border border-accent-light bg-accent-light/30 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-text-primary">
              AI Generated Quiz
            </h3>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              onClick={() => setGeneratedQuiz(null)}
            >
              ✕
            </Button>
          </div>
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-text-primary">
                {generatedQuiz.title}
              </h4>
              <p className="text-sm text-text-secondary">
                {generatedQuiz.description}
              </p>
            </div>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {generatedQuiz.questions?.map((q: any, idx: number) => (
                <div
                  key={idx}
                  className="p-3 bg-white rounded border border-border"
                >
                  <p className="font-medium text-gray-900">
                    {idx + 1}. {q.question}
                  </p>
                  <div className="mt-2 space-y-1 text-sm">
                    {Object.entries(q.options || {}).map(
                      ([key, value]: [string, any]) => (
                        <div
                          key={key}
                          className={
                            q.correctAnswer === key
                              ? "text-green-600 font-medium"
                              : "text-gray-600"
                          }
                        >
                          {key}: {value}
                          {q.correctAnswer === key && " ✓"}
                        </div>
                      ),
                    )}
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-3 pt-2">
              <Button
                type="button"
                onClick={async () => {
                  setSavingQuiz(true);
                  try {
                    const response = await fetch("/api/ai/generate-quiz", {
                      method: "POST",
                      headers: { "Content-Type": "application/json" },
                      body: JSON.stringify({
                        lessonId: lesson?.id,
                        numQuestions: 5,
                        difficulty: "medium",
                        saveToDatabase: true,
                      }),
                    });
                    const data = await response.json();
                    if (data.success) {
                      toast({
                        variant: "success",
                        title: "Quiz saved successfully",
                        description: `${data.data.saved.quizTitle} has been saved to the lesson.`,
                      });
                      setGeneratedQuiz(null);
                    } else {
                      toast({
                        variant: "destructive",
                        title: "Failed to save quiz",
                        description:
                          data.error ||
                          "An error occurred while saving the quiz.",
                      });
                    }
                  } catch (err) {
                    toast({
                      variant: "destructive",
                      title: "Failed to save quiz",
                      description:
                        "An unexpected error occurred. Please try again.",
                    });
                  } finally {
                    setSavingQuiz(false);
                  }
                }}
                disabled={savingQuiz}
              >
                {savingQuiz ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Quiz"
                )}
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => setGeneratedQuiz(null)}
              >
                Dismiss
              </Button>
            </div>
          </div>
        </div>
      )}
    </form>
  );
}

function EditorButton({
  onClick,
  isActive,
  icon: Icon,
  title,
}: {
  onClick: () => void;
  isActive: boolean;
  icon: any;
  title: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      title={title}
      className={`p-2 rounded hover:bg-bg-tertiary transition-smooth ${
        isActive
          ? "bg-accent/10 text-text-primary font-semibold"
          : "text-text-secondary"
      }`}
    >
      <Icon className="h-4 w-4" />
    </button>
  );
}
