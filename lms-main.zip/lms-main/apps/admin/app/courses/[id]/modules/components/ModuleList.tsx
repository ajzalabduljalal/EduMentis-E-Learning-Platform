"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Plus, GripVertical, Pencil, Trash2, BookOpen } from "lucide-react";
import type { ModuleWithStats } from "@repo/types";
import { ModuleDialog } from "./ModuleDialog";
import { Button } from "@repo/ui/components/button";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface ModuleListProps {
  courseId: string;
}

function SortableModule({
  module,
  onEdit,
  onDelete,
}: {
  module: ModuleWithStats;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: module.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const trackColors = {
    BASIC: "bg-blue-100 text-blue-800",
    ADVANCED: "bg-purple-100 text-purple-800",
    BOTH: "bg-green-100 text-green-800",
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="group flex items-center gap-4 rounded-lg border border-border bg-bg-primary p-4 hover:border-accent transition-smooth"
    >
      {/* Drag Handle */}
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing text-text-tertiary hover:text-text-primary"
      >
        <GripVertical className="h-5 w-5" />
      </button>

      {/* Module Info */}
      <div className="flex-1">
        <h3 className="text-sm font-medium text-text-primary">
          {module.title}
        </h3>
        {module.description && (
          <p className="text-sm text-text-secondary mt-1">
            {module.description}
          </p>
        )}
        <div className="flex items-center gap-3 mt-2">
          <span
            className={`px-2 py-0.5 rounded text-xs font-medium ${trackColors[module.track]}`}
          >
            {module.track}
          </span>
          <span className="text-xs text-text-tertiary">
            {module._count?.lessons || 0} lessons
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <Link
          href={`/courses/${module.courseId}/modules/${module.id}/lessons`}
          className="p-2 rounded-lg hover:bg-bg-secondary text-text-secondary hover:text-text-primary transition-smooth"
          title="Manage Lessons"
        >
          <BookOpen className="h-4 w-4" />
        </Link>
        <button
          onClick={onEdit}
          className="p-2 rounded-lg hover:bg-bg-secondary text-text-secondary hover:text-text-primary transition-smooth"
        >
          <Pencil className="h-4 w-4" />
        </button>
        <button
          onClick={onDelete}
          className="p-2 rounded-lg hover:bg-red-50 text-text-secondary hover:text-red-600 transition-smooth"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function ModuleList({ courseId }: ModuleListProps) {
  const [modules, setModules] = useState<ModuleWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingModule, setEditingModule] = useState<ModuleWithStats | null>(
    null,
  );

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const fetchModules = async () => {
    try {
      const response = await fetch(`/api/courses/${courseId}/modules`);
      const data = await response.json();

      if (data.success) {
        setModules(data.data);
      }
    } catch (error) {
      console.error("Error fetching modules:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchModules();
  }, [courseId]);

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over || active.id === over.id) {
      return;
    }

    const oldIndex = modules.findIndex((m) => m.id === active.id);
    const newIndex = modules.findIndex((m) => m.id === over.id);

    const reorderedModules = arrayMove(modules, oldIndex, newIndex);
    setModules(reorderedModules);

    // Update on server
    try {
      const updates = reorderedModules.map((module, index) => ({
        id: module.id,
        orderIndex: index,
      }));

      await fetch(`/api/courses/${courseId}/modules/reorder`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modules: updates }),
      });
    } catch (error) {
      console.error("Error reordering modules:", error);
      // Revert on error
      fetchModules();
    }
  };

  const handleDelete = async (moduleId: string) => {
    if (
      !confirm(
        "Are you sure you want to delete this module? This will also delete all lessons in this module.",
      )
    ) {
      return;
    }

    try {
      const response = await fetch(
        `/api/courses/${courseId}/modules/${moduleId}`,
        {
          method: "DELETE",
        },
      );

      if (response.ok) {
        fetchModules();
      }
    } catch (error) {
      console.error("Error deleting module:", error);
    }
  };

  const handleEdit = (module: ModuleWithStats) => {
    setEditingModule(module);
    setDialogOpen(true);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
    setEditingModule(null);
    fetchModules();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-text-secondary">Loading modules...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-text-primary">
          Course Modules
        </h2>
        <Button onClick={() => setDialogOpen(true)}>
          <Plus className="h-4 w-4" />
          Add Module
        </Button>
      </div>

      {/* Module List */}
      {modules.length === 0 ? (
        <div className="text-center py-12 rounded-lg border border-dashed border-border">
          <p className="text-text-secondary">
            No modules yet. Create your first module to get started.
          </p>
        </div>
      ) : (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={modules.map((m) => m.id)}
            strategy={verticalListSortingStrategy}
          >
            <div className="space-y-3">
              {modules.map((module) => (
                <SortableModule
                  key={module.id}
                  module={module}
                  onEdit={() => handleEdit(module)}
                  onDelete={() => handleDelete(module.id)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}

      {/* Dialog */}
      <ModuleDialog
        open={dialogOpen}
        onClose={handleDialogClose}
        courseId={courseId}
        module={editingModule}
      />
    </div>
  );
}
