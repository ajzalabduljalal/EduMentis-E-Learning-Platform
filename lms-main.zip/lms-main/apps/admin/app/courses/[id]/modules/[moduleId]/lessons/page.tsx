import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { LessonList } from "./components/LessonList";

export default async function LessonsPage({
  params,
}: {
  params: Promise<{ id: string; moduleId: string }>;
}) {
  await requireInstructor();
  const { id: courseId, moduleId } = await params;

  const module = await prisma.module.findFirst({
    where: {
      id: moduleId,
      courseId,
    },
    include: {
      course: true,
    },
  });

  if (!module) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-5xl px-6 py-8">
          <Link
            href={`/courses/${courseId}/modules`}
            className="inline-flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-smooth mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Modules
          </Link>
          <div>
            <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
              {module.title}
            </h1>
            <p className="mt-2 text-sm text-text-secondary">
              Manage lessons for this module
            </p>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-5xl px-6 py-8">
        <LessonList courseId={courseId} moduleId={moduleId} />
      </div>
    </div>
  );
}
