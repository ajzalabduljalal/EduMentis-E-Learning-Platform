import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { LessonEditor } from "../../components/LessonEditor";

export default async function EditLessonPage({
  params,
}: {
  params: Promise<{ id: string; moduleId: string; lessonId: string }>;
}) {
  await requireInstructor();
  const { id: courseId, moduleId, lessonId } = await params;

  const lesson = await prisma.lesson.findFirst({
    where: {
      id: lessonId,
      moduleId,
      module: {
        courseId,
      },
    },
    include: {
      quiz: {
        include: {
          _count: {
            select: { questions: true },
          },
        },
      },
    },
  });

  if (!lesson) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-5xl px-6 py-8">
          <Link
            href={`/courses/${courseId}/modules/${moduleId}/lessons`}
            className="inline-flex items-center gap-2 text-sm font-medium text-text-secondary hover:text-text-primary transition-smooth mb-4"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Lessons
          </Link>
          <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
            Edit Lesson
          </h1>
        </div>
      </div>

      {/* Editor */}
      <div className="mx-auto max-w-5xl px-6 py-8">
        <LessonEditor
          mode="edit"
          courseId={courseId}
          moduleId={moduleId}
          lesson={{
            ...lesson,
            track: lesson.track as "BASIC" | "ADVANCED" | "BOTH",
            type: lesson.lessonType as "TEXT" | "INTERACTIVE" | "CODING",
            hasQuiz: !!lesson.quiz,
            quizQuestionsCount: lesson.quiz?._count.questions || 0,
          }}
        />
      </div>
    </div>
  );
}
