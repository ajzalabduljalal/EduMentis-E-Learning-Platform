"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  Plus,
  GripVertical,
  Pencil,
  Trash2,
  FileText,
  Code,
  MousePointerClick,
  FileVideo,
} from "lucide-react";
import type { LessonWithDetails } from "@repo/types";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  verticalListSortingStrategy,
  useSortable,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

interface LessonListProps {
  courseId: string;
  moduleId: string;
}

function SortableLesson({
  lesson,
  courseId,
  onDelete,
}: {
  lesson: LessonWithDetails;
  courseId: string;
  onDelete: () => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({
    id: lesson.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const trackColors = {
    BASIC: "bg-blue-100 text-blue-800",
    ADVANCED: "bg-purple-100 text-purple-800",
    BOTH: "bg-green-100 text-green-800",
  };

  const TypeIcon =
    {
      TEXT: FileText,
      INTERACTIVE: MousePointerClick,
      CODING: Code,
      VIDEO: FileVideo,
    }[lesson.lessonType] || FileText;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="group flex items-center gap-4 rounded-lg border border-border bg-bg-primary p-4 hover:border-accent transition-smooth"
    >
      {/* Drag Handle */}
      <button
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing text-text-tertiary hover:text-text-primary"
      >
        <GripVertical className="h-5 w-5" />
      </button>

      {/* Icon */}
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-bg-secondary">
        <TypeIcon className="h-5 w-5 text-text-secondary" />
      </div>

      {/* Lesson Info */}
      <div className="flex-1">
        <h3 className="text-sm font-medium text-text-primary">
          {lesson.title}
        </h3>
        <div className="flex items-center gap-3 mt-1">
          <span
            className={`px-2 py-0.5 rounded text-xs font-medium ${trackColors[lesson.track]}`}
          >
            {lesson.track}
          </span>
          <span className="text-xs text-text-tertiary">
            {lesson.duration ? `${lesson.duration} min` : "No duration"}
          </span>
          <span className="text-xs text-text-tertiary capitalize">
            {lesson.lessonType.toLowerCase()}
          </span>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-2">
        <Link
          href={`/courses/${courseId}/modules/${lesson.moduleId}/lessons/${lesson.id}/edit`}
          className="p-2 rounded-lg hover:bg-bg-secondary text-text-secondary hover:text-text-primary transition-smooth"
        >
          <Pencil className="h-4 w-4" />
        </Link>
        <button
          onClick={onDelete}
          className="p-2 rounded-lg hover:bg-red-50 text-text-secondary hover:text-red-600 transition-smooth"
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
}

export function LessonList({ courseId, moduleId }: LessonListProps) {
  const [lessons, setLessons] = useState<LessonWithDetails[]>([]);
  const [loading, setLoading] = useState(true);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const fetchLessons = async () => {
    try {
      const response = await fetch(
        `/api/courses/${courseId}/modules/${moduleId}/lessons`,
      );
      const data = await response.json();

      if (data.success) {
        setLessons(data.data);
      }
    } catch (error) {
      console.error("Error fetching lessons:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLessons();
  }, [courseId, moduleId]);

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over || active.id === over.id) {
      return;
    }

    const oldIndex = lessons.findIndex((l) => l.id === active.id);
    const newIndex = lessons.findIndex((l) => l.id === over.id);

    const reorderedLessons = arrayMove(lessons, oldIndex, newIndex);
    setLessons(reorderedLessons);

    // Update on server
    try {
      const updates = reorderedLessons.map((lesson, index) => ({
        id: lesson.id,
        orderIndex: index,
      }));

      await fetch(
        `/api/courses/${courseId}/modules/${moduleId}/lessons/reorder`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ lessons: updates }),
        },
      );
    } catch (error) {
      console.error("Error reordering lessons:", error);
      // Revert on error
      fetchLessons();
    }
  };

  const handleDelete = async (lessonId: string) => {
    if (!confirm("Are you sure you want to delete this lesson?")) {
      return;
    }

    try {
      const response = await fetch(
        `/api/courses/${courseId}/modules/${moduleId}/lessons/${lessonId}`,
        {
          method: "DELETE",
        },
      );

      if (response.ok) {
        fetchLessons();
      }
    } catch (error) {
      console.error("Error deleting lesson:", error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-text-secondary">Loading lessons...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-text-primary">
          Module Lessons
        </h2>
        <div className="flex items-center gap-3">
          <Link
            href={`/courses/${courseId}/modules/${moduleId}/lessons/new`}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 transition-smooth"
          >
            <Plus className="h-4 w-4" />
            Add Lesson
          </Link>
        </div>
      </div>

      {/* Lesson List */}
      {lessons.length === 0 ? (
        <div className="text-center py-12 rounded-lg border border-dashed border-border">
          <p className="text-text-secondary">
            No lessons yet. Create your first lesson to get started.
          </p>
        </div>
      ) : (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={lessons.map((l) => l.id)}
            strategy={verticalListSortingStrategy}
          >
            <div className="space-y-3">
              {lessons.map((lesson) => (
                <SortableLesson
                  key={lesson.id}
                  lesson={lesson}
                  courseId={courseId}
                  onDelete={() => handleDelete(lesson.id)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}
    </div>
  );
}
