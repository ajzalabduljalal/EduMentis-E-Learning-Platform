"use client";

import { useState, useEffect } from "react";
import { X } from "lucide-react";
import type { ModuleWithStats } from "@repo/types";
import { Button } from "@repo/ui/components/button";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Label } from "@repo/ui/components/label";

type Track = "BASIC" | "ADVANCED" | "BOTH";

interface ModuleDialogProps {
  open: boolean;
  onClose: () => void;
  courseId: string;
  module?: ModuleWithStats | null;
}

export function ModuleDialog({
  open,
  onClose,
  courseId,
  module,
}: ModuleDialogProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    track: "BOTH" as Track,
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (module) {
      setFormData({
        title: module.title,
        description: module.description || "",
        track: module.track,
      });
    } else {
      setFormData({
        title: "",
        description: "",
        track: "BOTH",
      });
    }
  }, [module, open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const url = module
        ? `/api/courses/${courseId}/modules/${module.id}`
        : `/api/courses/${courseId}/modules`;

      const method = module ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        onClose();
      }
    } catch (error) {
      console.error("Error saving module:", error);
    } finally {
      setLoading(false);
    }
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-bg-primary rounded-lg shadow-lg w-full max-w-lg mx-4">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-xl font-semibold text-text-primary">
            {module ? "Edit Module" : "Create Module"}
          </h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="text-text-tertiary hover:text-text-primary"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Title */}
          <div>
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              type="text"
              required
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              placeholder="Module title"
              className="mt-2"
            />
          </div>

          {/* Description */}
          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={3}
              value={formData.description}
              onChange={(e) =>
                setFormData({ ...formData, description: e.target.value })
              }
              placeholder="Module description (optional)"
              className="mt-2"
            />
          </div>

          {/* Track */}
          <div>
            <label className="block text-sm font-medium text-text-primary mb-2">
              Track Assignment *
            </label>
            <div className="space-y-2">
              {[
                { value: "BASIC", label: "Basic Track Only" },
                { value: "ADVANCED", label: "Advanced Track Only" },
                { value: "BOTH", label: "Both Tracks" },
              ].map((option) => (
                <label
                  key={option.value}
                  className="flex items-center gap-2 cursor-pointer"
                >
                  <input
                    type="radio"
                    name="track"
                    value={option.value}
                    checked={formData.track === option.value}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        track: e.target.value as Track,
                      })
                    }
                    className="w-4 h-4 text-accent focus:ring-accent"
                  />
                  <span className="text-sm text-text-primary">
                    {option.label}
                  </span>
                </label>
              ))}
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? "Saving..." : module ? "Update" : "Create"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
