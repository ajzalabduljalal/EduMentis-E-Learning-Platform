import { requireInstructor } from "@repo/auth";
import { CourseForm } from "../components/CourseForm";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export default async function NewCoursePage() {
  await requireInstructor();

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-10">
          <Link
            href="/courses"
            className="inline-flex items-center gap-2 text-sm font-semibold text-text-secondary hover:text-text-primary transition-smooth mb-6"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Courses
          </Link>
          <h1 className="text-2xl font-semibold tracking-tight text-text-primary">
            Create New Course
          </h1>
          <p className="mt-2 text-base text-text-secondary">
            Fill in the details below to create a new course
          </p>
        </div>
      </div>

      {/* Form */}
      <div className="mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 py-8">
        <CourseForm />
      </div>
    </div>
  );
}
