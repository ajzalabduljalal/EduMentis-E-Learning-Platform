import { requireInstructor } from "@repo/auth";
import Link from "next/link";
import { Plus, BookOpen } from "lucide-react";
import { CourseList } from "./components/CourseList";

export default async function CoursesPage() {
  await requireInstructor();

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-semibold tracking-tight text-text-primary">
                Courses
              </h1>
              <p className="mt-2 text-base text-text-secondary">
                Create and manage your courses
              </p>
            </div>
            <Link
              href="/courses/new"
              className="inline-flex items-center gap-2 rounded-lg bg-zinc-900 px-4 py-2.5 text-sm font-semibold text-white hover:bg-zinc-800 transition-smooth shadow-sm"
            >
              <Plus className="h-4 w-4" />
              Create Course
            </Link>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <CourseList />
      </div>
    </div>
  );
}
