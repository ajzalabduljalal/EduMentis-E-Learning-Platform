import { currentUser } from "@clerk/nextjs/server";
import { requireInstructor } from "@repo/auth";
import { prisma, AssessmentStatus } from "@repo/db";
import Link from "next/link";
import {
  BookOpen,
  Users,
  FileCheck,
  Award,
  Plus,
  ArrowRight,
  GraduationCap,
  Clock,
  CheckCircle,
} from "lucide-react";

export default async function AdminHomePage() {
  // Require instructor or admin role to access this page
  await requireInstructor();

  const user = await currentUser();

  // Fetch real stats from database
  const [
    totalCourses,
    activeStudentsCount,
    pendingReviews,
    certificates,
    recentEnrollments,
    recentQuizAttempts,
  ] = await Promise.all([
    // Total courses (published)
    prisma.course.count({
      where: { status: "PUBLISHED" },
    }),
    // Active students (users with at least one course enrollment)
    prisma.userCourseProgress.findMany({
      select: { userId: true },
      distinct: ["userId"],
    }),
    // Pending reviews (assessments with GRADING status)
    prisma.assessmentAttempt.count({
      where: { status: AssessmentStatus.GRADING },
    }),
    // Certificates (completed courses with certificates)
    prisma.userCourseProgress.count({
      where: { isCompleted: true, certificateUrl: { not: null } },
    }),
    // Recent enrollments
    prisma.userCourseProgress.findMany({
      take: 5,
      orderBy: { enrolledAt: "desc" },
      include: {
        user: {
          select: { name: true, email: true, imageUrl: true },
        },
        course: {
          select: { id: true, title: true, slug: true },
        },
      },
    }),
    // Recent quiz completions
    prisma.quizAttempt.findMany({
      take: 5,
      where: { completedAt: { not: null } },
      orderBy: { completedAt: "desc" },
      include: {
        user: {
          select: { name: true, email: true, imageUrl: true },
        },
        quiz: {
          select: { title: true, quizType: true },
        },
      },
    }),
  ]);

  const activeStudents = activeStudentsCount.length;

  // Format recent activity for display
  const recentActivity = [
    ...recentEnrollments.map((enrollment) => ({
      id: enrollment.id,
      type: "enrollment" as const,
      user: enrollment.user,
      description: `enrolled in ${enrollment.course.title}`,
      timestamp: enrollment.enrolledAt,
    })),
    ...recentQuizAttempts.map((attempt) => ({
      id: attempt.id,
      type: "quiz" as const,
      user: attempt.user,
      description: `completed ${attempt.quiz.title} (${attempt.quiz.quizType.replace("_", " ").toLowerCase()})`,
      timestamp: attempt.completedAt!,
    })),
  ]
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
    .slice(0, 6);

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
            Admin Dashboard
          </h1>
          <p className="mt-2 text-sm text-text-secondary">
            Welcome back, {user?.firstName || "Admin"}
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-6 py-8">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-gray-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Total Courses
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {totalCourses}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-bg-secondary">
                <BookOpen className="h-6 w-6 text-text-primary" />
              </div>
            </div>
            <Link
              href="/courses"
              className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-text-primary hover:text-zinc-600 transition-smooth"
            >
              Manage courses
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-gray-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Active Students
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {activeStudents}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-bg-secondary">
                <Users className="h-6 w-6 text-text-primary" />
              </div>
            </div>
            <Link
              href="/courses"
              className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-text-primary hover:text-zinc-600 transition-smooth"
            >
              View courses
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-gray-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Pending Reviews
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {pendingReviews}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-bg-secondary">
                <FileCheck className="h-6 w-6 text-text-primary" />
              </div>
            </div>
            <Link
              href="/assessments"
              className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-text-primary hover:text-zinc-600 transition-smooth"
            >
              Review submissions
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>

          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-gray-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Certificates
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {certificates}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-bg-secondary">
                <Award className="h-6 w-6 text-text-primary" />
              </div>
            </div>
            <Link
              href="/assessments"
              className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-text-primary hover:text-zinc-600 transition-smooth"
            >
              View all
              <ArrowRight className="h-3 w-3" />
            </Link>
          </div>
        </div>

        {/* Quick Actions & Recent Activity */}
        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          {/* Quick Actions */}
          <div className="rounded-lg border border-border bg-bg-primary p-6">
            <h2 className="text-lg font-semibold text-text-primary">
              Quick Actions
            </h2>
            <div className="mt-4 space-y-3">
              <Link
                href="/courses/new"
                className="group flex items-center justify-between rounded-lg border border-border bg-bg-primary px-4 py-3 hover:border-accent hover:bg-accent-light transition-smooth"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-bg-secondary group-hover:bg-white transition-smooth">
                    <Plus className="h-4 w-4 text-text-primary" />
                  </div>
                  <span className="text-sm font-medium text-text-primary">
                    Create New Course
                  </span>
                </div>
                <ArrowRight className="h-4 w-4 text-text-tertiary group-hover:text-text-primary transition-smooth" />
              </Link>

              <Link
                href="/courses"
                className="group flex items-center justify-between rounded-lg border border-border bg-bg-primary px-4 py-3 hover:border-accent hover:bg-accent-light transition-smooth"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-bg-secondary group-hover:bg-white transition-smooth">
                    <BookOpen className="h-4 w-4 text-text-primary" />
                  </div>
                  <span className="text-sm font-medium text-text-primary">
                    Manage Courses
                  </span>
                </div>
                <ArrowRight className="h-4 w-4 text-text-tertiary group-hover:text-text-primary transition-smooth" />
              </Link>

              <Link
                href="/assessments"
                className="group flex items-center justify-between rounded-lg border border-border bg-bg-primary px-4 py-3 hover:border-accent hover:bg-accent-light transition-smooth"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-bg-secondary group-hover:bg-white transition-smooth">
                    <FileCheck className="h-4 w-4 text-text-primary" />
                  </div>
                  <span className="text-sm font-medium text-text-primary">
                    Review Assessments
                  </span>
                </div>
                <ArrowRight className="h-4 w-4 text-text-tertiary group-hover:text-text-primary transition-smooth" />
              </Link>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="rounded-lg border border-border bg-bg-primary p-6">
            <h2 className="text-lg font-semibold text-text-primary">
              Recent Activity
            </h2>
            {recentActivity.length === 0 ? (
              <div className="mt-4 flex items-center justify-center rounded-lg border border-dashed border-border py-12">
                <p className="text-sm text-text-tertiary">
                  No recent activity to display
                </p>
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                {recentActivity.map((activity) => (
                  <div
                    key={`${activity.type}-${activity.id}`}
                    className="flex items-start gap-3"
                  >
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-bg-secondary">
                      {activity.type === "enrollment" ? (
                        <GraduationCap className="h-4 w-4 text-text-primary" />
                      ) : (
                        <CheckCircle className="h-4 w-4 text-success" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-text-primary truncate">
                        <span className="font-medium">
                          {activity.user.name ||
                            activity.user.email.split("@")[0]}
                        </span>{" "}
                        {activity.description}
                      </p>
                      <p className="text-xs text-text-tertiary flex items-center gap-1 mt-0.5">
                        <Clock className="h-3 w-3" />
                        {formatTimeAgo(activity.timestamp)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
