"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@repo/ui/components/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import { Badge } from "@repo/ui/components/badge";
import { Input } from "@repo/ui/components/input";
import { Textarea } from "@repo/ui/components/textarea";
import { Label } from "@repo/ui/components/label";
import {
  ArrowLeft,
  CheckCircle2,
  XCircle,
  Save,
  Send,
  Loader2,
} from "lucide-react";
import Link from "next/link";
import { useToast } from "@repo/ui/hooks/use-toast";

type QuestionType = "MULTIPLE_CHOICE" | "TEXT" | "CODE" | "FILE_UPLOAD";

interface Question {
  id: string;
  questionType: QuestionType;
  questionText: string;
  points: number;
  options: { id: string; text: string }[];
  correctAnswer?: string;
  answer?: {
    answer: string;
    isCorrect: boolean | null;
    pointsEarned: number;
  };
}

interface ReviewClientProps {
  attempt: {
    id: string;
    submittedAt: string;
    student: {
      name: string;
      email: string;
    };
  };
  course: {
    title: string;
    passingScore: number;
  };
  questions: Question[];
}

export function ReviewClient({
  attempt,
  course,
  questions,
}: ReviewClientProps) {
  const router = useRouter();
  const { toast } = useToast();
  const [grades, setGrades] = useState<Record<string, number>>(() => {
    const initial: Record<string, number> = {};
    questions.forEach((q) => {
      if (q.answer && q.answer.pointsEarned !== null) {
        initial[q.id] = q.answer.pointsEarned;
      }
    });
    return initial;
  });
  const [feedback, setFeedback] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleGradeChange = (questionId: string, points: number) => {
    setGrades((prev) => ({
      ...prev,
      [questionId]: points,
    }));
  };

  const calculateTotalScore = () => {
    const totalPoints = questions.reduce((sum, q) => sum + q.points, 0);
    const earnedPoints = questions.reduce((sum, q) => {
      if (q.answer?.isCorrect === true) return sum + q.points;
      if (grades[q.id] !== undefined) return sum + (grades[q.id] || 0);
      return sum;
    }, 0);

    return {
      earnedPoints,
      totalPoints,
      percentage: Math.round((earnedPoints / totalPoints) * 100),
    };
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);

    try {
      const score = calculateTotalScore();

      const response = await fetch(`/api/assessments/${attempt.id}/grade`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          grades,
          feedback,
          totalScore: score.percentage,
        }),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          variant: "success",
          title: "Grade submitted successfully",
          description: `The student has been notified of their ${score.percentage}% score.`,
        });
        router.push("/assessments");
      } else {
        toast({
          variant: "destructive",
          title: "Failed to submit grade",
          description:
            data.error || "An error occurred while submitting the grade.",
        });
      }
    } catch (error) {
      console.error("Error submitting grade:", error);
      toast({
        variant: "destructive",
        title: "Failed to submit grade",
        description: "An unexpected error occurred. Please try again.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const score = calculateTotalScore();
  const isPassing = score.percentage >= course.passingScore;

  return (
    <div className="min-h-screen bg-zinc-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Link
            href="/assessments"
            className="inline-flex items-center text-sm text-text-secondary hover:text-primary mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to assessments
          </Link>

          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-3xl font-bold text-text-primary mb-2">
                Review Assessment
              </h1>
              <p className="text-text-secondary">
                Student: {attempt.student.name}
              </p>
              <p className="text-sm text-text-secondary">
                Course: {course.title}
              </p>
            </div>

            <div className="text-right">
              <p className="text-sm text-text-secondary mb-1">Current Score</p>
              <p className="text-4xl font-bold text-text-primary">
                {score.percentage}%
              </p>
              <Badge variant={isPassing ? "success" : "error"}>
                {isPassing ? "Passing" : "Failing"}
              </Badge>
            </div>
          </div>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-text-secondary">
                  Submitted: {new Date(attempt.submittedAt).toLocaleString()}
                </span>
                <span className="text-text-secondary">
                  Passing score: {course.passingScore}%
                </span>
                <span className="font-semibold">
                  {score.earnedPoints} / {score.totalPoints} points
                </span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Questions */}
        <div className="space-y-6 mb-8">
          {questions.map((question, index) => (
            <Card key={question.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm text-text-secondary">
                        Question {index + 1}
                      </span>
                      <Badge variant="secondary">
                        {question.questionType.replace("_", " ")}
                      </Badge>
                      {question.answer?.isCorrect !== null &&
                        question.answer !== undefined && (
                          <Badge
                            variant={
                              question.answer?.isCorrect ? "success" : "error"
                            }
                          >
                            {question.answer?.isCorrect
                              ? "Correct"
                              : "Incorrect"}
                          </Badge>
                        )}
                    </div>
                    <CardTitle className="text-base">
                      {question.questionText}
                    </CardTitle>
                  </div>
                  <span className="text-sm text-text-secondary">
                    {question.points} pts
                  </span>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Student's answer */}
                <div>
                  <Label className="text-sm font-semibold mb-2 block">
                    Student's Answer:
                  </Label>
                  {question.questionType === "MULTIPLE_CHOICE" ? (
                    <div className="space-y-2">
                      {question.options.map((option) => {
                        let selectedAnswer: string[] = [];
                        if (question.answer) {
                          try {
                            selectedAnswer = JSON.parse(question.answer.answer);
                          } catch {
                            selectedAnswer = [question.answer.answer];
                          }
                        }

                        const isSelected = selectedAnswer.includes(option.id);
                        const isCorrect = question.correctAnswer?.includes(
                          option.id,
                        );

                        return (
                          <div
                            key={option.id}
                            className={`p-3 rounded-lg border ${
                              isSelected
                                ? isCorrect
                                  ? "border-success bg-success-50"
                                  : "border-error bg-error-50"
                                : "border-border bg-white"
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              {isSelected &&
                                (isCorrect ? (
                                  <CheckCircle2 className="h-4 w-4 text-success" />
                                ) : (
                                  <XCircle className="h-4 w-4 text-error" />
                                ))}
                              <span className="text-sm">{option.text}</span>
                              {isCorrect && !isSelected && (
                                <span className="ml-auto text-xs text-success">
                                  (Correct answer)
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="bg-zinc-50 border border-border rounded-lg p-4">
                      <pre className="whitespace-pre-wrap text-sm font-mono">
                        {question.answer?.answer || "No answer provided"}
                      </pre>
                    </div>
                  )}
                </div>

                {/* Grading section for non-MCQ questions */}
                {question.questionType !== "MULTIPLE_CHOICE" &&
                  question.answer?.isCorrect === null && (
                    <div className="border-t border-border pt-4">
                      <Label
                        htmlFor={`grade-${question.id}`}
                        className="mb-2 block"
                      >
                        Assign Points (0 - {question.points}):
                      </Label>
                      <Input
                        id={`grade-${question.id}`}
                        type="number"
                        min={0}
                        max={question.points}
                        value={grades[question.id] || 0}
                        onChange={(e) =>
                          handleGradeChange(
                            question.id,
                            Math.min(
                              question.points,
                              Math.max(0, Number(e.target.value)),
                            ),
                          )
                        }
                        className="w-32"
                      />
                    </div>
                  )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Feedback section */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Overall Feedback (Optional)</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={feedback}
              onChange={(e) => setFeedback(e.target.value)}
              placeholder="Provide feedback to the student..."
              className="min-h-[120px]"
            />
          </CardContent>
        </Card>

        {/* Submit button */}
        <div className="flex gap-4">
          <Button
            size="lg"
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="flex-1"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Send className="mr-2 h-5 w-5" />
                Submit Grade
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
