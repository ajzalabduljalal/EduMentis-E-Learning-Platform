import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import { redirect, notFound } from "next/navigation";
import { ReviewClient } from "./ReviewClient";

interface PageProps {
  params: Promise<{ attemptId: string }>;
}

export default async function ReviewPage({ params }: PageProps) {
  const { userId } = await auth();

  if (!userId) {
    redirect("/sign-in");
  }

  const { attemptId } = await params;

  // Get user and check if admin
  const user = await prisma.user.findUnique({
    where: { clerkId: userId },
  });

  if (!user || (user.role !== "ADMIN" && user.role !== "INSTRUCTOR")) {
    redirect("/");
  }

  // Get assessment attempt
  const attempt = await prisma.assessmentAttempt.findUnique({
    where: { id: attemptId },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
  });

  if (!attempt) {
    notFound();
  }

  // Get course and final exam
  const course = await prisma.course.findUnique({
    where: { id: attempt.courseId },
    include: {
      finalExam: {
        include: {
          questions: {
            orderBy: { orderIndex: "asc" },
          },
        },
      },
    },
  });

  if (!course || !course.finalExam) {
    notFound();
  }

  // Get quiz attempt with answers
  const quizAttempt = await prisma.quizAttempt.findFirst({
    where: {
      userId: attempt.userId,
      quizId: course.finalExam.id,
    },
    include: {
      answers: {
        include: {
          question: true,
        },
      },
    },
    orderBy: {
      completedAt: "desc",
    },
  });

  if (!quizAttempt) {
    notFound();
  }

  // Transform data for client
  const questionsWithAnswers = course.finalExam.questions.map((question) => {
    const answer = quizAttempt.answers.find(
      (a) => a.questionId === question.id,
    );

    return {
      id: question.id,
      questionType: question.questionType as
        | "MULTIPLE_CHOICE"
        | "TEXT"
        | "CODE"
        | "FILE_UPLOAD",
      questionText: question.question,
      points: question.points,
      options:
        question.questionType === "MULTIPLE_CHOICE" && question.options
          ? Object.entries(question.options as Record<string, string>).map(
              ([key, value]) => ({
                id: key,
                text: value,
              }),
            )
          : [],
      correctAnswer: question.correctAnswer || undefined,
      answer: answer
        ? {
            answer: answer.answer,
            isCorrect: answer.isCorrect,
            pointsEarned: answer.pointsEarned,
          }
        : undefined,
    };
  });

  return (
    <ReviewClient
      attempt={{
        id: attempt.id,
        submittedAt: attempt.submittedAt.toISOString(),
        student: {
          name: attempt.user.name || attempt.user.email,
          email: attempt.user.email,
        },
      }}
      course={{
        title: course.title,
        passingScore: course.finalExam.passingScore,
      }}
      questions={questionsWithAnswers}
    />
  );
}
