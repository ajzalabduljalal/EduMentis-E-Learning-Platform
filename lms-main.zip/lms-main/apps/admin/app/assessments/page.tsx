import { auth } from "@clerk/nextjs/server";
import { prisma, AssessmentStatus } from "@repo/db";
import { redirect } from "next/navigation";
import Link from "next/link";
import { Clock, User, BookOpen, AlertCircle, ArrowRight } from "lucide-react";

export default async function AssessmentsPage() {
  const { userId } = await auth();

  if (!userId) {
    redirect("/sign-in");
  }

  // Get user and check if admin
  const user = await prisma.user.findUnique({
    where: { clerkId: userId },
  });

  if (!user || (user.role !== "ADMIN" && user.role !== "INSTRUCTOR")) {
    redirect("/");
  }

  // Get all pending assessments
  const pendingAssessments = await prisma.assessmentAttempt.findMany({
    where: {
      status: AssessmentStatus.GRADING,
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
    },
    orderBy: {
      submittedAt: "desc",
    },
  });

  // Get course info for each assessment
  const assessmentsWithCourses = await Promise.all(
    pendingAssessments.map(async (attempt) => {
      const course = await prisma.course.findUnique({
        where: { id: attempt.courseId },
        select: {
          id: true,
          title: true,
          slug: true,
        },
      });

      return {
        ...attempt,
        course,
      };
    }),
  );

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    if (seconds < 60) return "just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-7xl px-6 py-8">
          <h1 className="text-3xl font-semibold tracking-tight text-text-primary">
            Assessment Reviews
          </h1>
          <p className="mt-2 text-sm text-text-secondary">
            Review and grade pending final assessments
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-6 py-8">
        {/* Stats Grid */}
        <div className="grid gap-4 md:grid-cols-3 mb-8">
          {/* Pending Reviews */}
          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-zinc-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Pending Reviews
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {assessmentsWithCourses.length}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-warning-50">
                <Clock className="h-6 w-6 text-warning" />
              </div>
            </div>
          </div>

          {/* Unique Students */}
          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-zinc-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Unique Students
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {new Set(assessmentsWithCourses.map((a) => a.userId)).size}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-bg-secondary">
                <User className="h-6 w-6 text-text-primary" />
              </div>
            </div>
          </div>

          {/* Courses */}
          <div className="rounded-lg border border-border bg-bg-primary p-6 hover:border-zinc-300 transition-smooth">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-text-secondary">
                  Courses
                </p>
                <p className="mt-2 text-3xl font-semibold text-text-primary">
                  {new Set(assessmentsWithCourses.map((a) => a.courseId)).size}
                </p>
              </div>
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-success-50">
                <BookOpen className="h-6 w-6 text-success" />
              </div>
            </div>
          </div>
        </div>

        {/* Assessments List */}
        <div className="rounded-lg border border-border bg-bg-primary p-6">
          <div className="mb-6">
            <h2 className="text-lg font-semibold text-text-primary">
              Pending Assessments
            </h2>
            <p className="mt-1 text-sm text-text-secondary">
              Review student submissions and provide feedback
            </p>
          </div>

          {assessmentsWithCourses.length === 0 ? (
            <div className="flex flex-col items-center justify-center rounded-lg border border-dashed border-border py-16">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-bg-secondary mb-4">
                <AlertCircle className="h-6 w-6 text-text-tertiary" />
              </div>
              <p className="text-sm font-medium text-text-primary">
                No pending assessments
              </p>
              <p className="mt-1 text-sm text-text-tertiary">
                All assessments have been reviewed
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {assessmentsWithCourses.map((assessment) => (
                <Link
                  key={assessment.id}
                  href={`/assessments/${assessment.id}/review`}
                  className="group block rounded-lg border border-border bg-bg-primary p-4 hover:border-accent hover:bg-accent-light transition-smooth"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-sm font-semibold text-text-primary">
                          {assessment.user.name || assessment.user.email}
                        </h3>
                        <span className="inline-flex items-center rounded-full bg-warning-50 px-2 py-1 text-xs font-medium text-warning">
                          Pending Review
                        </span>
                      </div>
                      <p className="text-sm text-text-secondary mb-1">
                        <span className="font-medium">Course:</span>{" "}
                        {assessment.course?.title || "Unknown Course"}
                      </p>
                      <div className="flex items-center gap-1 text-xs text-text-tertiary">
                        <Clock className="h-3 w-3" />
                        Submitted {formatTimeAgo(assessment.submittedAt)}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="hidden sm:inline-block text-sm font-medium text-text-primary group-hover:text-zinc-700 transition-smooth">
                        Review
                      </span>
                      <ArrowRight className="h-4 w-4 text-text-tertiary group-hover:text-text-primary transition-smooth" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
