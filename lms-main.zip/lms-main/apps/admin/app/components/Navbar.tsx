"use client";

import Link from "next/link";
import { UserButton } from "@clerk/nextjs";

export function Navbar() {
  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 h-16 bg-bg-primary border-b border-border">
        <div className="mx-auto max-w-full px-6 h-full">
          <div className="flex items-center justify-between h-full">
            {/* Logo */}
            <Link
              href="/"
              className="text-lg font-semibold text-text-primary hover:text-zinc-700 transition-colors"
            >
              Edumentis Admin
            </Link>

            {/* User Menu */}
            <UserButton
              afterSignOutUrl="/sign-in"
              appearance={{
                elements: {
                  avatarBox: "h-8 w-8",
                  userButtonPopoverFooter: { display: "none" },
                  footer: { display: "none" },
                  popoverFooter: { display: "none" },
                },
              }}
            />
          </div>
        </div>
      </nav>

      {/* Add padding to body to account for fixed navbar */}
      <div className="h-16" />
    </>
  );
}
