import { SignIn } from "@clerk/nextjs";

export default function AdminSignInPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-bg-secondary">
      <div className="w-full max-w-md px-6">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-semibold text-text-primary">
            Admin Portal
          </h1>
          <p className="mt-3 text-base text-text-secondary leading-relaxed">
            Sign in to manage Edumentis
          </p>
        </div>
        <SignIn
          appearance={{
            elements: {
              rootBox: "mx-auto",
              card: "shadow-sm border-border",
              footer: {
                display: "none",
              },
            },
          }}
        />
      </div>
    </div>
  );
}
