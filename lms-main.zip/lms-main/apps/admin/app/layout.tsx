import type { Metadata } from "next";
import { ClerkProvider } from "@clerk/nextjs";
import "./globals.css";
import { Navbar } from "./components/Navbar";
import { Toaster } from "@repo/ui/components/toaster";

export const metadata: Metadata = {
  title: "Edumentis Admin",
  description: "Admin dashboard for managing courses, content, and assessments",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>
          <Navbar />
          {children}
          <Toaster />
        </body>
      </html>
    </ClerkProvider>
  );
}
