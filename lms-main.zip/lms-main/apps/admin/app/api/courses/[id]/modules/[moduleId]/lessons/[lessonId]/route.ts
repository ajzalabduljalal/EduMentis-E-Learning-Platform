import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import type { ApiResponse, UpdateLessonInput, LessonWithDetails } from "@repo/types";

/**
 * GET /api/courses/[id]/modules/[moduleId]/lessons/[lessonId]
 * Get a single lesson
 */
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string; lessonId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId, lessonId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Get lesson with ownership check
        const lesson = await prisma.lesson.findFirst({
            where: {
                id: lessonId,
                moduleId,
                module: {
                    courseId,
                    course: {
                        instructorId: instructor.id,
                    },
                },
            },
        });

        if (!lesson) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Lesson not found or access denied" },
                { status: 404 }
            );
        }

        return NextResponse.json<ApiResponse<LessonWithDetails>>({
            success: true,
            data: lesson as LessonWithDetails,
        });
    } catch (error) {
        console.error("Error fetching lesson:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * PUT /api/courses/[id]/modules/[moduleId]/lessons/[lessonId]
 * Update a lesson
 */
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string; lessonId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId, lessonId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify lesson exists and user owns the course
        const existingLesson = await prisma.lesson.findFirst({
            where: {
                id: lessonId,
                moduleId,
                module: {
                    courseId,
                    course: {
                        instructorId: instructor.id,
                    },
                },
            },
        });

        if (!existingLesson) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Lesson not found or access denied" },
                { status: 404 }
            );
        }

        const body: Omit<UpdateLessonInput, "id"> = await request.json();

        // Update lesson
        const lesson = await prisma.lesson.update({
            where: { id: lessonId },
            data: {
                title: body.title,
                description: body.description,
                content: body.content,
                track: body.track,
                lessonType: body.lessonType,
                duration: body.duration,
                orderIndex: body.orderIndex,
                isFree: body.isFree,
            },
        });

        return NextResponse.json<ApiResponse<LessonWithDetails>>({
            success: true,
            data: lesson as LessonWithDetails,
            message: "Lesson updated successfully",
        });
    } catch (error) {
        console.error("Error updating lesson:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * DELETE /api/courses/[id]/modules/[moduleId]/lessons/[lessonId]
 * Delete a lesson
 */
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string; lessonId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId, lessonId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify lesson exists and user owns the course
        const existingLesson = await prisma.lesson.findFirst({
            where: {
                id: lessonId,
                moduleId,
                module: {
                    courseId,
                    course: {
                        instructorId: instructor.id,
                    },
                },
            },
        });

        if (!existingLesson) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Lesson not found or access denied" },
                { status: 404 }
            );
        }

        // Delete lesson
        await prisma.lesson.delete({
            where: { id: lessonId },
        });

        return NextResponse.json<ApiResponse>({
            success: true,
            message: "Lesson deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting lesson:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
