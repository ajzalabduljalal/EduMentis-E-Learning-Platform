import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@repo/db";
import { requireInstructor } from "@repo/auth";
import type { ApiResponse, UpdateQuestionInput, Question } from "@repo/types";

export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; quizId: string; questionId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, quizId, questionId } = await params;

        // Verify ownership
        const existingQuestion = await prisma.question.findFirst({
            where: {
                id: questionId,
                quizId,
                quiz: {
                    courseId,
                    course: { instructorId: userId },
                },
            },
        });

        if (!existingQuestion) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Question not found or unauthorized" },
                { status: 404 }
            );
        }

        const body: Omit<UpdateQuestionInput, "id"> = await request.json();

        const question = await prisma.question.update({
            where: { id: questionId },
            data: {
                question: body.question,
                questionType: body.questionType,
                points: body.points,
                orderIndex: body.orderIndex,
                options: body.options ?? undefined,
                correctAnswer: body.correctAnswer,
                explanation: body.explanation,
                testCases: body.testCases ?? undefined,
                starterCode: body.starterCode,
                maxLength: body.maxLength,
            },
        });

        return NextResponse.json<ApiResponse<Question>>({
            success: true,
            data: question as unknown as Question,
            message: "Question updated successfully",
        });
    } catch (error) {
        console.error("Error updating question:", error);
        return NextResponse.json<ApiResponse<null>>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; quizId: string; questionId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, quizId, questionId } = await params;

        // Verify ownership
        const existingQuestion = await prisma.question.findFirst({
            where: {
                id: questionId,
                quizId,
                quiz: {
                    courseId,
                    course: { instructorId: userId },
                },
            },
        });

        if (!existingQuestion) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Question not found or unauthorized" },
                { status: 404 }
            );
        }

        await prisma.question.delete({
            where: { id: questionId },
        });

        return NextResponse.json<ApiResponse<null>>({
            success: true,
            message: "Question deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting question:", error);
        return NextResponse.json<ApiResponse<null>>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
