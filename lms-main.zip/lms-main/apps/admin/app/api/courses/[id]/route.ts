import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import type { ApiResponse, UpdateCourseInput, CourseWithStats } from "@repo/types";
import { CourseStatus } from "@repo/db";

/**
 * GET /api/courses/[id]
 * Get a single course by ID
 */
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const { userId } = await auth();

        if (!userId) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Unauthorized" },
                { status: 401 }
            );
        }

        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor || (instructor.role !== "INSTRUCTOR" && instructor.role !== "ADMIN")) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Forbidden" },
                { status: 403 }
            );
        }

        const course = await prisma.course.findUnique({
            where: { id },
            include: {
                _count: {
                    select: {
                        modules: true,
                        userProgress: true,
                    },
                },
            },
        });

        if (!course) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Course not found" },
                { status: 404 }
            );
        }

        // Verify ownership
        if (course.instructorId !== instructor.id && instructor.role !== "ADMIN") {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Forbidden - You don't own this course" },
                { status: 403 }
            );
        }

        return NextResponse.json<ApiResponse<CourseWithStats>>({
            success: true,
            data: course as CourseWithStats,
        });
    } catch (error) {
        console.error("Error fetching course:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * PUT /api/courses/[id]
 * Update a course
 */
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const { userId } = await auth();

        if (!userId) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Unauthorized" },
                { status: 401 }
            );
        }

        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor || (instructor.role !== "INSTRUCTOR" && instructor.role !== "ADMIN")) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Forbidden" },
                { status: 403 }
            );
        }

        // Check if course exists and verify ownership
        const existingCourse = await prisma.course.findUnique({
            where: { id },
        });

        if (!existingCourse) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Course not found" },
                { status: 404 }
            );
        }

        if (existingCourse.instructorId !== instructor.id && instructor.role !== "ADMIN") {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Forbidden - You don't own this course" },
                { status: 403 }
            );
        }

        const body: Partial<UpdateCourseInput> = await request.json();

        // If changing slug, check if it's available
        if (body.slug && body.slug !== existingCourse.slug) {
            const slugExists = await prisma.course.findUnique({
                where: { slug: body.slug },
            });

            if (slugExists) {
                return NextResponse.json<ApiResponse>(
                    { success: false, error: "A course with this slug already exists" },
                    { status: 409 }
                );
            }
        }

        // Update course
        const updateData: any = {
            ...(body.title !== undefined && { title: body.title }),
            ...(body.slug !== undefined && { slug: body.slug }),
            ...(body.description !== undefined && { description: body.description }),
            ...(body.shortDescription !== undefined && { shortDescription: body.shortDescription }),
            ...(body.imageUrl !== undefined && { imageUrl: body.imageUrl }),
            ...(body.price !== undefined && { price: body.price }),
            ...(body.level !== undefined && { level: body.level }),
            ...(body.category !== undefined && { category: body.category }),
            ...(body.duration !== undefined && { duration: body.duration }),
        };

        // Handle status change to published
        if (body.status !== undefined) {
            updateData.status = body.status;
            if (body.status === CourseStatus.PUBLISHED && !existingCourse.publishedAt) {
                updateData.publishedAt = new Date();
            }
        }

        const course = await prisma.course.update({
            where: { id },
            data: updateData,
            include: {
                _count: {
                    select: {
                        modules: true,
                        userProgress: true,
                    },
                },
            },
        });

        return NextResponse.json<ApiResponse<CourseWithStats>>({
            success: true,
            data: course as CourseWithStats,
            message: "Course updated successfully",
        });
    } catch (error) {
        console.error("Error updating course:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * DELETE /api/courses/[id]
 * Delete a course
 */
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const { userId } = await auth();

        if (!userId) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Unauthorized" },
                { status: 401 }
            );
        }

        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor || (instructor.role !== "INSTRUCTOR" && instructor.role !== "ADMIN")) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Forbidden" },
                { status: 403 }
            );
        }

        // Check if course exists and verify ownership
        const existingCourse = await prisma.course.findUnique({
            where: { id },
            include: {
                _count: {
                    select: {
                        userProgress: true,
                    },
                },
            },
        });

        if (!existingCourse) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Course not found" },
                { status: 404 }
            );
        }

        if (existingCourse.instructorId !== instructor.id && instructor.role !== "ADMIN") {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Forbidden - You don't own this course" },
                { status: 403 }
            );
        }

        // Prevent deletion if students are enrolled
        if (existingCourse._count.userProgress > 0) {
            return NextResponse.json<ApiResponse>(
                {
                    success: false,
                    error: `Cannot delete course with ${existingCourse._count.userProgress} enrolled student(s). Archive it instead.`,
                },
                { status: 400 }
            );
        }

        // Delete course (cascade will handle modules, lessons, etc.)
        await prisma.course.delete({
            where: { id },
        });

        return NextResponse.json<ApiResponse>({
            success: true,
            message: "Course deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting course:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
