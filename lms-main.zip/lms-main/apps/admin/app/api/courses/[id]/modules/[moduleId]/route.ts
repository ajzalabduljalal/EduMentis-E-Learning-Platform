import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import type { ApiResponse, ModuleWithStats, UpdateModuleInput } from "@repo/types";

/**
 * GET /api/courses/[id]/modules/[moduleId]
 * Get a single module
 */
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Get module with course ownership check
        const module = await prisma.module.findFirst({
            where: {
                id: moduleId,
                courseId,
                course: {
                    instructorId: instructor.id,
                },
            },
            include: {
                _count: {
                    select: {
                        lessons: true,
                    },
                },
            },
        });

        if (!module) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Module not found or access denied" },
                { status: 404 }
            );
        }

        return NextResponse.json<ApiResponse<ModuleWithStats>>({
            success: true,
            data: module as ModuleWithStats,
        });
    } catch (error) {
        console.error("Error fetching module:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * PUT /api/courses/[id]/modules/[moduleId]
 * Update a module
 */
export async function PUT(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify module exists and user owns the course
        const existingModule = await prisma.module.findFirst({
            where: {
                id: moduleId,
                courseId,
                course: {
                    instructorId: instructor.id,
                },
            },
        });

        if (!existingModule) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Module not found or access denied" },
                { status: 404 }
            );
        }

        const body: Omit<UpdateModuleInput, "id"> = await request.json();

        // Update module
        const module = await prisma.module.update({
            where: { id: moduleId },
            data: {
                title: body.title,
                description: body.description,
                track: body.track,
                orderIndex: body.orderIndex,
            },
            include: {
                _count: {
                    select: {
                        lessons: true,
                    },
                },
            },
        });

        return NextResponse.json<ApiResponse<ModuleWithStats>>({
            success: true,
            data: module as ModuleWithStats,
            message: "Module updated successfully",
        });
    } catch (error) {
        console.error("Error updating module:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * DELETE /api/courses/[id]/modules/[moduleId]
 * Delete a module (cascade deletes lessons)
 */
export async function DELETE(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify module exists and user owns the course
        const existingModule = await prisma.module.findFirst({
            where: {
                id: moduleId,
                courseId,
                course: {
                    instructorId: instructor.id,
                },
            },
        });

        if (!existingModule) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Module not found or access denied" },
                { status: 404 }
            );
        }

        // Delete module (cascade will delete lessons)
        await prisma.module.delete({
            where: { id: moduleId },
        });

        return NextResponse.json<ApiResponse>({
            success: true,
            message: "Module deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting module:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
