import { NextRequest, NextResponse } from "next/server";
import { prisma, QuizType } from "@repo/db";
import { requireInstructor } from "@repo/auth";
import type { ApiResponse, CreateQuizInput, QuizWithDetails } from "@repo/types";

export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId } = await params;

        // Verify ownership
        const course = await prisma.course.findUnique({
            where: { id: courseId, instructorId: userId },
        });

        if (!course) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Course not found or unauthorized" },
                { status: 404 }
            );
        }

        const quizzes = await prisma.quiz.findMany({
            where: { courseId },
            orderBy: { createdAt: "desc" },
            include: {
                _count: {
                    select: { questions: true },
                },
            },
        });

        return NextResponse.json<ApiResponse<QuizWithDetails[]>>({
            success: true,
            data: quizzes as unknown as QuizWithDetails[],
        });
    } catch (error) {
        console.error("Error fetching quizzes:", error);
        return NextResponse.json<ApiResponse<null>>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId } = await params;

        // Verify ownership
        console.log(`[POST /api/courses/${courseId}/quizzes] Checking ownership for user ${userId}`);
        const course = await prisma.course.findUnique({
            where: { id: courseId },
        });

        if (!course) {
            console.log(`[POST /api/courses/${courseId}/quizzes] Course not found`);
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Course not found" },
                { status: 404 }
            );
        }

        if (course.instructorId !== userId) {
            console.log(`[POST /api/courses/${courseId}/quizzes] Unauthorized: Course instructor ${course.instructorId} !== Request user ${userId}`);
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Unauthorized" },
                { status: 403 }
            );
        }

        if (!course) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Course not found or unauthorized" },
                { status: 404 }
            );
        }

        const body: Omit<CreateQuizInput, "courseId"> = await request.json();

        // specific validation for quizType
        if (body.quizType === QuizType.ENTRY_QUIZ || body.quizType === QuizType.FINAL_EXAM) {
            const existingQuiz = await prisma.quiz.findFirst({
                where: {
                    courseId,
                    quizType: body.quizType
                }
            });

            if (existingQuiz) {
                return NextResponse.json<ApiResponse<null>>(
                    { success: false, error: `A ${body.quizType} quiz already exists for this course` },
                    { status: 409 }
                );
            }
        }

        const quiz = await prisma.quiz.create({
            data: {
                courseId,
                title: body.title,
                description: body.description,
                quizType: body.quizType,
                passingScore: body.passingScore,
                maxAttempts: body.maxAttempts,
                timeLimit: body.timeLimit,
                isRandomized: body.isRandomized,
            },
        });

        // If it's ENTRY/FINAL, link it to the course
        if (body.quizType === QuizType.ENTRY_QUIZ) {
            await prisma.course.update({
                where: { id: courseId },
                data: { entryQuizId: quiz.id }
            });
        } else if (body.quizType === QuizType.FINAL_EXAM) {
            await prisma.course.update({
                where: { id: courseId },
                data: { finalExamId: quiz.id }
            });
        }

        return NextResponse.json<ApiResponse<QuizWithDetails>>({
            success: true,
            data: quiz as unknown as QuizWithDetails,
            message: "Quiz created successfully",
        });
    } catch (error) {
        console.error("Error creating quiz:", error);
        return NextResponse.json<ApiResponse<null>>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
