import { NextRequest, NextResponse } from "next/server";
import { prisma, QuestionType } from "@repo/db";
import { requireInstructor } from "@repo/auth";
import type { ApiResponse, CreateQuestionInput, Question } from "@repo/types";

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; quizId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, quizId } = await params;

        // Verify ownership
        const quiz = await prisma.quiz.findFirst({
            where: {
                id: quizId,
                courseId,
                course: { instructorId: userId },
            },
        });

        if (!quiz) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Quiz not found or unauthorized" },
                { status: 404 }
            );
        }

        const body: Omit<CreateQuestionInput, "quizId"> = await request.json();

        const lastQuestion = await prisma.question.findFirst({
            where: { quizId },
            orderBy: { orderIndex: "desc" },
        });

        const orderIndex = body.orderIndex ?? (lastQuestion ? lastQuestion.orderIndex + 1 : 0);

        const question = await prisma.question.create({
            data: {
                quizId,
                question: body.question,
                questionType: body.questionType,
                points: body.points,
                orderIndex,
                options: body.options ?? undefined,
                correctAnswer: body.correctAnswer,
                explanation: body.explanation,
                testCases: body.testCases ?? undefined,
                starterCode: body.starterCode,
                maxLength: body.maxLength,
            },
        });

        return NextResponse.json<ApiResponse<Question>>({
            success: true,
            data: question as unknown as Question,
            message: "Question added successfully",
        });
    } catch (error) {
        console.error("Error creating question:", error);
        return NextResponse.json<ApiResponse<null>>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
