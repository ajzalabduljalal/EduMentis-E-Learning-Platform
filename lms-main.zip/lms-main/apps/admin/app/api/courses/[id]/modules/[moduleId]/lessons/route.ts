import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import type { ApiResponse, CreateLessonInput, LessonWithDetails } from "@repo/types";

/**
 * GET /api/courses/[id]/modules/[moduleId]/lessons
 * List all lessons for a module
 */
export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify module exists and user owns the course
        const module = await prisma.module.findFirst({
            where: {
                id: moduleId,
                courseId,
                course: {
                    instructorId: instructor.id,
                },
            },
        });

        if (!module) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Module not found or access denied" },
                { status: 404 }
            );
        }

        // Get all lessons ordered by orderIndex
        const lessons = await prisma.lesson.findMany({
            where: { moduleId },
            orderBy: {
                orderIndex: "asc",
            },
        });

        return NextResponse.json<ApiResponse<LessonWithDetails[]>>({
            success: true,
            data: lessons as LessonWithDetails[],
        });
    } catch (error) {
        console.error("Error fetching lessons:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}

/**
 * POST /api/courses/[id]/modules/[moduleId]/lessons
 * Create a new lesson
 */
export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify module exists and user owns the course
        const module = await prisma.module.findFirst({
            where: {
                id: moduleId,
                courseId,
                course: {
                    instructorId: instructor.id,
                },
            },
        });

        if (!module) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Module not found or access denied" },
                { status: 404 }
            );
        }

        const body: Omit<CreateLessonInput, "moduleId"> = await request.json();

        // Validate required fields
        if (!body.title || !body.content || !body.track || !body.lessonType) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Title, content, track, and lesson type are required" },
                { status: 400 }
            );
        }

        // Get the highest orderIndex for auto-ordering
        const lastLesson = await prisma.lesson.findFirst({
            where: { moduleId },
            orderBy: { orderIndex: "desc" },
        });

        const orderIndex = body.orderIndex ?? (lastLesson ? lastLesson.orderIndex + 1 : 0);

        // Create lesson
        const lesson = await prisma.lesson.create({
            data: {
                moduleId,
                title: body.title,
                description: body.description,
                content: body.content,
                track: body.track,
                lessonType: body.lessonType,
                duration: body.duration,
                orderIndex,
                isFree: body.isFree ?? false,
                videoUrl: null, // Text lessons don't have videos
            },
        });

        return NextResponse.json<ApiResponse<LessonWithDetails>>({
            success: true,
            data: lesson as LessonWithDetails,
            message: "Lesson created successfully",
        });
    } catch (error) {
        console.error("Error creating lesson:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
