import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma, Track } from "@repo/db";
import type {
  ApiResponse,
  ModuleWithStats,
  CreateModuleInput,
  PaginatedResponse,
} from "@repo/types";

/**
 * GET /api/courses/[id]/modules
 * List all modules for a course
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { userId } = await requireInstructor();
    const { id: courseId } = await params;

    // Verify course exists and user owns it
    const course = await prisma.course.findUnique({
      where: { id: courseId },
    });

    if (!course) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Course not found" },
        { status: 404 },
      );
    }

    // Get instructor from database
    const instructor = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!instructor || course.instructorId !== instructor.id) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Forbidden - You do not own this course" },
        { status: 403 },
      );
    }

    // Get all modules with lesson count
    const modules = await prisma.module.findMany({
      where: { courseId },
      include: {
        _count: {
          select: {
            lessons: true,
          },
        },
      },
      orderBy: {
        orderIndex: "asc",
      },
    });

    return NextResponse.json<ApiResponse<ModuleWithStats[]>>({
      success: true,
      data: modules as ModuleWithStats[],
    });
  } catch (error) {
    console.error("Error fetching modules:", error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}

/**
 * POST /api/courses/[id]/modules
 * Create a new module
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { userId } = await requireInstructor();
    const { id: courseId } = await params;

    // Verify course exists and user owns it
    const course = await prisma.course.findUnique({
      where: { id: courseId },
    });

    if (!course) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Course not found" },
        { status: 404 },
      );
    }

    // Get instructor from database
    const instructor = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!instructor || course.instructorId !== instructor.id) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Forbidden - You do not own this course" },
        { status: 403 },
      );
    }

    const body: Omit<CreateModuleInput, "courseId"> = await request.json();

    // Validate required fields
    if (!body.title || !body.track) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Title and track are required" },
        { status: 400 },
      );
    }

    // Get the highest orderIndex for auto-ordering
    const lastModule = await prisma.module.findFirst({
      where: { courseId },
      orderBy: { orderIndex: "desc" },
    });

    const orderIndex =
      body.orderIndex ?? (lastModule ? lastModule.orderIndex + 1 : 0);

    // Create module
    const newModule = await prisma.module.create({
      data: {
        courseId,
        title: body.title,
        description: body.description,
        track: body.track,
        orderIndex,
      },
      include: {
        _count: {
          select: {
            lessons: true,
          },
        },
      },
    });

    return NextResponse.json<ApiResponse<ModuleWithStats>>({
      success: true,
      data: newModule as ModuleWithStats,
      message: "Module created successfully",
    });
  } catch (error) {
    console.error("Error creating module:", error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}
