import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import type { ApiResponse, ReorderModulesInput, ModuleWithStats } from "@repo/types";

/**
 * POST /api/courses/[id]/modules/reorder
 * Batch update module order
 */
export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify course exists and user owns it
        const course = await prisma.course.findFirst({
            where: {
                id: courseId,
                instructorId: instructor.id,
            },
        });

        if (!course) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Course not found or access denied" },
                { status: 404 }
            );
        }

        const body: Omit<ReorderModulesInput, "courseId"> = await request.json();

        if (!body.modules || !Array.isArray(body.modules)) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Invalid request: modules array required" },
                { status: 400 }
            );
        }

        // Update all modules in a transaction
        await prisma.$transaction(
            body.modules.map((module) =>
                prisma.module.update({
                    where: { id: module.id },
                    data: { orderIndex: module.orderIndex },
                })
            )
        );

        // Fetch updated modules
        const modules = await prisma.module.findMany({
            where: { courseId },
            include: {
                _count: {
                    select: {
                        lessons: true,
                    },
                },
            },
            orderBy: {
                orderIndex: "asc",
            },
        });

        return NextResponse.json<ApiResponse<ModuleWithStats[]>>({
            success: true,
            data: modules as ModuleWithStats[],
            message: "Modules reordered successfully",
        });
    } catch (error) {
        console.error("Error reordering modules:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
