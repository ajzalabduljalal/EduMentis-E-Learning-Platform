import { NextRequest, NextResponse } from "next/server";
import { prisma, QuizType } from "@repo/db";
import { requireInstructor, getCurrentDbUser } from "@repo/auth";
import type {
  ApiResponse,
  QuizWithDetails,
  UpdateQuizInput,
} from "@repo/types";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; quizId: string }> },
) {
  try {
    await requireInstructor();
    const dbUser = await getCurrentDbUser();
    const { id: courseId, quizId } = await params;

    if (!dbUser) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "User not found in database" },
        { status: 401 },
      );
    }

    const quiz = await prisma.quiz.findFirst({
      where: {
        id: quizId,
        courseId,
        course: {
          instructor: {
            email: dbUser.email, // Check by email instead of ID
          },
        },
      },
      include: {
        questions: {
          orderBy: { orderIndex: "asc" },
        },
      },
    });

    if (!quiz) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "Quiz not found" },
        { status: 404 },
      );
    }

    return NextResponse.json<
      ApiResponse<QuizWithDetails & { questions: any[] }>
    >({
      success: true,
      data: quiz as unknown as QuizWithDetails & { questions: any[] },
    });
  } catch (error) {
    console.error("Error fetching quiz:", error);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; quizId: string }> },
) {
  try {
    await requireInstructor();
    const dbUser = await getCurrentDbUser();
    const { id: courseId, quizId } = await params;

    if (!dbUser) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "User not found in database" },
        { status: 401 },
      );
    }

    // Verify ownership by email
    const existingQuiz = await prisma.quiz.findFirst({
      where: {
        id: quizId,
        courseId,
        course: {
          instructor: {
            email: dbUser.email, // Check by email instead of ID
          },
        },
      },
    });

    if (!existingQuiz) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "Quiz not found or unauthorized" },
        { status: 404 },
      );
    }

    const body: Omit<UpdateQuizInput, "id"> = await request.json();

    const quiz = await prisma.quiz.update({
      where: { id: quizId },
      data: {
        title: body.title,
        description: body.description,
        quizType: body.quizType,
        passingScore: body.passingScore,
        maxAttempts: body.maxAttempts,
        timeLimit: body.timeLimit,
        isRandomized: body.isRandomized,
      },
      include: {
        _count: {
          select: { questions: true },
        },
      },
    });

    return NextResponse.json<ApiResponse<QuizWithDetails>>({
      success: true,
      data: quiz as unknown as QuizWithDetails,
      message: "Quiz updated successfully",
    });
  } catch (error) {
    console.error("Error updating quiz:", error);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; quizId: string }> },
) {
  try {
    await requireInstructor();
    const dbUser = await getCurrentDbUser();
    const { id: courseId, quizId } = await params;

    if (!dbUser) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "User not found in database" },
        { status: 401 },
      );
    }

    // Verify ownership by email
    const existingQuiz = await prisma.quiz.findFirst({
      where: {
        id: quizId,
        courseId,
        course: {
          instructor: {
            email: dbUser.email, // Check by email instead of ID
          },
        },
      },
    });

    if (!existingQuiz) {
      return NextResponse.json<ApiResponse<null>>(
        { success: false, error: "Quiz not found or unauthorized" },
        { status: 404 },
      );
    }

    // Check if it's an Entry or Final quiz and unlink from course if needed
    // Actually, on delete set null in course or cascade?
    // Prisma relation might handle it if set to SetNull on delete.
    // But safely:
    if (existingQuiz.quizType === QuizType.ENTRY_QUIZ) {
      await prisma.course.update({
        where: { id: courseId },
        data: { entryQuizId: null },
      });
    } else if (existingQuiz.quizType === QuizType.FINAL_EXAM) {
      await prisma.course.update({
        where: { id: courseId },
        data: { finalExamId: null },
      });
    }

    await prisma.quiz.delete({
      where: { id: quizId },
    });

    return NextResponse.json<ApiResponse<null>>({
      success: true,
      message: "Quiz deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting quiz:", error);
    return NextResponse.json<ApiResponse<null>>(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}
