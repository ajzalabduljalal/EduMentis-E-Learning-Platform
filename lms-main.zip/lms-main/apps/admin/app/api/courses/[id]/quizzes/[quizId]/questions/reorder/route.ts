import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@repo/db";
import { requireInstructor } from "@repo/auth";
import type { ApiResponse, ReorderQuestionsInput, Question } from "@repo/types";

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; quizId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, quizId } = await params;

        // Verify ownership
        const quiz = await prisma.quiz.findFirst({
            where: {
                id: quizId,
                courseId,
                course: { instructorId: userId },
            },
        });

        if (!quiz) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Quiz not found or unauthorized" },
                { status: 404 }
            );
        }

        const body: Omit<ReorderQuestionsInput, "quizId"> = await request.json();

        if (!body.questions || !Array.isArray(body.questions)) {
            return NextResponse.json<ApiResponse<null>>(
                { success: false, error: "Invalid input" },
                { status: 400 }
            );
        }

        // Process reordering in a transaction
        await prisma.$transaction(
            body.questions.map((question) =>
                prisma.question.update({
                    where: { id: question.id },
                    data: { orderIndex: question.orderIndex },
                })
            )
        );

        const questions = await prisma.question.findMany({
            where: { quizId },
            orderBy: { orderIndex: "asc" },
        });

        return NextResponse.json<ApiResponse<Question[]>>({
            success: true,
            data: questions as unknown as Question[],
            message: "Questions reordered successfully",
        });
    } catch (error) {
        console.error("Error reordering questions:", error);
        return NextResponse.json<ApiResponse<null>>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
