import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma } from "@repo/db";
import type { ApiResponse, ReorderLessonsInput, LessonWithDetails } from "@repo/types";

/**
 * POST /api/courses/[id]/modules/[moduleId]/lessons/reorder
 * Batch update lesson order
 */
export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ id: string; moduleId: string }> }
) {
    try {
        const { userId } = await requireInstructor();
        const { id: courseId, moduleId } = await params;

        // Get instructor from database
        const instructor = await prisma.user.findUnique({
            where: { clerkId: userId },
        });

        if (!instructor) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Instructor not found" },
                { status: 404 }
            );
        }

        // Verify module exists and user owns the course
        const module = await prisma.module.findFirst({
            where: {
                id: moduleId,
                courseId,
                course: {
                    instructorId: instructor.id,
                },
            },
        });

        if (!module) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Module not found or access denied" },
                { status: 404 }
            );
        }

        const body: Omit<ReorderLessonsInput, "moduleId"> = await request.json();

        if (!body.lessons || !Array.isArray(body.lessons)) {
            return NextResponse.json<ApiResponse>(
                { success: false, error: "Invalid request: lessons array required" },
                { status: 400 }
            );
        }

        // Update all lessons in a transaction
        await prisma.$transaction(
            body.lessons.map((lesson) =>
                prisma.lesson.update({
                    where: { id: lesson.id },
                    data: { orderIndex: lesson.orderIndex },
                })
            )
        );

        // Fetch updated lessons
        const lessons = await prisma.lesson.findMany({
            where: { moduleId },
            orderBy: {
                orderIndex: "asc",
            },
        });

        return NextResponse.json<ApiResponse<LessonWithDetails[]>>({
            success: true,
            data: lessons as LessonWithDetails[],
            message: "Lessons reordered successfully",
        });
    } catch (error) {
        console.error("Error reordering lessons:", error);
        return NextResponse.json<ApiResponse>(
            { success: false, error: "Internal server error" },
            { status: 500 }
        );
    }
}
