import { NextRequest, NextResponse } from "next/server";
import { requireInstructor, currentUser } from "@repo/auth";
import { prisma, CourseStatus, CourseLevel } from "@repo/db";
import type {
  ApiResponse,
  CreateCourseInput,
  CourseWithStats,
  PaginatedResponse,
} from "@repo/types";

/**
 * GET /api/courses
 * List all courses (with pagination and filters)
 */
export async function GET(request: NextRequest) {
  try {
    const { userId } = await requireInstructor();

    let instructor = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!instructor) {
      const user = await currentUser();
      const email =
        user?.emailAddresses?.[0]?.emailAddress || `${userId}@placeholder.com`;

      // Check if user exists by email (may have been created via different auth)
      const existingByEmail = await prisma.user.findUnique({
        where: { email },
      });

      if (existingByEmail) {
        // Update existing user with clerkId
        instructor = await prisma.user.update({
          where: { id: existingByEmail.id },
          data: { clerkId: userId },
        });
      } else {
        // Create new user
        instructor = await prisma.user.create({
          data: {
            clerkId: userId,
            email,
            role: "INSTRUCTOR",
          },
        });
      }
    }

    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "10");
    const status = searchParams.get("status") as CourseStatus | null;
    const search = searchParams.get("search") || "";

    const where: any = {
      instructorId: instructor.id,
    };

    if (status) {
      where.status = status;
    }

    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
      ];
    }

    const total = await prisma.course.count({ where });

    const courses = await prisma.course.findMany({
      where,
      include: {
        _count: {
          select: {
            modules: true,
            userProgress: true,
          },
        },
      },
      orderBy: {
        updatedAt: "desc",
      },
      skip: (page - 1) * pageSize,
      take: pageSize,
    });

    const response: PaginatedResponse<CourseWithStats> = {
      items: courses as CourseWithStats[],
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize),
    };

    return NextResponse.json<ApiResponse<PaginatedResponse<CourseWithStats>>>({
      success: true,
      data: response,
    });
  } catch (error) {
    console.error("Error fetching courses:", error);
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json<ApiResponse>(
      {
        success: false,
        error: `Failed to fetch courses: ${errorMessage}`,
      },
      { status: 500 },
    );
  }
}

/**
 * POST /api/courses
 * Create a new course
 */
export async function POST(request: NextRequest) {
  try {
    const { userId } = await requireInstructor();

    let instructor = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!instructor) {
      const user = await currentUser();
      const email =
        user?.emailAddresses?.[0]?.emailAddress || `${userId}@placeholder.com`;

      // Check if user exists by email (may have been created via different auth)
      const existingByEmail = await prisma.user.findUnique({
        where: { email },
      });

      if (existingByEmail) {
        // Update existing user with clerkId
        instructor = await prisma.user.update({
          where: { id: existingByEmail.id },
          data: { clerkId: userId },
        });
      } else {
        // Create new user
        instructor = await prisma.user.create({
          data: {
            clerkId: userId,
            email,
            role: "INSTRUCTOR",
          },
        });
      }
    }

    const body: CreateCourseInput = await request.json();

    if (!body.title || !body.slug) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Title and slug are required" },
        { status: 400 },
      );
    }

    const existingCourse = await prisma.course.findUnique({
      where: { slug: body.slug },
    });

    if (existingCourse) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "A course with this slug already exists" },
        { status: 409 },
      );
    }

    const course = await prisma.course.create({
      data: {
        title: body.title,
        slug: body.slug,
        description: body.description,
        shortDescription: body.shortDescription,
        imageUrl: body.imageUrl,
        price: body.price || 0,
        status: body.status || CourseStatus.DRAFT,
        level: body.level || CourseLevel.BEGINNER,
        category: body.category,
        duration: body.duration,
        instructorId: instructor.id,
        publishedAt: body.status === CourseStatus.PUBLISHED ? new Date() : null,
      },
      include: {
        _count: {
          select: {
            modules: true,
            userProgress: true,
          },
        },
      },
    });

    return NextResponse.json<ApiResponse<CourseWithStats>>({
      success: true,
      data: course as CourseWithStats,
      message: "Course created successfully",
    });
  } catch (error) {
    console.error("Error creating course:", error);
    const errorMessage =
      error instanceof Error ? error.message : "Unknown error";
    return NextResponse.json<ApiResponse>(
      {
        success: false,
        error: `Failed to create course: ${errorMessage}`,
      },
      { status: 500 },
    );
  }
}
