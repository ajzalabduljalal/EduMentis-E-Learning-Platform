import { NextRequest, NextResponse } from "next/server";
import { prisma, AssessmentStatus } from "@repo/db";
import { auth } from "@clerk/nextjs/server";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ attemptId: string }> },
) {
  try {
    const { attemptId } = await params;
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get user and check if admin
    const user = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!user || (user.role !== "ADMIN" && user.role !== "INSTRUCTOR")) {
      return NextResponse.json(
        { success: false, error: "Forbidden" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { grades, feedback, totalScore } = body as {
      grades: Record<string, number>;
      feedback?: string;
      totalScore: number;
    };

    // Get assessment attempt
    const attempt = await prisma.assessmentAttempt.findUnique({
      where: { id: attemptId },
    });

    if (!attempt) {
      return NextResponse.json(
        { success: false, error: "Assessment attempt not found" },
        { status: 404 },
      );
    }

    // Get course
    const course = await prisma.course.findUnique({
      where: { id: attempt.courseId },
      include: {
        finalExam: true,
      },
    });

    if (!course || !course.finalExam) {
      return NextResponse.json(
        { success: false, error: "Course or final exam not found" },
        { status: 404 },
      );
    }

    // Determine if passed
    const isPassed = totalScore >= course.finalExam.passingScore;
    const status = isPassed ? AssessmentStatus.PASSED : AssessmentStatus.FAILED;

    // Update assessment attempt
    await prisma.assessmentAttempt.update({
      where: { id: attemptId },
      data: {
        status,
        score: totalScore,
        feedback: feedback || null,
        gradedAt: new Date(),
      },
    });

    // Update quiz attempt answers with manual grades
    const quizAttempt = await prisma.quizAttempt.findFirst({
      where: {
        userId: attempt.userId,
        quizId: course.finalExam.id,
      },
      orderBy: {
        completedAt: "desc",
      },
    });

    if (quizAttempt) {
      // Update individual question answers
      for (const [questionId, points] of Object.entries(grades)) {
        await prisma.questionAnswer.updateMany({
          where: {
            attemptId: quizAttempt.id,
            questionId: questionId,
          },
          data: {
            pointsEarned: points,
            isCorrect: points > 0,
          },
        });
      }

      // Update quiz attempt score
      await prisma.quizAttempt.update({
        where: { id: quizAttempt.id },
        data: {
          score: totalScore,
          isPassed,
        },
      });
    }

    // If passed, generate certificate
    if (isPassed) {
      try {
        const certResponse = await fetch(
          `${process.env.NEXT_PUBLIC_WEB_URL || "http://localhost:3000"}/api/certificates/generate`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              userId: attempt.userId,
              courseId: course.id,
              attemptId: attempt.id,
            }),
          },
        );

        if (!certResponse.ok) {
          console.error("Failed to generate certificate");
        }
      } catch (error) {
        console.error("Certificate generation error:", error);
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        status,
        score: totalScore,
        isPassed,
      },
    });
  } catch (error) {
    console.error("Error grading assessment:", error);
    return NextResponse.json(
      { success: false, error: "Failed to grade assessment" },
      { status: 500 },
    );
  }
}
