import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma, AssessmentStatus } from "@repo/db";

/**
 * GET /api/assessments/pending
 * Get all assessments pending manual review
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    await requireInstructor();

    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get("status") as AssessmentStatus | null;

    const where: any = {};

    if (status) {
      where.status = status;
    } else {
      // Default to showing GRADING and PENDING
      where.status = {
        in: [AssessmentStatus.GRADING, AssessmentStatus.PENDING],
      };
    }

    const assessments = await prisma.assessmentAttempt.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            email: true,
            name: true,
          },
        },
      },
      orderBy: {
        submittedAt: "desc",
      },
    });

    // Get answers for each assessment
    const assessmentsWithAnswers = await Promise.all(
      assessments.map(async (assessment) => {
        // Get course with final exam
        const course = await prisma.course.findUnique({
          where: { id: assessment.courseId },
          include: {
            finalExam: {
              include: {
                questions: true,
              },
            },
          },
        });

        // Find the corresponding quiz attempt
        const quizAttempt = await prisma.quizAttempt.findFirst({
          where: {
            userId: assessment.userId,
            quizId: course?.finalExamId || "",
          },
          orderBy: {
            startedAt: "desc",
          },
          include: {
            answers: {
              include: {
                question: true,
              },
            },
          },
        });

        return {
          ...assessment,
          courseDetails: course,
          answers: quizAttempt?.answers || [],
        };
      }),
    );

    return NextResponse.json({
      success: true,
      data: assessmentsWithAnswers,
    });
  } catch (error) {
    console.error("Error fetching pending assessments:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch assessments" },
      { status: 500 },
    );
  }
}
