import { NextRequest, NextResponse } from "next/server";
import { requireInstructor } from "@repo/auth";
import { prisma, AssessmentStatus } from "@repo/db";

interface GradeData {
  attemptId: string;
  score: number;
  feedback?: string;
  status: "PASSED" | "FAILED";
}

/**
 * POST /api/admin/assessments/grade
 * Grade a manual assessment
 */
export async function POST(request: NextRequest) {
  try {
    await requireInstructor();

    const body: GradeData = await request.json();
    const { attemptId, score, feedback, status } = body;

    if (!attemptId || score === undefined || !status) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Update assessment attempt
    const attempt = await prisma.assessmentAttempt.update({
      where: { id: attemptId },
      data: {
        score,
        feedback,
        status:
          status === "PASSED"
            ? AssessmentStatus.PASSED
            : AssessmentStatus.FAILED,
        gradedAt: new Date(),
      },
      include: {
        user: true,
      },
    });

    // Get course
    const course = await prisma.course.findUnique({
      where: { id: attempt.courseId },
      select: {
        id: true,
        title: true,
        slug: true,
      },
    });

    // If passed, trigger certificate generation
    if (status === "PASSED" && course) {
      try {
        const certResponse = await fetch(
          `${process.env.NEXT_PUBLIC_WEB_URL || "http://localhost:3000"}/api/certificates/generate`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              userId: attempt.userId,
              courseId: course.id,
              attemptId: attempt.id,
            }),
          },
        );

        if (!certResponse.ok) {
          console.error("Failed to generate certificate");
        }
      } catch (error) {
        console.error("Certificate generation error:", error);
      }

      // Mark course as completed
      await prisma.userCourseProgress.update({
        where: {
          userId_courseId: {
            userId: attempt.userId,
            courseId: course.id,
          },
        },
        data: {
          isCompleted: true,
          completedAt: new Date(),
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: attempt,
      message: "Assessment graded successfully",
    });
  } catch (error) {
    console.error("Error grading assessment:", error);
    return NextResponse.json(
      { success: false, error: "Failed to grade assessment" },
      { status: 500 },
    );
  }
}
