import { NextResponse } from "next/server";
import { auth } from "@repo/auth";
import { prisma } from "@repo/db";

/**
 * GET /api/analytics/overview
 *
 * Returns overview statistics for admin dashboard
 */
export async function GET() {
  try {
    const authResult = await auth();

    if (!authResult?.userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // TODO: Check if user is admin/instructor
    // For now, we'll allow any authenticated user

    // Get total counts
    const [
      totalCourses,
      publishedCourses,
      totalEnrollments,
      completedEnrollments,
      totalQuizAttempts,
      totalAssessmentAttempts,
    ] = await Promise.all([
      prisma.course.count(),
      prisma.course.count({ where: { status: "PUBLISHED" } }),
      prisma.userCourseProgress.count(),
      prisma.userCourseProgress.count({ where: { isCompleted: true } }),
      prisma.quizAttempt.count(),
      prisma.assessmentAttempt.count(),
    ]);

    // Calculate completion rate
    const completionRate =
      totalEnrollments > 0
        ? Math.round((completedEnrollments / totalEnrollments) * 100)
        : 0;

    // Get unique students count
    const uniqueStudents = await prisma.userCourseProgress.findMany({
      distinct: ["userId"],
      select: { userId: true },
    });

    // Get recent enrollments (last 7 days)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

    const recentEnrollments = await prisma.userCourseProgress.count({
      where: {
        enrolledAt: {
          gte: sevenDaysAgo,
        },
      },
    });

    // Get average quiz score
    const quizScores = await prisma.quizAttempt.aggregate({
      _avg: {
        score: true,
      },
    });

    // Get course with most enrollments
    const courseEnrollments = await prisma.userCourseProgress.groupBy({
      by: ["courseId"],
      _count: {
        id: true,
      },
      orderBy: {
        _count: {
          id: "desc",
        },
      },
      take: 5,
    });

    // Get course details for top courses
    const topCourseIds = courseEnrollments.map((ce) => ce.courseId);
    const topCourses = await prisma.course.findMany({
      where: {
        id: {
          in: topCourseIds,
        },
      },
      select: {
        id: true,
        title: true,
      },
    });

    const topCoursesWithCounts = courseEnrollments.map((ce) => {
      const course = topCourses.find((c) => c.id === ce.courseId);
      return {
        courseId: ce.courseId,
        courseName: course?.title || "Unknown Course",
        enrollmentCount: ce._count.id,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        overview: {
          totalCourses,
          publishedCourses,
          totalEnrollments,
          completedEnrollments,
          completionRate,
          totalStudents: uniqueStudents.length,
          recentEnrollments,
          averageQuizScore: quizScores._avg.score
            ? Math.round(quizScores._avg.score)
            : 0,
          totalQuizAttempts,
          totalAssessmentAttempts,
        },
        topCourses: topCoursesWithCounts,
      },
    });
  } catch (error) {
    console.error("Analytics overview error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch analytics" },
      { status: 500 },
    );
  }
}
