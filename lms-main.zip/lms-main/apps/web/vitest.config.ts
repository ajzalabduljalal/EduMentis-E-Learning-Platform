import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import path from "path";

export default defineConfig({
  plugins: [react()],
  test: {
    globals: true,
    environment: "jsdom",
    setupFiles: ["./vitest.setup.ts"],
    include: ["**/*.test.{ts,tsx}", "**/*.spec.{ts,tsx}"],
    coverage: {
      provider: "v8",
      reporter: ["text", "json", "html"],
      exclude: ["node_modules/", ".next/", "**/*.config.{js,ts}", "**/*.d.ts"],
    },
  },
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./"),
      "@repo/ui": path.resolve(__dirname, "../../packages/ui/src"),
      "@repo/db": path.resolve(__dirname, "../../packages/database/src"),
      "@repo/auth": path.resolve(__dirname, "../../packages/auth/src"),
      "@repo/types": path.resolve(__dirname, "../../packages/types/src"),
      "@repo/ai": path.resolve(__dirname, "../../packages/ai/src"),
    },
  },
});
