import { SignUp } from "@clerk/nextjs";
import Link from "next/link";
import { Zap, Brain, Sparkles } from "lucide-react";

export default function SignUpPage() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[40%_60%] h-screen overflow-hidden">
      {/* Left Side - Marketing Content */}
      <div
        className="hidden lg:flex flex-col justify-between p-12 xl:p-16 overflow-hidden"
        style={{
          backgroundImage: "url('/signup-bg.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* Logo */}
        <div>
          <Link
            href="/"
            className="inline-block text-2xl font-normal text-text-primary hover:opacity-80 transition-opacity"
          >
            Edumentis
          </Link>
        </div>

        {/* Hero Content */}
        <div className="max-w-md">
          <div className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-normal text-text-primary border border-zinc-200 mb-8">
            <Sparkles className="h-4 w-4 text-accent" />
            AI-Powered Learning
          </div>

          <h1 className="text-4xl xl:text-5xl font-light tracking-tight text-text-primary mb-6">
            Start your{" "}
            <span className="font-normal">personalized learning journey</span>
          </h1>
          <p className="text-lg text-text-secondary leading-relaxed font-light mb-12">
            Join thousands of learners getting adaptive courses, AI tutoring,
            and recognized certificates. No credit card required.
          </p>

          {/* Feature Cards */}
          <div className="grid grid-cols-2 gap-4 mt-12">
            <div className="rounded-lg border border-zinc-200 bg-white p-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent/10 mb-3">
                <Zap className="h-4 w-4 text-text-primary" />
              </div>
              <p className="text-sm font-normal text-text-primary mb-1">
                Smart Adaptation
              </p>
              <p className="text-xs text-text-secondary font-light">
                Content adjusts to you
              </p>
            </div>

            <div className="rounded-lg border border-zinc-200 bg-white p-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-accent/10 mb-3">
                <Brain className="h-4 w-4 text-text-primary" />
              </div>
              <p className="text-sm font-normal text-text-primary mb-1">
                AI Assistance
              </p>
              <p className="text-xs text-text-secondary font-light">
                Always ready to help
              </p>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="max-w-md">
          <div className="grid grid-cols-3 gap-8 rounded-lg border border-zinc-200 bg-white p-6">
            <div className="text-center">
              <div className="text-2xl font-light text-text-primary">10K+</div>
              <div className="text-xs text-text-secondary mt-1 font-light">
                Students
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-light text-text-primary">95%</div>
              <div className="text-xs text-text-secondary mt-1 font-light">
                Completion
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-light text-text-primary">50+</div>
              <div className="text-xs text-text-secondary mt-1 font-light">
                Courses
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Sign Up Form */}
      <div className="flex flex-col items-center p-6 sm:p-12 bg-white overflow-y-auto min-w-0">
        <div className="w-full max-w-md my-auto py-8">
          {/* Mobile Logo */}
          <div className="lg:hidden mb-8">
            <Link
              href="/"
              className="inline-block text-2xl font-normal text-text-primary hover:opacity-80 transition-opacity"
            >
              Edumentis
            </Link>
          </div>

          {/* Sign Up Component */}
          <div className="w-full">
            <div className="mb-8 text-center">
              <h2 className="text-3xl font-light text-text-primary mb-3">
                Create your account
              </h2>
              <p className="text-base text-text-secondary font-light">
                Get started with adaptive learning today
              </p>
            </div>

            <SignUp
              appearance={{
                elements: {
                  rootBox: "mx-auto",
                  card: "shadow-none border border-zinc-200",
                  formButtonPrimary:
                    "bg-text-primary hover:bg-text-primary/90 text-sm font-medium",
                  footerActionLink:
                    "text-text-primary hover:text-text-primary/80",
                  footer: {
                    display: "none",
                  },
                },
              }}
            />

            {/* Sign In Link */}
            <div className="mt-8 text-center">
              <p className="text-sm text-text-secondary font-light">
                Already have an account?{" "}
                <Link
                  href="/sign-in"
                  className="font-medium text-text-primary hover:underline"
                >
                  Sign in
                </Link>
              </p>
            </div>

            {/* Trust Signals */}
            <div className="mt-8 pt-6 border-t border-zinc-200">
              <p className="text-xs text-center text-text-secondary font-light">
                By signing up, you agree to our Terms of Service and Privacy
                Policy. Free to start, no credit card required.
              </p>
            </div>
          </div>

          {/* Back to Home Link */}
          <div className="mt-8 text-center">
            <Link
              href="/"
              className="text-sm text-text-secondary hover:text-text-primary transition-colors font-light"
            >
              ← Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
