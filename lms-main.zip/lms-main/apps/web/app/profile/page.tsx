import { UserProfile } from "@clerk/nextjs";

export default function ProfilePage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-50 py-12">
      <UserProfile
        appearance={{
          elements: {
            rootBox: "w-full max-w-4xl",
            card: "shadow-lg",
          },
        }}
      />
    </div>
  );
}
