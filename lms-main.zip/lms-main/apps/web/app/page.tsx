import Link from "next/link";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import {
  ArrowRight,
  Zap,
  Brain,
  Award,
  BookOpen,
  TrendingUp,
  CheckCircle,
  FileCheck,
  Users,
  BarChart3,
  Sparkles,
} from "lucide-react";

export default async function Home() {
  const { userId } = await auth();

  // If user is already signed in, redirect to dashboard
  if (userId) {
    redirect("/dashboard");
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Floating Navigation */}
      <div className="sticky top-4 z-50 px-4 sm:px-6 pt-4 mb-8">
        <nav className="mx-auto max-w-5xl bg-white border border-zinc-200 rounded-full shadow-sm">
          <div className="px-6 py-1">
            <div className="flex items-center justify-between">
              <div className="text-xl font-normal text-text-primary">
                Edumentis
              </div>
              <div className="flex items-center gap-4">
                <Link
                  href="/sign-in"
                  className="text-sm font-normal text-text-secondary hover:text-text-primary transition-colors"
                >
                  Sign In
                </Link>
                <Link
                  href="/sign-up"
                  className="rounded-lg bg-accent px-4 py-2 text-sm font-medium text-text-primary hover:bg-accent-hover transition-colors"
                >
                  Get Started
                </Link>
              </div>
            </div>
          </div>
        </nav>
      </div>

      {/* Hero Section */}
      <section className="relative mx-auto max-w-7xl px-6 pt-16 pb-12 sm:pt-24 sm:pb-16 overflow-hidden">
        {/* Radial gradient fade background - bright center fading to light edges */}
        <div
          className="absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(ellipse at center, #7FFFC3 0%, #B6FFDD 40%, #ABCCBD 70%, rgba(171, 204, 189, 0.3) 100%)",
            opacity: 0.6,
          }}
        />

        {/* Curved wave pattern at top (SVG for crisp rendering) */}
        <div className="absolute top-0 left-0 right-0 -z-10 h-32">
          <svg
            className="w-full h-full"
            viewBox="0 0 1440 120"
            preserveAspectRatio="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <defs>
              <pattern
                id="diagonal-stripes"
                x="0"
                y="0"
                width="20"
                height="20"
                patternUnits="userSpaceOnUse"
                patternTransform="rotate(45)"
              >
                <rect
                  x="0"
                  y="0"
                  width="10"
                  height="20"
                  fill="rgba(167, 243, 208, 0.3)"
                />
              </pattern>
            </defs>
            <path
              d="M0,0 L1440,0 L1440,80 Q1080,100 720,80 Q360,60 0,80 Z"
              fill="url(#diagonal-stripes)"
              opacity="0.5"
            />
            <path
              d="M0,80 Q360,60 720,80 Q1080,100 1440,80 L1440,0 L0,0 Z"
              fill="none"
              stroke="rgba(167, 243, 208, 0.4)"
              strokeWidth="2"
              strokeDasharray="8,8"
            />
          </svg>
        </div>
        <div className="mx-auto max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-normal text-text-primary border border-zinc-200 mb-8">
            <Sparkles className="h-4 w-4 text-accent" />
            AI-Powered Adaptive Learning
          </div>
          <h1 className="text-5xl font-light tracking-tight text-text-primary sm:text-6xl lg:text-7xl mb-6">
            Learn Smarter with{" "}
            <span className="font-normal">Personalized Learning Paths</span>
          </h1>
          <p className="text-lg text-text-secondary leading-relaxed max-w-3xl mx-auto font-light">
            Experience intelligent course adaptation that matches your skill
            level. Get AI-powered tutoring, track your progress in real-time,
            and earn recognized certificates upon completion.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/courses"
              className="group inline-flex items-center gap-2 rounded-lg bg-text-primary px-8 py-4 text-base font-medium text-white hover:bg-text-primary/90 transition-all duration-200 w-full sm:w-auto justify-center"
            >
              Browse Courses
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/sign-up"
              className="rounded-lg border-2 border-text-primary bg-white px-8 py-4 text-base font-medium text-text-primary hover:bg-text-primary hover:text-white transition-all duration-200 w-full sm:w-auto text-center"
            >
              Get Started Free
            </Link>
          </div>

          {/* Stats Section */}
          <div className="mt-16 pt-8 border-t border-zinc-200/50">
            <div className="grid grid-cols-3 gap-8">
              <div className="text-center">
                <div className="text-3xl font-light text-text-primary">
                  10K+
                </div>
                <div className="text-sm text-text-secondary mt-1 font-light">
                  Active Students
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-text-primary">95%</div>
                <div className="text-sm text-text-secondary mt-1 font-light">
                  Completion Rate
                </div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-light text-text-primary">50+</div>
                <div className="text-sm text-text-secondary mt-1 font-light">
                  Expert Courses
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="mx-auto max-w-7xl px-6 py-24 bg-white">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-light tracking-tight text-text-primary sm:text-4xl">
            Everything You Need to Succeed
          </h2>
          <p className="mt-4 text-lg text-text-secondary max-w-2xl mx-auto font-light">
            Our platform combines cutting-edge AI technology with proven
            learning methodologies to deliver an exceptional educational
            experience.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {/* Feature 1 */}
          <div className="group rounded-lg border border-zinc-200 bg-white p-8 hover:border-accent transition-all duration-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <Zap className="h-5 w-5 text-text-primary" />
            </div>
            <h3 className="mt-6 text-lg font-normal text-text-primary">
              Adaptive Learning Paths
            </h3>
            <p className="mt-2 text-sm text-text-secondary leading-relaxed font-light">
              Take an entry quiz and get automatically assigned to Basic or
              Advanced tracks based on your performance. Learn at the perfect
              pace for your skill level.
            </p>
          </div>

          {/* Feature 2 */}
          <div className="group rounded-lg border border-zinc-200 bg-white p-8 hover:border-accent transition-all duration-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <Brain className="h-5 w-5 text-text-primary" />
            </div>
            <h3 className="mt-6 text-lg font-normal text-text-primary">
              AI-Powered Tutoring
            </h3>
            <p className="mt-2 text-sm text-text-secondary leading-relaxed font-light">
              Get instant, context-aware help from our Google Gemini-powered AI
              tutor that understands your course content and learning progress.
            </p>
          </div>

          {/* Feature 3 */}
          <div className="group rounded-lg border border-zinc-200 bg-white p-8 hover:border-accent transition-all duration-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <BookOpen className="h-5 w-5 text-text-primary" />
            </div>
            <h3 className="mt-6 text-lg font-normal text-text-primary">
              Rich Course Content
            </h3>
            <p className="mt-2 text-sm text-text-secondary leading-relaxed font-light">
              Engage with interactive modules and lessons featuring rich text,
              code examples, embedded media, and downloadable resources.
            </p>
          </div>

          {/* Feature 4 */}
          <div className="group rounded-lg border border-zinc-200 bg-white p-8 hover:border-accent transition-all duration-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <TrendingUp className="h-5 w-5 text-text-primary" />
            </div>
            <h3 className="mt-6 text-lg font-normal text-text-primary">
              Progress Tracking
            </h3>
            <p className="mt-2 text-sm text-text-secondary leading-relaxed font-light">
              Monitor your learning journey with detailed progress indicators,
              completion tracking, and visual dashboards showing your
              achievements.
            </p>
          </div>

          {/* Feature 5 */}
          <div className="group rounded-lg border border-zinc-200 bg-white p-8 hover:border-accent transition-all duration-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <FileCheck className="h-5 w-5 text-text-primary" />
            </div>
            <h3 className="mt-6 text-lg font-normal text-text-primary">
              Smart Assessments
            </h3>
            <p className="mt-2 text-sm text-text-secondary leading-relaxed font-light">
              Complete diverse assessments including MCQs, coding challenges,
              and text responses. Enjoy instant auto-grading for objective
              questions.
            </p>
          </div>

          {/* Feature 6 */}
          <div className="group rounded-lg border border-zinc-200 bg-white p-8 hover:border-accent transition-all duration-200">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <Award className="h-5 w-5 text-text-primary" />
            </div>
            <h3 className="mt-6 text-lg font-normal text-text-primary">
              Verified Certificates
            </h3>
            <p className="mt-2 text-sm text-text-secondary leading-relaxed font-light">
              Earn professionally designed PDF certificates upon course
              completion to showcase your achievements and skills.
            </p>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section
        className="relative mx-auto max-w-7xl px-6 py-24"
        style={{
          background:
            "repeating-linear-gradient(-45deg, rgb(203, 226, 219), rgb(203, 226, 219) 1px, rgba(0, 0, 0, 0) 0px, rgba(0, 0, 0, 0) 8px)",
        }}
      >
        <div className="text-center mb-16">
          <h2 className="text-3xl font-light tracking-tight text-text-primary sm:text-4xl">
            How It Works
          </h2>
          <p className="mt-4 text-lg text-text-secondary max-w-2xl mx-auto font-light">
            Start learning in minutes with our streamlined process designed to
            maximize your educational outcomes.
          </p>
        </div>

        <div className="grid gap-12 md:grid-cols-2 lg:grid-cols-4">
          {/* Step 1 */}
          <div className="relative group">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-text-primary text-white text-lg font-normal mb-4">
                1
              </div>
              <h3 className="text-lg font-normal text-text-primary mb-2">
                Browse & Enroll
              </h3>
              <p className="text-sm text-text-secondary leading-relaxed font-light">
                Explore our course catalog, filter by category, and enroll in
                courses that match your learning goals.
              </p>
            </div>
          </div>

          {/* Step 2 */}
          <div className="relative group">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-text-primary text-white text-lg font-normal mb-4">
                2
              </div>
              <h3 className="text-lg font-normal text-text-primary mb-2">
                Take Entry Quiz
              </h3>
              <p className="text-sm text-text-secondary leading-relaxed font-light">
                Complete a quick assessment to determine your starting level.
                Score 70%+ for Advanced, or start with Basic fundamentals.
              </p>
            </div>
          </div>

          {/* Step 3 */}
          <div className="relative group">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-text-primary text-white text-lg font-normal mb-4">
                3
              </div>
              <h3 className="text-lg font-normal text-text-primary mb-2">
                Learn & Practice
              </h3>
              <p className="text-sm text-text-secondary leading-relaxed font-light">
                Access personalized content matching your track. Get AI tutor
                support and track your progress through each module.
              </p>
            </div>
          </div>

          {/* Step 4 */}
          <div className="relative group">
            <div className="flex flex-col items-center text-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-full bg-text-primary text-white text-lg font-normal mb-4">
                4
              </div>
              <h3 className="text-lg font-normal text-text-primary mb-2">
                Earn Certificate
              </h3>
              <p className="text-sm text-text-secondary leading-relaxed font-light">
                Complete the final assessment to test your knowledge and earn
                your verified completion certificate.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="mx-auto max-w-7xl px-6 py-24 bg-white">
        <div className="grid gap-16 lg:grid-cols-2">
          {/* For Students */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                <Users className="h-5 w-5 text-text-primary" />
              </div>
              <h2 className="text-2xl font-light text-text-primary">
                For Students
              </h2>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Personalized Learning Experience
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Content adapts to your skill level ensuring optimal learning
                    pace and comprehension.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    24/7 AI Tutor Support
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Get instant answers and explanations whenever you need help
                    with course material.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Clear Progress Visibility
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Track completion rates, view achievements, and stay
                    motivated with visual progress indicators.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Recognized Certificates
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Earn credentials to showcase your skills and boost your
                    professional portfolio.
                  </p>
                </div>
              </li>
            </ul>
          </div>

          {/* For Educators */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
                <BarChart3 className="h-5 w-5 text-text-primary" />
              </div>
              <h2 className="text-2xl font-light text-text-primary">
                For Educators
              </h2>
            </div>
            <ul className="space-y-4">
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Easy Course Creation
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Build engaging courses with rich text editor, drag-and-drop
                    module organization, and flexible content types.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Automated Grading
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Save time with instant auto-grading for multiple choice
                    questions and coding assessments.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Student Analytics
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Monitor student progress, identify struggling learners, and
                    track course completion rates.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-text-primary shrink-0 mt-0.5" />
                <div>
                  <p className="font-normal text-text-primary">
                    Flexible Assessment Tools
                  </p>
                  <p className="text-sm text-text-secondary mt-1 font-light">
                    Create diverse quizzes with MCQs, text responses, code
                    challenges, and file submissions.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section
        className="mx-auto max-w-7xl px-6 py-24"
        style={{
          background:
            "repeating-linear-gradient(-45deg, rgb(203, 226, 219), rgb(203, 226, 219) 1px, rgba(0, 0, 0, 0) 0px, rgba(0, 0, 0, 0) 8px)",
        }}
      >
        <div className="text-center mb-16">
          <h2 className="text-3xl font-light tracking-tight text-text-primary sm:text-4xl">
            Loved by Learners Worldwide
          </h2>
          <p className="mt-4 text-lg text-text-secondary max-w-2xl mx-auto font-light">
            See what our students have to say about their learning experience.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {/* Testimonial 1 */}
          <div className="rounded-lg border border-zinc-200 bg-white p-8">
            <div className="flex items-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <svg
                  key={i}
                  className="h-5 w-5 text-text-primary"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <p className="text-sm text-text-secondary leading-relaxed mb-6 font-light">
              &ldquo;The adaptive learning paths are game-changing! I started in
              the basic track and the content was perfectly paced for my level.
              The AI tutor helped me whenever I got stuck.&rdquo;
            </p>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                <span className="text-sm font-medium text-text-primary">
                  SM
                </span>
              </div>
              <div>
                <div className="text-sm font-medium text-text-primary">
                  Sarah Mitchell
                </div>
                <div className="text-xs text-text-secondary">
                  Web Development Student
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 2 */}
          <div className="rounded-lg border border-zinc-200 bg-white p-8">
            <div className="flex items-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <svg
                  key={i}
                  className="h-5 w-5 text-text-primary"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <p className="text-sm text-text-secondary leading-relaxed mb-6 font-light">
              &ldquo;I love how the platform tracks my progress and shows me
              exactly what I need to complete. The certificates look
              professional and I&rsquo;ve already added them to my
              LinkedIn.&rdquo;
            </p>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                <span className="text-sm font-medium text-text-primary">
                  JC
                </span>
              </div>
              <div>
                <div className="text-sm font-medium text-text-primary">
                  James Chen
                </div>
                <div className="text-xs text-text-secondary">
                  Data Science Learner
                </div>
              </div>
            </div>
          </div>

          {/* Testimonial 3 */}
          <div className="rounded-lg border border-zinc-200 bg-white p-8">
            <div className="flex items-center gap-1 mb-4">
              {[...Array(5)].map((_, i) => (
                <svg
                  key={i}
                  className="h-5 w-5 text-text-primary"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <p className="text-sm text-text-secondary leading-relaxed mb-6 font-light">
              &ldquo;As an educator, I appreciate the automated grading and
              analytics features. Creating courses is intuitive and my students
              love the interactive assessments.&rdquo;
            </p>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                <span className="text-sm font-medium text-text-primary">
                  EP
                </span>
              </div>
              <div>
                <div className="text-sm font-medium text-text-primary">
                  Emily Rodriguez
                </div>
                <div className="text-xs text-text-secondary">
                  Course Instructor
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section
        className="relative border-t border-border overflow-hidden"
        style={{
          background: "#1A2720",
        }}
      >
        <div className="relative mx-auto max-w-7xl px-6 py-20 text-center">
          <h2 className="text-4xl font-light tracking-tight text-white">
            Ready to Transform Your Learning?
          </h2>
          <p className="mt-4 text-lg text-white/80 max-w-2xl mx-auto font-light">
            Join our community of learners and start your personalized
            educational journey today. No credit card required.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/courses"
              className="group inline-flex items-center gap-2 rounded-lg bg-accent px-8 py-4 text-base font-medium text-text-primary hover:bg-accent-hover transition-all duration-200 w-full sm:w-auto justify-center"
            >
              Explore Courses
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
            <Link
              href="/sign-up"
              className="rounded-lg border-2 border-white bg-transparent px-8 py-4 text-base font-medium text-white hover:bg-white hover:text-text-primary transition-all duration-200 w-full sm:w-auto text-center"
            >
              Sign Up Free
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-white">
        <div className="mx-auto max-w-7xl px-6 py-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-sm text-text-secondary font-light">
              © 2026 Edumentis. All rights reserved.
            </div>
            <div className="flex items-center gap-6">
              <Link
                href="/courses"
                className="text-sm text-text-secondary hover:text-text-primary transition-colors font-light"
              >
                Courses
              </Link>
              <Link
                href="/sign-in"
                className="text-sm text-text-secondary hover:text-text-primary transition-colors font-light"
              >
                Sign In
              </Link>
              <Link
                href="/sign-up"
                className="text-sm text-text-secondary hover:text-text-primary transition-colors font-light"
              >
                Get Started
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
