import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
} from "@react-pdf/renderer";

// ── Palette: Zinc + Indigo + Mint ──────────────────────────
const MINT = "#7FFFC3";
const MINT_DARK = "#4DDBA0";
const MINT_PALE = "#E6FFF5";
const INDIGO = "#4F46E5";
const INDIGO_DARK = "#3730A3";
const INDIGO_LIGHT = "#818CF8";
const ZINC_900 = "#18181B";
const ZINC_700 = "#3F3F46";
const ZINC_500 = "#71717A";
const ZINC_300 = "#D4D4D8";
const ZINC_100 = "#F4F4F5";
const WHITE = "#FFFFFF";

const styles = StyleSheet.create({
  page: {
    flexDirection: "column",
    backgroundColor: WHITE,
    padding: 0,
    fontFamily: "Helvetica",
  },

  // ── Root wrapper fills the page ─────────────────────────
  root: {
    flex: 1,
    margin: 22,
    flexDirection: "column",
    border: `2pt solid ${ZINC_300}`,
  },

  // ── Top indigo header ───────────────────────────────────
  header: {
    backgroundColor: INDIGO_DARK,
    paddingVertical: 18,
    paddingHorizontal: 40,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  headerLeft: {
    flexDirection: "column",
  },
  brandName: {
    fontSize: 26,
    fontWeight: "bold",
    color: MINT,
    letterSpacing: 3,
    textTransform: "uppercase",
  },
  brandSub: {
    fontSize: 7,
    color: INDIGO_LIGHT,
    letterSpacing: 2.5,
    textTransform: "uppercase",
    marginTop: 3,
  },
  headerRight: {
    flexDirection: "column",
    alignItems: "flex-end",
  },
  headerLabel: {
    fontSize: 7.5,
    color: INDIGO_LIGHT,
    letterSpacing: 2,
    textTransform: "uppercase",
  },
  headerTitle: {
    fontSize: 15,
    fontWeight: "bold",
    color: WHITE,
    letterSpacing: 1.5,
    textTransform: "uppercase",
    marginTop: 3,
  },

  // Mint accent bar below header
  mintBar: {
    height: 4,
    backgroundColor: MINT,
  },

  // ── Body ────────────────────────────────────────────────
  body: {
    flex: 1,
    flexDirection: "row",
  },

  // Left mint accent stripe
  leftStripe: {
    width: 6,
    backgroundColor: MINT_PALE,
    borderRight: `1pt solid ${MINT_DARK}`,
  },

  // Main content
  content: {
    flex: 1,
    flexDirection: "column",
    alignItems: "center",
    paddingHorizontal: 50,
    paddingTop: 22,
    paddingBottom: 18,
  },

  // Ornament row
  ornamentRow: {
    flexDirection: "row",
    alignItems: "center",
    width: "70%",
    marginBottom: 16,
  },
  ornamentLine: {
    flex: 1,
    height: 0.75,
    backgroundColor: ZINC_300,
  },
  ornamentDiamond: {
    width: 5,
    height: 5,
    backgroundColor: MINT_DARK,
    marginHorizontal: 6,
    transform: "rotate(45deg)",
  },

  // Presented to block
  presentedTo: {
    fontSize: 9,
    color: ZINC_500,
    letterSpacing: 2.5,
    textTransform: "uppercase",
    marginBottom: 6,
  },

  // Student name
  studentName: {
    fontSize: 34,
    fontWeight: "bold",
    color: ZINC_900,
    letterSpacing: 0.5,
    marginBottom: 4,
    textAlign: "center",
  },

  // Name underline (mint)
  nameUnderline: {
    width: 200,
    height: 2.5,
    backgroundColor: MINT,
    marginBottom: 14,
  },

  bodyText: {
    fontSize: 10,
    color: ZINC_500,
    letterSpacing: 0.5,
    marginBottom: 6,
    textAlign: "center",
    fontStyle: "italic",
  },

  coursePill: {
    backgroundColor: MINT_PALE,
    border: `1pt solid ${MINT_DARK}`,
    borderRadius: 4,
    paddingVertical: 6,
    paddingHorizontal: 20,
    marginBottom: 12,
    alignItems: "center",
  },
  courseName: {
    fontSize: 18,
    fontWeight: "bold",
    color: INDIGO_DARK,
    letterSpacing: 0.5,
    textAlign: "center",
  },

  achievementText: {
    fontSize: 9,
    color: ZINC_500,
    textAlign: "center",
    maxWidth: 380,
    lineHeight: 1.6,
    marginBottom: 14,
  },

  // ── Seal ────────────────────────────────────────────────
  sealOuter: {
    width: 62,
    height: 62,
    borderRadius: 31,
    border: `2pt solid ${MINT_DARK}`,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 4,
  },
  sealInner: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: INDIGO_DARK,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
  },
  sealStar: {
    fontSize: 11,
    color: MINT,
  },
  sealText: {
    fontSize: 5.5,
    fontWeight: "bold",
    color: WHITE,
    letterSpacing: 1.5,
    textTransform: "uppercase",
    marginTop: 1,
  },

  // Right accent stripe
  rightStripe: {
    width: 6,
    backgroundColor: MINT_PALE,
    borderLeft: `1pt solid ${MINT_DARK}`,
  },

  // ── Footer band ─────────────────────────────────────────
  footer: {
    backgroundColor: ZINC_100,
    borderTop: `1pt solid ${ZINC_300}`,
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 40,
  },
  footerItem: {
    flex: 1,
    alignItems: "center",
  },
  footerLabel: {
    fontSize: 7,
    color: ZINC_500,
    letterSpacing: 2,
    textTransform: "uppercase",
    marginBottom: 3,
  },
  footerValue: {
    fontSize: 10,
    fontWeight: "bold",
    color: ZINC_700,
    letterSpacing: 0.3,
  },
  footerDivider: {
    width: 1,
    height: 28,
    backgroundColor: ZINC_300,
  },
  signatureLine: {
    width: 90,
    height: 0.75,
    backgroundColor: ZINC_500,
    marginBottom: 5,
    opacity: 0.5,
  },

  // Bottom strips
  bottomStrip: {
    height: 5,
    backgroundColor: INDIGO,
  },
  mintBottomStrip: {
    height: 3,
    backgroundColor: MINT,
  },
});

interface CertificatePDFProps {
  studentName: string;
  courseName: string;
  completionDate: string;
  certificateId: string;
  instructorName?: string;
}

export function CertificatePDF({
  studentName,
  courseName,
  completionDate,
  certificateId,
  instructorName = "Course Instructor",
}: CertificatePDFProps) {
  return (
    <Document>
      <Page size="A4" orientation="landscape" style={styles.page}>
        <View style={styles.root}>

          {/* ── Indigo Header ── */}
          <View style={styles.header}>
            <View style={styles.headerLeft}>
              <Text style={styles.brandName}>Edumentis</Text>
              <Text style={styles.brandSub}>Academy of Excellence &amp; Learning</Text>
            </View>
            <View style={styles.headerRight}>
              <Text style={styles.headerLabel}>Official Document</Text>
              <Text style={styles.headerTitle}>Certificate of Completion</Text>
            </View>
          </View>

          {/* Mint accent bar */}
          <View style={styles.mintBar} />

          {/* ── Body row ── */}
          <View style={styles.body}>
            {/* Left stripe */}
            <View style={styles.leftStripe} />

            {/* Main content */}
            <View style={styles.content}>

              {/* Top ornament */}
              <View style={styles.ornamentRow}>
                <View style={styles.ornamentLine} />
                <View style={styles.ornamentDiamond} />
                <View style={styles.ornamentLine} />
              </View>

              <Text style={styles.presentedTo}>Proudly presented to</Text>

              <Text style={styles.studentName}>{studentName}</Text>
              <View style={styles.nameUnderline} />

              <Text style={styles.bodyText}>
                has successfully completed the course
              </Text>

              {/* Course pill */}
              <View style={styles.coursePill}>
                <Text style={styles.courseName}>{courseName}</Text>
              </View>

              <Text style={styles.achievementText}>
                demonstrating exceptional dedication, commitment, and mastery
                of the subject matter throughout the duration of the program.
              </Text>

              {/* Bottom ornament */}
              <View style={styles.ornamentRow}>
                <View style={styles.ornamentLine} />
                <View style={styles.ornamentDiamond} />
                <View style={styles.ornamentLine} />
              </View>

              {/* Seal */}
              <View style={styles.sealOuter}>
                <View style={styles.sealInner}>
                  <Text style={styles.sealStar}>★</Text>
                  <Text style={styles.sealText}>CERTIFIED</Text>
                </View>
              </View>

            </View>

            {/* Right stripe */}
            <View style={styles.rightStripe} />
          </View>

          {/* ── Footer ── */}
          <View style={styles.footer}>
            {/* Date */}
            <View style={styles.footerItem}>
              <Text style={styles.footerLabel}>Completion Date</Text>
              <Text style={styles.footerValue}>{completionDate}</Text>
            </View>

            <View style={styles.footerDivider} />

            {/* Instructor */}
            <View style={styles.footerItem}>
              <View style={styles.signatureLine} />
              <Text style={styles.footerLabel}>Instructor</Text>
              <Text style={styles.footerValue}>{instructorName}</Text>
            </View>

            <View style={styles.footerDivider} />

            {/* Certificate ID */}
            <View style={styles.footerItem}>
              <Text style={styles.footerLabel}>Certificate ID</Text>
              <Text style={styles.footerValue}>{certificateId}</Text>
            </View>
          </View>

          {/* Bottom strips */}
          <View style={styles.bottomStrip} />
          <View style={styles.mintBottomStrip} />

        </View>
      </Page>
    </Document>
  );
}