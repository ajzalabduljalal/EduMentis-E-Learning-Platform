import {
  Code,
  Palette,
  Briefcase,
  Database,
  Brain,
  Network,
  BookOpen,
} from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface CategoryConfig {
  icon: LucideIcon;
  color: string;
  bgColor: string;
}

// Default category icon mapping
export const categoryIconMap = {
  programming: {
    icon: Code,
    color: "text-blue-600",
    bgColor: "bg-blue-100",
  },
  design: {
    icon: Palette,
    color: "text-pink-600",
    bgColor: "bg-pink-100",
  },
  business: {
    icon: Briefcase,
    color: "text-orange-600",
    bgColor: "bg-orange-100",
  },
  data: {
    icon: Database,
    color: "text-purple-600",
    bgColor: "bg-purple-100",
  },
  ai: {
    icon: Brain,
    color: "text-green-600",
    bgColor: "bg-green-100",
  },
  networking: {
    icon: Network,
    color: "text-cyan-600",
    bgColor: "bg-cyan-100",
  },
} as const satisfies Record<string, CategoryConfig>;

const fallbackConfig: CategoryConfig = {
  icon: BookOpen,
  color: "text-slate-600",
  bgColor: "bg-slate-100",
};

// Helper function to get category config
export function getCategoryConfig(categoryName: string | null): CategoryConfig {
  if (!categoryName) {
    return fallbackConfig;
  }

  const normalized = categoryName.toLowerCase().replace(/\s+/g, "");

  // Check if it's a known category key
  type CategoryKey = keyof typeof categoryIconMap;
  const knownKeys = Object.keys(categoryIconMap) as CategoryKey[];

  // Direct match
  if (knownKeys.includes(normalized as CategoryKey)) {
    return categoryIconMap[normalized as CategoryKey];
  }

  // Partial matches
  if (normalized.includes("program") || normalized.includes("code")) {
    return categoryIconMap.programming;
  }
  if (normalized.includes("design") || normalized.includes("ui")) {
    return categoryIconMap.design;
  }
  if (normalized.includes("business") || normalized.includes("market")) {
    return categoryIconMap.business;
  }
  if (normalized.includes("data") || normalized.includes("analytics")) {
    return categoryIconMap.data;
  }
  if (
    normalized.includes("ai") ||
    normalized.includes("ml") ||
    normalized.includes("machine")
  ) {
    return categoryIconMap.ai;
  }
  if (normalized.includes("network") || normalized.includes("cloud")) {
    return categoryIconMap.networking;
  }

  // Fallback
  return fallbackConfig;
}
