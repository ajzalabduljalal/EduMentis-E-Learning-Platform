import { prisma, AssessmentStatus } from "@repo/db";
import { renderToBuffer } from "@react-pdf/renderer";
import { CertificatePDF } from "./certificate";

interface GenerateCertificateResult {
  certificateUrl: string;
  certificateId: string;
}

/**
 * Core certificate generation logic.
 * Generates a PDF certificate and stores it in UserCourseProgress.
 * Called directly from the assessment submit handler (same server)
 * and from the /api/certificates/generate route (for external callers like admin).
 */
export async function generateCertificate(
  userId: string,
  courseId: string,
  attemptId: string,
): Promise<GenerateCertificateResult> {
  // Get user
  const user = await prisma.user.findUnique({
    where: { id: userId },
  });

  if (!user) {
    throw new Error("User not found");
  }

  // Get course with instructor
  const course = await prisma.course.findUnique({
    where: { id: courseId },
    include: {
      instructor: true,
    },
  });

  if (!course) {
    throw new Error("Course not found");
  }

  // Get assessment attempt and verify it passed
  const attempt = await prisma.assessmentAttempt.findUnique({
    where: { id: attemptId },
  });

  if (!attempt || attempt.status !== AssessmentStatus.PASSED) {
    throw new Error("Assessment not passed");
  }

  // Check if certificate already exists
  const progress = await prisma.userCourseProgress.findUnique({
    where: {
      userId_courseId: {
        userId: user.id,
        courseId: course.id,
      },
    },
  });

  if (progress?.certificateUrl) {
    // Extract existing certificate ID
    const existingMatch = progress.certificateUrl.match(
      /CERT-\d+-[A-Z0-9]+/,
    );
    return {
      certificateUrl: progress.certificateUrl,
      certificateId: existingMatch?.[0] || "N/A",
    };
  }

  // Generate certificate ID
  const certificateId = `CERT-${Date.now()}-${userId.substring(0, 8).toUpperCase()}`;

  // Generate PDF
  const pdfComponent = CertificatePDF({
    studentName: user.name || user.email,
    courseName: course.title,
    completionDate: new Date().toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
    }),
    certificateId,
    instructorName: course.instructor.name || "Course Instructor",
  });

  const pdfBuffer = await renderToBuffer(pdfComponent);

  // Store as base64 data URL (in production, upload to R2/S3)
  const base64Pdf = pdfBuffer.toString("base64");
  const certificateUrl = `data:application/pdf;base64,${base64Pdf}`;

  // Update progress with certificate URL and mark course as completed
  await prisma.userCourseProgress.update({
    where: {
      userId_courseId: {
        userId: user.id,
        courseId: course.id,
      },
    },
    data: {
      isCompleted: true,
      completedAt: new Date(),
      certificateUrl,
    },
  });

  return { certificateUrl, certificateId };
}
