import { notFound } from "next/navigation";
import { prisma, CourseStatus } from "@repo/db";
import { auth } from "@clerk/nextjs/server";
import {
  Clock,
  BookOpen,
  Users,
  Award,
  CheckCircle,
  Layers,
} from "lucide-react";
import { EnrollButton } from "./components/EnrollButton";
import { CurriculumAccordion } from "./components/CurriculumAccordion";
import { getCategoryConfig } from "../../lib/category-config";

const levelLabels: Record<string, string> = {
  BEGINNER: "Beginner",
  INTERMEDIATE: "Intermediate",
  ADVANCED: "Advanced",
};

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default async function CourseDetailPage({ params }: PageProps) {
  const { slug } = await params;
  const { userId } = await auth();

  // Fetch course with all details
  const course = await prisma.course.findFirst({
    where: {
      slug,
      status: CourseStatus.PUBLISHED,
    },
    include: {
      instructor: {
        select: {
          id: true,
          name: true,
          email: true,
        },
      },
      modules: {
        orderBy: { orderIndex: "asc" },
        include: {
          lessons: {
            orderBy: { orderIndex: "asc" },
            select: {
              id: true,
              title: true,
              duration: true,
              track: true,
              isFree: true,
              lessonType: true,
            },
          },
        },
      },
      entryQuiz: {
        select: {
          id: true,
          title: true,
          description: true,
          passingScore: true,
          timeLimit: true,
          _count: {
            select: { questions: true },
          },
        },
      },
      _count: {
        select: {
          modules: true,
          userProgress: true,
        },
      },
    },
  });

  if (!course) {
    notFound();
  }

  // Check enrollment status
  let enrollment = null;
  if (userId) {
    const user = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (user) {
      enrollment = await prisma.userCourseProgress.findUnique({
        where: {
          userId_courseId: {
            userId: user.id,
            courseId: course.id,
          },
        },
      });
    }
  }

  const levelLabel = levelLabels[course.level] ?? "Beginner";

  // Calculate total lessons and duration
  const totalLessons = course.modules.reduce(
    (sum: number, m: { lessons: { id: string }[] }) => sum + m.lessons.length,
    0,
  );
  const totalMinutes = course.modules.reduce(
    (sum: number, m: { lessons: { duration: number | null }[] }) =>
      sum +
      m.lessons.reduce(
        (lSum: number, l: { duration: number | null }) =>
          lSum + (l.duration || 0),
        0,
      ),
    0,
  );
  const totalHours = Math.ceil(totalMinutes / 60);

  // Get category config for icon
  const categoryConfig = getCategoryConfig(course.category);
  const CategoryIcon = categoryConfig.icon;

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header Section */}
      <section className="border-b border-border">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Left content */}
            <div className="lg:col-span-3 space-y-6">
              {/* Category Icon + Breadcrumb */}
              <div className="flex items-center gap-4">
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-full ${categoryConfig.bgColor} shrink-0`}
                >
                  <CategoryIcon className={`h-6 w-6 ${categoryConfig.color}`} />
                </div>
                <div className="flex items-center gap-2 text-sm text-text-secondary">
                  {course.category && (
                    <>
                      <span className="font-medium">{course.category}</span>
                      <span>/</span>
                    </>
                  )}
                  <span className="bg-bg-tertiary px-2 py-0.5 rounded text-xs font-medium">
                    {levelLabel}
                  </span>
                </div>
              </div>

              {/* Title */}
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-text-primary">
                {course.title}
              </h1>

              {/* Short description */}
              {course.shortDescription && (
                <p className="text-base text-text-secondary leading-relaxed">
                  {course.shortDescription}
                </p>
              )}

              {/* Meta info */}
              <div className="flex flex-wrap items-center gap-6 text-sm text-text-secondary pt-2">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  <span>{totalHours} hours</span>
                </div>
                <div className="flex items-center gap-2">
                  <Layers className="h-5 w-5" />
                  <span>{course._count.modules} modules</span>
                </div>
                <div className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  <span>{totalLessons} lessons</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  <span>{course._count.userProgress} enrolled</span>
                </div>
              </div>

              {/* Instructor */}
              {course.instructor && (
                <div className="pt-2">
                  <p className="text-sm text-text-secondary">
                    Instructor:{" "}
                    <span className="text-text-primary font-semibold">
                      {course.instructor.name || "Instructor"}
                    </span>
                  </p>
                </div>
              )}
            </div>

            {/* Right sidebar - Enrollment card */}
            <div className="lg:col-span-2">
              <div className="border border-border rounded-lg p-6 bg-bg-primary shadow-sm sticky top-24">
                {/* Price */}
                <div className="mb-6">
                  {course.price === 0 ? (
                    <div className="text-3xl font-semibold text-text-primary">
                      Free
                    </div>
                  ) : (
                    <div className="text-3xl font-semibold text-text-primary">
                      ${course.price}
                    </div>
                  )}
                </div>

                {/* Enroll button */}
                <EnrollButton
                  courseId={course.id}
                  courseSlug={course.slug}
                  hasEntryQuiz={!!course.entryQuiz}
                  entryQuizId={course.entryQuiz?.id}
                  isEnrolled={!!enrollment}
                  progress={enrollment?.progressPercent || 0}
                  price={course.price}
                />

                {/* Features */}
                <div className="mt-6 pt-6 border-t border-border space-y-3 text-sm text-text-secondary">
                  <div className="flex items-center gap-3">
                    <Award className="h-4 w-4" />
                    <span>Certificate of completion</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Clock className="h-4 w-4" />
                    <span>Lifetime access</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Content Section */}
      <section className="py-12 sm:py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-5 gap-12">
            {/* Main content */}
            <div className="lg:col-span-3 space-y-12">
              {/* What you'll learn */}
              <div>
                <h2 className="text-xl font-semibold tracking-tight text-text-primary mb-4">
                  What you&apos;ll learn
                </h2>
                <div className="grid gap-3">
                  {[
                    "Master core concepts and fundamentals",
                    "Build real-world projects from scratch",
                    "Learn best practices and industry standards",
                    "Earn a certificate upon completion",
                  ].map((point, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-text-secondary mt-0.5 shrink-0" />
                      <span className="text-base text-text-secondary">
                        {point}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Entry Quiz Info */}
              {course.entryQuiz && !enrollment && (
                <div className="border border-border rounded-lg p-6 bg-bg-secondary/50">
                  <h3 className="text-lg font-semibold tracking-tight text-text-primary mb-2">
                    Personalized Learning Path
                  </h3>
                  <p className="text-text-secondary text-sm leading-relaxed mb-4">
                    This course includes an entry assessment to place you in the
                    right learning track. Complete a{" "}
                    {course.entryQuiz._count.questions}-question quiz to get a
                    personalized curriculum.
                  </p>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-text-secondary">
                    <div className="flex items-center gap-2">
                      <BookOpen className="h-4 w-4" />
                      <span>{course.entryQuiz._count.questions} questions</span>
                    </div>
                    {course.entryQuiz.timeLimit && (
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        <span>{course.entryQuiz.timeLimit} min</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Award className="h-4 w-4" />
                      <span>
                        {course.entryQuiz.passingScore}% for advanced track
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Curriculum */}
              <div>
                <h2 className="text-xl font-semibold tracking-tight text-text-primary mb-4">
                  Curriculum
                </h2>
                <CurriculumAccordion
                  modules={course.modules}
                  isEnrolled={!!enrollment}
                  enrolledTrack={
                    enrollment?.enrolledTrack === "BOTH"
                      ? "ADVANCED"
                      : enrollment?.enrolledTrack
                  }
                />
              </div>

              {/* Full Description */}
              {course.description && (
                <div>
                  <h2 className="text-xl font-semibold tracking-tight text-text-primary mb-4">
                    About this course
                  </h2>
                  <div className="prose prose-zinc prose-base max-w-none">
                    <p className="text-base text-text-secondary whitespace-pre-wrap leading-relaxed">
                      {course.description}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Sidebar spacer */}
            <div className="hidden lg:block lg:col-span-2" />
          </div>
        </div>
      </section>
    </div>
  );
}
