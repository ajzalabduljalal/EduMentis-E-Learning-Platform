"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import {
  ArrowLeft,
  Check,
  ChevronLeft,
  ChevronRight,
  FileText,
  Download,
  Brain,
  MessageCircle,
} from "lucide-react";
import { Progress } from "@repo/ui/components/progress";
import { LessonQuizModal } from "./components/LessonQuizModal";
import { AITutorChat } from "./components/AITutorChat";

interface Attachment {
  id: string;
  name: string;
  url: string;
  fileType: string;
}

interface Lesson {
  id: string;
  title: string;
  description: string | null;
  content: string;
  lessonType: "TEXT" | "VIDEO" | "INTERACTIVE" | "CODING";
  track: "BASIC" | "ADVANCED" | "BOTH";
  duration: number | null;
  isFree: boolean;
  attachments: Attachment[];
}

interface NavigationLesson {
  id: string;
  title: string;
}

interface Navigation {
  prevLesson: NavigationLesson | null;
  nextLesson: NavigationLesson | null;
}

interface ModuleLesson {
  id: string;
  title: string;
  track: "BASIC" | "ADVANCED" | "BOTH";
  isCompleted: boolean;
}

interface Module {
  id: string;
  title: string;
  track: "BASIC" | "ADVANCED" | "BOTH";
  lessons: ModuleLesson[];
}

interface LessonViewClientProps {
  lesson: Lesson;
  moduleTitle: string;
  course: {
    id: string;
    slug: string;
    title: string;
  };
  enrollment: {
    enrolledTrack: "BASIC" | "ADVANCED";
    progressPercent: number;
  };
  modules: Module[];
  currentLessonProgress: boolean;
  hasQuiz: boolean;
  navigation: Navigation;
}

export function LessonViewClient({
  lesson,
  moduleTitle,
  course,
  modules,
  currentLessonProgress,
  hasQuiz,
  navigation,
}: LessonViewClientProps) {
  const [isCompleted, setIsCompleted] = useState(currentLessonProgress);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showQuizModal, setShowQuizModal] = useState(false);
  const [quizData, setQuizData] = useState<{
    quiz: any;
    attempts: any[];
  } | null>(null);
  const [loadingQuiz, setLoadingQuiz] = useState(false);
  const [showAITutor, setShowAITutor] = useState(false);

  // Update local state when prop changes
  useEffect(() => {
    setIsCompleted(currentLessonProgress);
  }, [currentLessonProgress]);

  const handleMarkComplete = useCallback(async () => {
    if (isUpdating) return;

    setIsUpdating(true);
    try {
      const response = await fetch(`/api/lessons/${lesson.id}/progress`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isCompleted: !isCompleted }),
      });

      const data = await response.json();

      if (data.success) {
        setIsCompleted(!isCompleted);
      } else {
        console.error("Failed to update progress:", data.error);
      }
    } catch (error) {
      console.error("Error updating progress:", error);
    } finally {
      setIsUpdating(false);
    }
  }, [lesson.id, isCompleted, isUpdating]);

  const handleTakeQuiz = async () => {
    setLoadingQuiz(true);
    try {
      const response = await fetch(`/api/lessons/${lesson.id}/quiz`);
      const data = await response.json();

      if (data.success && data.data) {
        setQuizData(data.data);
        setShowQuizModal(true);
      } else {
        console.error("Failed to load quiz");
      }
    } catch (error) {
      console.error("Error loading quiz:", error);
    } finally {
      setLoadingQuiz(false);
    }
  };

  // Calculate overall progress
  const totalLessons = modules.reduce((acc, m) => acc + m.lessons.length, 0);
  const completedLessons = modules.reduce(
    (acc, m) => acc + m.lessons.filter((l) => l.isCompleted).length,
    0,
  );
  const overallProgress =
    totalLessons > 0 ? (completedLessons / totalLessons) * 100 : 0;

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Header */}
      <div className="border-b border-border bg-bg-primary sticky top-0 z-10">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link
              href={`/courses/${course.slug}/learn`}
              className="inline-flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Course
            </Link>

            <div className="flex items-center gap-4">
              <div className="text-sm text-text-secondary">
                <span className="font-medium text-text-primary">
                  {completedLessons}
                </span>{" "}
                / {totalLessons} completed
              </div>
              <Progress value={overallProgress} className="w-24 h-2" />
            </div>
          </div>
        </div>
      </div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-8">
          {/* Main Content */}
          <div className="min-w-0">
            {/* Lesson Header */}
            <div className="mb-8">
              <div className="text-sm font-medium text-text-secondary mb-2">
                {moduleTitle}
              </div>
              <h1 className="text-3xl font-semibold text-text-primary mb-4">
                {lesson.title}
              </h1>
              {lesson.description && (
                <p className="text-text-secondary leading-relaxed">
                  {lesson.description}
                </p>
              )}
            </div>

            {/* Lesson Content - Enhanced styling */}
            <div className="mb-8 bg-white rounded-lg border border-border p-8 min-h-[400px]">
              {lesson.lessonType === "TEXT" ||
              lesson.lessonType === "INTERACTIVE" ? (
                <div
                  className="prose prose-zinc prose-lg max-w-none text-text-primary [&>h1]:text-2xl [&>h1]:font-semibold [&>h1]:mb-4 [&>h2]:text-xl [&>h2]:font-semibold [&>h2]:mb-3 [&>h3]:text-lg [&>h3]:font-semibold [&>h3]:mb-2 [&>p]:mb-4 [&>p]:leading-relaxed [&>ul]:mb-4 [&>ol]:mb-4 [&>pre]:bg-zinc-900 [&>pre]:text-zinc-100 [&>pre]:p-4 [&>pre]:rounded-lg [&>pre]:overflow-x-auto [&>code]:text-sm [&>code]:bg-zinc-100 [&>code]:px-1.5 [&>code]:py-0.5 [&>code]:rounded [&>blockquote]:border-l-4 [&>blockquote]:border-zinc-300 [&>blockquote]:pl-4 [&>blockquote]:italic"
                  dangerouslySetInnerHTML={{ __html: lesson.content }}
                />
              ) : lesson.lessonType === "VIDEO" ? (
                <div className="bg-black rounded-lg aspect-video flex items-center justify-center">
                  <p className="text-white">Video: {lesson.title}</p>
                </div>
              ) : lesson.lessonType === "CODING" ? (
                <div className="bg-slate-900 rounded-lg p-6 font-mono text-sm">
                  <pre className="text-slate-100 whitespace-pre-wrap leading-relaxed">
                    {lesson.content}
                  </pre>
                </div>
              ) : null}
            </div>

            {/* Attachments */}
            {lesson.attachments.length > 0 && (
              <div className="mb-8">
                <h3 className="text-lg font-semibold text-text-primary mb-4">
                  Attachments
                </h3>
                <div className="space-y-2">
                  {lesson.attachments.map((attachment) => (
                    <a
                      key={attachment.id}
                      href={attachment.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 p-3 border border-border rounded-lg hover:bg-bg-secondary transition-colors"
                    >
                      <FileText className="h-5 w-5 text-text-secondary" />
                      <span className="text-sm font-medium text-text-primary">
                        {attachment.name}
                      </span>
                      <Download className="h-4 w-4 text-text-secondary ml-auto" />
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Take Quiz Button - Only show if quiz exists */}
            {hasQuiz && (
              <div className="mb-8">
                <button
                  onClick={handleTakeQuiz}
                  disabled={loadingQuiz}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 disabled:opacity-50 transition-colors font-medium"
                >
                  <Brain className="h-5 w-5" />
                  {loadingQuiz ? "Loading Quiz..." : "Take Lesson Quiz"}
                </button>
                <p className="text-sm text-text-secondary mt-2">
                  Test your understanding of this lesson
                </p>
              </div>
            )}

            {/* Mark Complete Button */}
            <div className="flex items-center justify-between p-4 bg-bg-secondary rounded-lg mb-8">
              <div className="flex items-center gap-3">
                <button
                  onClick={handleMarkComplete}
                  disabled={isUpdating}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                    isCompleted
                      ? "bg-green-100 text-green-700"
                      : "bg-bg-tertiary text-text-primary hover:bg-primary hover:text-white"
                  }`}
                >
                  {isCompleted ? (
                    <>
                      <Check className="h-5 w-5" />
                      Completed
                    </>
                  ) : (
                    "Mark as Complete"
                  )}
                </button>
              </div>

              {/* Navigation */}
              <div className="flex items-center gap-2">
                {navigation.prevLesson ? (
                  <Link
                    href={`/courses/${course.slug}/lessons/${navigation.prevLesson.id}`}
                    className="flex items-center gap-1 px-3 py-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
                  >
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </Link>
                ) : (
                  <span className="flex items-center gap-1 px-3 py-2 text-sm text-text-secondary opacity-50">
                    <ChevronLeft className="h-4 w-4" />
                    Previous
                  </span>
                )}

                {navigation.nextLesson ? (
                  <Link
                    href={`/courses/${course.slug}/lessons/${navigation.nextLesson.id}`}
                    className="flex items-center gap-1 px-3 py-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
                  >
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                ) : (
                  <span className="flex items-center gap-1 px-3 py-2 text-sm text-text-secondary opacity-50">
                    Next
                    <ChevronRight className="h-4 w-4" />
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar - Course Navigation */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <div className="bg-white rounded-lg border border-border p-6">
              <h3 className="text-sm font-semibold text-text-primary mb-4">
                Course Content
              </h3>
              <div className="space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto">
                {modules.map((module, moduleIndex) => (
                  <div
                    key={module.id}
                    className="border border-border rounded-lg overflow-hidden"
                  >
                    <div className="bg-bg-secondary px-3 py-2">
                      <h4 className="text-xs font-medium text-text-primary">
                        Module {moduleIndex + 1}: {module.title}
                      </h4>
                    </div>
                    <div className="divide-y divide-border">
                      {module.lessons.map((l) => (
                        <Link
                          key={l.id}
                          href={`/courses/${course.slug}/lessons/${l.id}`}
                          className={`flex items-center gap-2 px-3 py-2 text-xs transition-colors ${
                            l.id === lesson.id
                              ? "bg-primary/10 text-primary font-medium"
                              : "text-text-secondary hover:text-text-primary hover:bg-bg-secondary"
                          }`}
                        >
                          <div
                            className={`h-4 w-4 rounded-full flex items-center justify-center shrink-0 ${
                              l.isCompleted
                                ? "bg-green-100 text-green-600"
                                : "bg-bg-tertiary text-text-secondary"
                            }`}
                          >
                            {l.isCompleted ? (
                              <Check className="h-2.5 w-2.5" />
                            ) : (
                              <span className="text-[10px]">
                                {module.lessons.findIndex(
                                  (les) => les.id === l.id,
                                ) + 1}
                              </span>
                            )}
                          </div>
                          <span className="truncate">{l.title}</span>
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Quiz Modal */}
      {showQuizModal && quizData?.quiz && (
        <LessonQuizModal
          lessonId={lesson.id}
          quiz={quizData.quiz}
          attempts={quizData.attempts || []}
          onClose={() => {
            setShowQuizModal(false);
            setQuizData(null);
          }}
        />
      )}

      {/* AI Tutor Chat */}
      <AITutorChat
        lessonId={lesson.id}
        courseId={course.id}
        lessonTitle={lesson.title}
        isOpen={showAITutor}
        onClose={() => setShowAITutor(false)}
      />

      {/* Floating AI Tutor Button */}
      <button
        onClick={() => setShowAITutor(true)}
        className="fixed bottom-6 right-6 h-14 w-14 rounded-full bg-white border-2 border-zinc-200 text-zinc-700 shadow-lg hover:shadow-xl hover:border-zinc-300 hover:bg-zinc-50 transition-all duration-200 flex items-center justify-center z-30"
        aria-label="Open AI Tutor"
      >
        <MessageCircle className="h-6 w-6" />
      </button>
    </div>
  );
}
