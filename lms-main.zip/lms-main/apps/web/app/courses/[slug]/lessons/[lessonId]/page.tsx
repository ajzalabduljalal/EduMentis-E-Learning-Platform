import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import { notFound, redirect } from "next/navigation";
import { LessonViewClient } from "./LessonViewClient";

interface NavigationLesson {
  id: string;
  title: string;
}

interface PageProps {
  params: Promise<{ slug: string; lessonId: string }>;
}

export default async function LessonPage({ params }: PageProps) {
  const { userId: clerkId } = await auth();
  const { slug, lessonId } = await params;

  if (!clerkId) {
    redirect("/sign-in");
  }

  // Find the internal user
  const dbUser = await prisma.user.findUnique({
    where: { clerkId },
  });

  if (!dbUser) {
    redirect("/sign-in");
  }

  // Get course
  const course = await prisma.course.findUnique({
    where: { slug },
  });

  if (!course) {
    notFound();
  }

  // Check enrollment
  const enrollment = await prisma.userCourseProgress.findUnique({
    where: {
      userId_courseId: {
        userId: dbUser.id,
        courseId: course.id,
      },
    },
  });

  if (!enrollment) {
    redirect(`/courses/${slug}`);
  }

  // Get lesson with module info
  const lesson = await prisma.lesson.findUnique({
    where: { id: lessonId },
    include: {
      module: {
        include: {
          course: true,
        },
      },
      attachments: true,
    },
  });

  if (!lesson) {
    notFound();
  }

  // Check track access
  if (lesson.track !== "BOTH" && lesson.track !== enrollment.enrolledTrack) {
    // User is not on the right track for this lesson
    redirect(`/courses/${slug}/learn`);
  }

  // Check if lesson is free or user is enrolled
  if (!lesson.isFree && !enrollment) {
    redirect(`/courses/${slug}`);
  }

  // Get lesson progress
  const lessonProgress = await prisma.lessonProgress.findUnique({
    where: {
      userId_lessonId: {
        userId: dbUser.id,
        lessonId: lesson.id,
      },
    },
  });

  // Check if a quiz exists for this lesson
  const hasQuiz = await prisma.quiz.findFirst({
    where: { courseId: course.id },
    select: { id: true },
  });

  // Get all lessons in the same module for navigation
  const moduleLessons = await prisma.lesson.findMany({
    where: {
      moduleId: lesson.moduleId,
    },
    orderBy: { orderIndex: "asc" },
    select: {
      id: true,
      title: true,
      orderIndex: true,
    },
  });

  // Get all modules in the course (for sidebar)
  const allModules = await prisma.module.findMany({
    where: {
      courseId: course.id,
    },
    include: {
      lessons: {
        orderBy: { orderIndex: "asc" },
        select: {
          id: true,
          title: true,
          track: true,
          orderIndex: true,
        },
      },
    },
    orderBy: { orderIndex: "asc" },
  });

  // Filter visible modules based on enrolled track
  const visibleModules = allModules.filter((module) => {
    if (module.track === "BOTH") return true;
    return module.track === enrollment.enrolledTrack;
  });

  // Calculate lesson completion status for all visible lessons
  const allLessonIds = visibleModules.flatMap((m) =>
    m.lessons.map((l) => l.id),
  );
  const allLessonProgress = await prisma.lessonProgress.findMany({
    where: {
      userId: dbUser.id,
      lessonId: { in: allLessonIds },
    },
    select: {
      lessonId: true,
      isCompleted: true,
    },
  });

  const completedLessonIds = new Set(
    allLessonProgress.filter((lp) => lp.isCompleted).map((lp) => lp.lessonId),
  );

  // Find previous and next lessons
  const currentIndex = moduleLessons.findIndex((l) => l.id === lessonId);
  const prevLesson: NavigationLesson | null = (() => {
    if (currentIndex > 0) {
      const prev = moduleLessons[currentIndex - 1];
      if (prev) return { id: prev.id, title: prev.title };
    }
    return null;
  })();
  const nextLesson: NavigationLesson | null = (() => {
    if (currentIndex < moduleLessons.length - 1) {
      const next = moduleLessons[currentIndex + 1];
      if (next) return { id: next.id, title: next.title };
    }
    return null;
  })();

  // Prepare module data with completion status
  const modulesData = visibleModules.map((module) => ({
    id: module.id,
    title: module.title,
    track: module.track,
    lessons: module.lessons.map((l) => ({
      id: l.id,
      title: l.title,
      track: l.track,
      isCompleted: completedLessonIds.has(l.id),
    })),
  }));

  return (
    <LessonViewClient
      lesson={{
        id: lesson.id,
        title: lesson.title,
        description: lesson.description,
        content: lesson.content,
        lessonType: lesson.lessonType as
          | "TEXT"
          | "VIDEO"
          | "INTERACTIVE"
          | "CODING",
        track: lesson.track as "BASIC" | "ADVANCED" | "BOTH",
        duration: lesson.duration,
        isFree: lesson.isFree,
        attachments: lesson.attachments.map((a) => ({
          id: a.id,
          name: a.name,
          url: a.url,
          fileType: a.fileType,
        })),
      }}
      moduleTitle={lesson.module.title}
      course={{
        id: course.id,
        slug: course.slug,
        title: course.title,
      }}
      enrollment={{
        enrolledTrack: enrollment.enrolledTrack as "BASIC" | "ADVANCED",
        progressPercent: enrollment.progressPercent,
      }}
      modules={modulesData}
      currentLessonProgress={lessonProgress?.isCompleted || false}
      hasQuiz={!!hasQuiz}
      navigation={{
        prevLesson,
        nextLesson,
      }}
    />
  );
}
