"use client";

import { useState, useRef, useEffect } from "react";
import { X, Send, MessageCircle, Loader2 } from "lucide-react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface AITutorChatProps {
  lessonId: string;
  courseId: string;
  lessonTitle: string;
  isOpen: boolean;
  onClose: () => void;
}

export function AITutorChat({
  lessonId,
  courseId,
  lessonTitle,
  isOpen,
  onClose,
}: AITutorChatProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState("");
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingMessage]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      textareaRef.current?.focus();
    }
  }, [isOpen]);

  // Load conversation history when component mounts or lesson changes
  useEffect(() => {
    if (isOpen && lessonId && courseId) {
      loadConversationHistory();
    }
  }, [isOpen, lessonId, courseId]);

  const loadConversationHistory = async () => {
    setLoadingHistory(true);
    try {
      const response = await fetch(
        `/api/ai/tutor/history?courseId=${courseId}&lessonId=${lessonId}`,
      );

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setConversationId(data.data.conversationId);
          const historyMessages = data.data.messages.map((msg: any) => ({
            id: Date.now() + Math.random().toString(),
            role: msg.role,
            content: msg.content,
            timestamp: msg.timestamp ? new Date(msg.timestamp) : new Date(),
          }));
          setMessages(historyMessages);
        }
      }
    } catch (error) {
      console.error("Error loading conversation history:", error);
    } finally {
      setLoadingHistory(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: inputValue.trim(),
      timestamp: new Date(),
    };

    // Add user message to chat
    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);
    setStreamingMessage("");

    try {
      const response = await fetch("/api/ai/tutor", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage.content,
          lessonId,
          courseId,
          conversationHistory: messages,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();

        // Handle rate limit error specifically
        if (response.status === 429) {
          const errorMessage: Message = {
            id: (Date.now() + 1).toString(),
            role: "assistant",
            content: `⏳ ${errorData.error || "Rate limit exceeded. Please wait a moment before sending another message."}`,
            timestamp: new Date(),
          };
          setMessages((prev) => [...prev, errorMessage]);
          setIsLoading(false);
          return;
        }

        throw new Error(errorData.error || "Failed to get AI response");
      }

      // Handle streaming response
      const reader = response.body?.getReader();
      const decoder = new TextDecoder();
      let fullResponse = "";

      if (reader) {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const chunk = decoder.decode(value, { stream: true });
          fullResponse += chunk;
          setStreamingMessage(fullResponse);
        }

        // Add complete AI response to messages
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          role: "assistant",
          content: fullResponse,
          timestamp: new Date(),
        };

        setMessages((prev) => [...prev, aiMessage]);
        setStreamingMessage("");
      }
    } catch (error) {
      console.error("Error sending message:", error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content:
          "I'm sorry, I encountered an error. Please try again or refresh the page.",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop overlay */}
      <div
        className="fixed inset-0 bg-black/20 z-40 lg:hidden"
        onClick={onClose}
      />

      {/* Chat sidebar */}
      <div
        className={`fixed right-0 top-0 h-full w-full lg:w-[400px] bg-white border-l border-zinc-200 shadow-2xl z-50 flex flex-col transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-200">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-zinc-900 flex items-center justify-center">
              <MessageCircle className="h-5 w-5 text-white" />
            </div>
            <div>
              <h2 className="text-base font-semibold text-zinc-900">
                AI Tutor
              </h2>
              <p className="text-xs text-zinc-600">Ask about this lesson</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="h-8 w-8 rounded-lg hover:bg-zinc-100 flex items-center justify-center transition-colors"
            aria-label="Close AI Tutor"
          >
            <X className="h-5 w-5 text-zinc-600" />
          </button>
        </div>

        {/* Messages area */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          {loadingHistory ? (
            <div className="flex items-center justify-center py-12">
              <div className="text-sm text-zinc-600">
                Loading conversation...
              </div>
            </div>
          ) : messages.length === 0 && !streamingMessage ? (
            <div className="text-center py-12">
              <div className="h-16 w-16 rounded-full bg-zinc-100 flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="h-8 w-8 text-zinc-400" />
              </div>
              <h3 className="text-sm font-semibold text-zinc-900 mb-2">
                Welcome to AI Tutor!
              </h3>
              <p className="text-sm text-zinc-600 mb-4 max-w-xs mx-auto">
                I'm here to help you understand "{lessonTitle}". Ask me anything
                about the lesson content!
              </p>
              <div className="text-xs text-zinc-500 space-y-2">
                <p>💡 Try asking:</p>
                <ul className="text-left max-w-xs mx-auto space-y-1">
                  <li>• "Can you explain this concept?"</li>
                  <li>• "What does this mean?"</li>
                  <li>• "Can you give me an example?"</li>
                </ul>
              </div>
            </div>
          ) : null}

          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              {msg.role === "assistant" && (
                <div className="h-8 w-8 rounded-full bg-zinc-900 flex items-center justify-center shrink-0">
                  <MessageCircle className="h-4 w-4 text-white" />
                </div>
              )}
              <div
                className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                  msg.role === "user"
                    ? "bg-zinc-900 text-white rounded-br-md"
                    : "bg-white border border-zinc-200 text-zinc-900 rounded-bl-md"
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                  {msg.content}
                </p>
                <span
                  className={`text-xs mt-2 block ${
                    msg.role === "user" ? "text-zinc-400" : "text-zinc-500"
                  }`}
                >
                  {msg.timestamp.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
              {msg.role === "user" && (
                <div className="h-8 w-8 rounded-full bg-zinc-900 flex items-center justify-center shrink-0 text-white text-xs font-semibold">
                  You
                </div>
              )}
            </div>
          ))}

          {/* Streaming message (AI typing) */}
          {streamingMessage && (
            <div className="flex gap-3 justify-start">
              <div className="h-8 w-8 rounded-full bg-zinc-900 flex items-center justify-center shrink-0">
                <MessageCircle className="h-4 w-4 text-white" />
              </div>
              <div className="max-w-[85%] rounded-2xl px-4 py-3 bg-white border border-zinc-200 text-zinc-900 rounded-bl-md">
                <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
                  {streamingMessage}
                </p>
              </div>
            </div>
          )}

          {/* Loading indicator */}
          {isLoading && !streamingMessage && (
            <div className="flex gap-3 justify-start">
              <div className="h-8 w-8 rounded-full bg-zinc-900 flex items-center justify-center shrink-0">
                <MessageCircle className="h-4 w-4 text-white" />
              </div>
              <div className="max-w-[85%] rounded-2xl px-4 py-3 bg-white border border-zinc-200 rounded-bl-md">
                <div className="flex gap-1">
                  <span className="h-2 w-2 bg-zinc-400 rounded-full animate-bounce" />
                  <span
                    className="h-2 w-2 bg-zinc-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  />
                  <span
                    className="h-2 w-2 bg-zinc-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  />
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input area */}
        <div className="border-t border-zinc-200 p-4 bg-white">
          <div className="flex gap-2">
            <textarea
              ref={textareaRef}
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask a question about the lesson..."
              rows={1}
              disabled={isLoading}
              className="flex-1 resize-none rounded-lg border border-zinc-300 px-4 py-3 text-sm text-zinc-900 placeholder-zinc-500 focus:outline-none focus:ring-2 focus:ring-zinc-400 focus:border-transparent disabled:opacity-50 disabled:cursor-not-allowed max-h-32"
              style={{
                minHeight: "44px",
                maxHeight: "128px",
                height: "auto",
              }}
            />
            <button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="h-11 w-11 rounded-lg bg-zinc-900 text-white hover:bg-zinc-800 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center transition-colors shrink-0"
              aria-label="Send message"
            >
              {isLoading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <Send className="h-5 w-5" />
              )}
            </button>
          </div>
          <p className="text-xs text-zinc-500 mt-2 px-1">
            Press Enter to send, Shift+Enter for new line
          </p>
        </div>
      </div>
    </>
  );
}
