"use client";

import { useState } from "react";
import { X, Check, XCircle, Trophy, RefreshCw } from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Progress } from "@repo/ui/components/progress";

interface QuizQuestion {
  id: string;
  question: string;
  options: Record<string, string>;
  orderIndex: number;
}

interface QuizAttempt {
  id: string;
  score: number;
  totalPoints: number;
  isPassed: boolean;
  startedAt: string;
  completedAt: string | null;
}

interface QuizResult {
  questionId: string;
  answer: string;
  isCorrect: boolean;
  pointsEarned: number;
  correctAnswer?: string;
  explanation?: string;
}

interface LessonQuizModalProps {
  lessonId: string;
  quiz: {
    id: string;
    title: string;
    description: string | null;
    passingScore: number;
    maxAttempts: number;
    timeLimit: number | null;
    questions: QuizQuestion[];
  };
  attempts: QuizAttempt[];
  onClose: () => void;
}

export function LessonQuizModal({
  lessonId,
  quiz,
  attempts,
  onClose,
}: LessonQuizModalProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [results, setResults] = useState<{
    score: number;
    isPassed: boolean;
    totalPoints: number;
    earnedPoints: number;
    passingScore: number;
    results: QuizResult[];
  } | null>(null);
  const [showResults, setShowResults] = useState(false);

  const currentQ = quiz.questions[currentQuestion];
  const progress = ((currentQuestion + 1) / quiz.questions.length) * 100;

  const handleAnswerSelect = (answer: string) => {
    if (!currentQ) return;
    setAnswers((prev) => ({
      ...prev,
      [currentQ.id]: answer,
    }));
  };

  const handleNext = () => {
    if (currentQuestion < quiz.questions.length - 1) {
      setCurrentQuestion((prev) => prev + 1);
    }
  };

  const handlePrev = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion((prev) => prev - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const response = await fetch(`/api/lessons/${lessonId}/quiz/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers }),
      });

      const data = await response.json();

      if (data.success) {
        setResults(data.data);
        setShowResults(true);
      } else {
        alert(data.error || "Failed to submit quiz");
      }
    } catch (error) {
      console.error("Error submitting quiz:", error);
      alert("Failed to submit quiz");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleRetry = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setResults(null);
    setShowResults(false);
  };

  // Check if all questions are answered
  const allAnswered = quiz.questions.every((q) => answers[q.id]);

  // Show results view
  if (showResults && results) {
    const resultMap = new Map(results.results.map((r) => [r.questionId, r]));

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <div className="bg-bg-primary rounded-lg max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
          {/* Header */}
          <div className="border-b border-border p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-semibold text-text-primary">
                Quiz Results
              </h2>
              <button
                onClick={onClose}
                className="text-text-secondary hover:text-text-primary"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            {/* Score Display */}
            <div className="flex items-center gap-6">
              <div
                className={`flex items-center gap-3 px-6 py-4 rounded-lg ${
                  results.isPassed
                    ? "bg-green-50 border border-green-200"
                    : "bg-red-50 border border-red-200"
                }`}
              >
                {results.isPassed ? (
                  <Trophy className="h-8 w-8 text-green-600" />
                ) : (
                  <XCircle className="h-8 w-8 text-red-600" />
                )}
                <div>
                  <div
                    className={`text-3xl font-bold ${
                      results.isPassed ? "text-green-700" : "text-red-700"
                    }`}
                  >
                    {results.score}%
                  </div>
                  <div
                    className={`text-sm ${
                      results.isPassed ? "text-green-600" : "text-red-600"
                    }`}
                  >
                    {results.isPassed ? "Passed!" : "Not passed"}
                  </div>
                </div>
              </div>

              <div className="text-sm text-text-secondary">
                <p>
                  Passing score:{" "}
                  <span className="font-medium">{results.passingScore}%</span>
                </p>
                <p>
                  Correct:{" "}
                  <span className="font-medium">
                    {results.earnedPoints} / {results.totalPoints}
                  </span>
                </p>
              </div>
            </div>
          </div>

          {/* Results List */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {quiz.questions.map((question, index) => {
              const result = resultMap.get(question.id);
              if (!result) return null;

              return (
                <div
                  key={question.id}
                  className={`p-4 rounded-lg border ${
                    result.isCorrect
                      ? "border-green-200 bg-green-50/50"
                      : "border-red-200 bg-red-50/50"
                  }`}
                >
                  <div className="flex items-start gap-3 mb-3">
                    {result.isCorrect ? (
                      <Check className="h-5 w-5 text-green-600 mt-0.5 shrink-0" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-600 mt-0.5 shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium text-text-primary mb-2">
                        {index + 1}. {question.question}
                      </p>

                      <div className="space-y-2 text-sm">
                        {Object.entries(question.options).map(
                          ([key, value]) => {
                            const isUserAnswer = result.answer === key;
                            const isCorrectAnswer =
                              result.correctAnswer === key;

                            return (
                              <div
                                key={key}
                                className={`p-2 rounded ${
                                  isCorrectAnswer
                                    ? "bg-green-100 text-green-800 font-medium"
                                    : isUserAnswer && !result.isCorrect
                                      ? "bg-red-100 text-red-800"
                                      : "text-text-secondary"
                                }`}
                              >
                                {key}: {value}
                                {isCorrectAnswer && " ✓"}
                                {isUserAnswer && !result.isCorrect && " ✗"}
                              </div>
                            );
                          },
                        )}
                      </div>

                      {result.explanation && (
                        <div className="mt-3 p-3 bg-bg-secondary rounded text-sm text-text-secondary">
                          <strong>Explanation:</strong> {result.explanation}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer */}
          <div className="border-t border-border p-6 flex items-center justify-between">
            <Button variant="outline" onClick={handleRetry} className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Try Again
            </Button>
            <Button onClick={onClose}>Close</Button>
          </div>
        </div>
      </div>
    );
  }

  // Show quiz taking view
  if (!currentQ) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-bg-primary rounded-lg max-w-2xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="border-b border-border p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-text-primary">
              {quiz.title}
            </h2>
            <button
              onClick={onClose}
              className="text-text-secondary hover:text-text-primary"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          {/* Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm text-text-secondary">
              <span>
                Question {currentQuestion + 1} of {quiz.questions.length}
              </span>
              <span>{Math.round(progress)}% complete</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        </div>

        {/* Question Content */}
        <div className="flex-1 overflow-y-auto p-6">
          <div className="mb-6">
            <h3 className="text-lg font-medium text-text-primary mb-4">
              {currentQ.question}
            </h3>

            <div className="space-y-3">
              {Object.entries(currentQ.options).map(([key, value]) => {
                const isSelected = answers[currentQ.id] === key;

                return (
                  <button
                    key={key}
                    onClick={() => handleAnswerSelect(key)}
                    className={`w-full text-left p-4 rounded-lg border transition-colors ${
                      isSelected
                        ? "border-primary bg-primary/5 text-text-primary"
                        : "border-border hover:border-primary/50 text-text-secondary"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`h-5 w-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                          isSelected
                            ? "border-primary bg-primary"
                            : "border-border"
                        }`}
                      >
                        {isSelected && <Check className="h-3 w-3 text-white" />}
                      </div>
                      <span className="font-medium">{key}:</span>
                      <span>{value}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Previous Attempts */}
          {attempts.length > 0 && currentQuestion === 0 && (
            <div className="mt-6 p-4 bg-bg-secondary rounded-lg">
              <h4 className="text-sm font-medium text-text-primary mb-2">
                Previous Attempts
              </h4>
              <div className="space-y-2 text-sm text-text-secondary">
                {attempts.slice(0, 3).map((attempt, index) => (
                  <div
                    key={attempt.id}
                    className="flex items-center justify-between"
                  >
                    <span>Attempt {attempts.length - index}</span>
                    <span
                      className={
                        attempt.isPassed ? "text-green-600" : "text-red-600"
                      }
                    >
                      {attempt.score}%
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer Navigation */}
        <div className="border-t border-border p-6 flex items-center justify-between">
          <Button
            variant="outline"
            onClick={handlePrev}
            disabled={currentQuestion === 0}
          >
            Previous
          </Button>

          <div className="text-sm text-text-secondary">
            {Object.keys(answers).length} / {quiz.questions.length} answered
          </div>

          {currentQuestion === quiz.questions.length - 1 ? (
            <Button
              onClick={handleSubmit}
              disabled={!allAnswered || isSubmitting}
            >
              {isSubmitting ? "Submitting..." : "Submit Quiz"}
            </Button>
          ) : (
            <Button onClick={handleNext} disabled={!answers[currentQ.id]}>
              Next
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
