"use client";

import { Checkbox } from "@repo/ui/components/checkbox";
import { cn } from "@repo/ui";
import { Circle } from "lucide-react";

interface Option {
  id: string;
  text: string;
}

interface QuestionCardProps {
  questionNumber: number;
  totalQuestions: number;
  questionText: string;
  options: Option[];
  selectedAnswers: string[];
  isMultiSelect?: boolean;
  onAnswerChange: (answers: string[]) => void;
}

export function QuestionCard({
  questionNumber,
  totalQuestions,
  questionText,
  options,
  selectedAnswers,
  isMultiSelect = false,
  onAnswerChange,
}: QuestionCardProps) {
  const handleSingleSelect = (optionId: string) => {
    if (selectedAnswers[0] === optionId) {
      onAnswerChange([]);
    } else {
      onAnswerChange([optionId]);
    }
  };

  const handleMultiSelect = (optionId: string, checked: boolean) => {
    if (checked) {
      onAnswerChange([...selectedAnswers, optionId]);
    } else {
      onAnswerChange(selectedAnswers.filter((id) => id !== optionId));
    }
  };

  // Ensure options is always an array
  const safeOptions = Array.isArray(options) ? options : [];

  if (safeOptions.length === 0) {
    return (
      <div className="w-full max-w-2xl mx-auto">
        <div className="text-center text-slate-600">
          No options available for this question.
        </div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Question header */}
      <div className="mb-6 text-center">
        <span className="text-sm font-medium text-primary">
          Question {questionNumber} of {totalQuestions}
        </span>
      </div>

      {/* Question text */}
      <h2 className="text-xl sm:text-2xl font-semibold text-slate-900 text-center mb-8">
        {questionText}
      </h2>

      {/* Options */}
      {isMultiSelect ? (
        <div className="space-y-3">
          {safeOptions.map((option) => (
            <label
              key={option.id}
              className={cn(
                "flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all",
                selectedAnswers.includes(option.id)
                  ? "border-primary bg-primary-50"
                  : "border-slate-200 hover:border-slate-300 hover:bg-slate-50",
              )}
            >
              <Checkbox
                checked={selectedAnswers.includes(option.id)}
                onCheckedChange={(checked) =>
                  handleMultiSelect(option.id, checked as boolean)
                }
              />
              <span className="text-base text-slate-700">{option.text}</span>
            </label>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {safeOptions.map((option) => {
            const isSelected = selectedAnswers[0] === option.id;
            return (
              <div
                key={option.id}
                role="radio"
                aria-checked={isSelected}
                tabIndex={0}
                onClick={() => handleSingleSelect(option.id)}
                onKeyDown={(e) => {
                  if (e.key === " " || e.key === "Enter") {
                    e.preventDefault();
                    handleSingleSelect(option.id);
                  }
                }}
                className={cn(
                  "flex items-center gap-4 p-4 rounded-xl border-2 cursor-pointer transition-all",
                  isSelected
                    ? "border-primary bg-primary-50"
                    : "border-slate-200 hover:border-slate-300 hover:bg-slate-50",
                )}
              >
                <span
                  className={cn(
                    "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                    isSelected
                      ? "border-primary bg-primary"
                      : "border-slate-300"
                  )}
                >
                  {isSelected && <Circle className="h-2 w-2 fill-white text-white" />}
                </span>
                <span className="text-base text-slate-700">{option.text}</span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
