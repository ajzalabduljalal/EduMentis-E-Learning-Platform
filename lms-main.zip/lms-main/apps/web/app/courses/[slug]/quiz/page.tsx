"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@clerk/nextjs";
import { QuestionCard } from "./components/QuestionCard";
import { QuizHeader } from "./components/QuizHeader";
import { QuizNavigation } from "./components/QuizNavigation";
import { Loader2 } from "lucide-react";

interface Question {
  id: string;
  questionText: string;
  questionType: "MULTIPLE_CHOICE" | "TEXT" | "CODE" | "FILE_UPLOAD";
  options: { id: string; text: string }[];
  points: number;
}

interface Quiz {
  id: string;
  title: string;
  description: string | null;
  timeLimit: number | null;
  course: {
    id: string;
    title: string;
    slug: string;
  };
  questions: Question[];
}

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default function QuizPage({ params }: PageProps) {
  const router = useRouter();
  const { isLoaded, userId } = useAuth();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [answers, setAnswers] = useState<Record<string, string[]>>({});
  const [timeRemaining, setTimeRemaining] = useState<number | undefined>();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const submitRef = useRef<() => void>(() => {});

  // Handle auth check and redirect
  useEffect(() => {
    if (isLoaded && !userId) {
      const currentPath = window.location.pathname;
      router.push(`/sign-in?redirect_url=${encodeURIComponent(currentPath)}`);
    }
  }, [isLoaded, userId, router]);

  // Fetch quiz data
  useEffect(() => {
    // Skip if not authenticated yet
    if (!isLoaded || !userId) return;

    async function fetchQuiz() {
      try {
        const resolvedParams = await params;
        const slug = resolvedParams.slug;

        // First get course to find entry quiz ID
        const courseRes = await fetch(`/api/courses/${slug}`);
        const courseData = await courseRes.json();

        if (!courseData.success || !courseData.data.entryQuiz) {
          router.push(`/courses/${slug}`);
          return;
        }

        // Fetch quiz
        const quizRes = await fetch(
          `/api/quizzes/${courseData.data.entryQuiz.id}`,
        );
        const quizData = await quizRes.json();

        if (quizData.success) {
          setQuiz(quizData.data);
          if (quizData.data.timeLimit) {
            setTimeRemaining(quizData.data.timeLimit * 60); // Convert to seconds
          }
        } else {
          router.push(`/courses/${slug}`);
        }
      } catch (error) {
        console.error("Failed to fetch quiz:", error);
      } finally {
        setLoading(false);
      }
    }

    fetchQuiz();
  }, [params, router]);

  // Timer countdown
  useEffect(() => {
    if (timeRemaining === undefined || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev === undefined || prev <= 1) {
          clearInterval(timer);
          // Auto-submit when time runs out
          submitRef.current();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeRemaining]);

  // Keyboard navigation
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "ArrowLeft" && currentQuestion > 1) {
        setCurrentQuestion((prev) => prev - 1);
      } else if (
        e.key === "ArrowRight" &&
        quiz &&
        currentQuestion < quiz.questions.length
      ) {
        setCurrentQuestion((prev) => prev + 1);
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentQuestion, quiz]);

  const handleAnswerChange = useCallback(
    (questionId: string, selectedAnswers: string[]) => {
      setAnswers((prev) => ({
        ...prev,
        [questionId]: selectedAnswers,
      }));
    },
    [],
  );

  const handleSubmit = async () => {
    if (!quiz) return;

    setIsSubmitting(true);

    try {
      const formattedAnswers = quiz.questions.map((q) => ({
        questionId: q.id,
        selectedAnswers: answers[q.id] || [],
      }));

      const response = await fetch(`/api/quizzes/${quiz.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          answers: formattedAnswers,
          timeSpent: quiz.timeLimit
            ? quiz.timeLimit * 60 - (timeRemaining || 0)
            : undefined,
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Store result in sessionStorage for results page
        sessionStorage.setItem(
          "quizResult",
          JSON.stringify({
            ...data.data,
            courseName: quiz.course.title,
            courseSlug: quiz.course.slug,
          }),
        );
        router.push(`/courses/${quiz.course.slug}/quiz/results`);
      } else {
        console.error("Failed to submit quiz:", data.error);
      }
    } catch (error) {
      console.error("Error submitting quiz:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Keep the ref updated with latest handleSubmit
  submitRef.current = handleSubmit;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-slate-600">Loading assessment...</p>
        </div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-slate-600">Redirecting...</p>
        </div>
      </div>
    );
  }

  const currentQ = quiz.questions[currentQuestion - 1];

  if (!currentQ) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-slate-600">Loading question...</p>
        </div>
      </div>
    );
  }

  const currentAnswers = answers[currentQ.id] || [];

  return (
    <div className="min-h-screen bg-slate-50 pb-24">
      {/* Header with progress */}
      <QuizHeader
        courseName={quiz.course.title}
        quizTitle={quiz.title}
        currentQuestion={currentQuestion}
        totalQuestions={quiz.questions.length}
        timeRemaining={timeRemaining}
      />

      {/* Question */}
      <div className="py-12 px-4">
        <QuestionCard
          questionNumber={currentQuestion}
          totalQuestions={quiz.questions.length}
          questionText={currentQ.questionText}
          options={currentQ.options}
          selectedAnswers={currentAnswers}
          isMultiSelect={false} // For now, all questions are single select
          onAnswerChange={(selected) =>
            handleAnswerChange(currentQ.id, selected)
          }
        />
      </div>

      {/* Navigation */}
      <QuizNavigation
        currentQuestion={currentQuestion}
        totalQuestions={quiz.questions.length}
        canGoBack={currentQuestion > 1}
        canGoForward={currentAnswers.length > 0}
        isSubmitting={isSubmitting}
        isLastQuestion={currentQuestion === quiz.questions.length}
        onPrevious={() => setCurrentQuestion((prev) => prev - 1)}
        onNext={() => setCurrentQuestion((prev) => prev + 1)}
        onSubmit={handleSubmit}
      />
    </div>
  );
}
