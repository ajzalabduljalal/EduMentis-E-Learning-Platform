import { Skeleton } from "@repo/ui/components/skeleton";

export default function QuizLoading() {
  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Quiz Header Skeleton */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Skeleton className="h-10 w-10 rounded-lg" />
              <div>
                <Skeleton className="h-5 w-48" />
                <Skeleton className="h-4 w-32 mt-1" />
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Skeleton className="h-8 w-20 rounded-full" />
              <Skeleton className="h-10 w-28" />
            </div>
          </div>
          {/* Progress bar */}
          <Skeleton className="h-2 w-full mt-4 rounded-full" />
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex items-center justify-center p-6">
        <div className="w-full max-w-2xl">
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-8">
            {/* Question number */}
            <Skeleton className="h-5 w-24 mb-4" />

            {/* Question text */}
            <Skeleton className="h-7 w-full mb-2" />
            <Skeleton className="h-7 w-3/4 mb-8" />

            {/* Answer options */}
            <div className="space-y-3">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="flex items-center gap-4 p-4 rounded-lg border border-slate-200"
                >
                  <Skeleton className="h-5 w-5 rounded-full" />
                  <Skeleton className="h-5 w-3/4" />
                </div>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-6">
            <Skeleton className="h-11 w-28" />
            <Skeleton className="h-11 w-28" />
          </div>
        </div>
      </div>
    </div>
  );
}
