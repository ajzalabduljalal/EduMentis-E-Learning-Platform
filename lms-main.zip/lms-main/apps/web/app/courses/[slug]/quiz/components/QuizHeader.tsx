"use client";

import { Progress } from "@repo/ui/components/progress";
import { Clock } from "lucide-react";

interface QuizHeaderProps {
  courseName: string;
  quizTitle: string;
  currentQuestion: number;
  totalQuestions: number;
  timeRemaining?: number; // in seconds
}

export function QuizHeader({
  courseName,
  quizTitle,
  currentQuestion,
  totalQuestions,
  timeRemaining,
}: QuizHeaderProps) {
  const progress = (currentQuestion / totalQuestions) * 100;

  // Format time remaining
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="bg-white border-b border-slate-200 sticky top-0 z-10">
      <div className="mx-auto max-w-3xl px-4 py-4">
        {/* Course and quiz name */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <p className="text-sm text-slate-500">{courseName}</p>
            <h1 className="text-lg font-semibold text-slate-900">{quizTitle}</h1>
          </div>

          {/* Timer */}
          {timeRemaining !== undefined && (
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${
                timeRemaining < 60
                  ? "bg-error-50 text-error-700"
                  : timeRemaining < 300
                  ? "bg-warning-50 text-warning-700"
                  : "bg-slate-100 text-slate-700"
              }`}
            >
              <Clock className="h-4 w-4" />
              <span className="font-mono font-medium">
                {formatTime(timeRemaining)}
              </span>
            </div>
          )}
        </div>

        {/* Progress bar */}
        <div className="flex items-center gap-4">
          <Progress value={progress} className="flex-1 h-2" />
          <span className="text-sm font-medium text-slate-600 shrink-0">
            {currentQuestion}/{totalQuestions}
          </span>
        </div>
      </div>
    </div>
  );
}
