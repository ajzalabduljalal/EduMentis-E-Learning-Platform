"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import confetti from "canvas-confetti";
import { Button } from "@repo/ui/components/button";
import { Badge } from "@repo/ui/components/badge";
import { ScoreCircle } from "../components/ScoreCircle";
import {
  GraduationCap,
  ArrowRight,
  Trophy,
  Target,
  Sparkles,
} from "lucide-react";

interface QuizResult {
  score: number;
  earnedPoints: number;
  totalPoints: number;
  isPassed: boolean;
  assignedTrack: "BASIC" | "ADVANCED";
  courseName: string;
  courseSlug: string;
}

export default function QuizResultsPage() {
  const router = useRouter();
  const [result, setResult] = useState<QuizResult | null>(null);

  useEffect(() => {
    // Get result from sessionStorage
    const storedResult = sessionStorage.getItem("quizResult");
    if (storedResult) {
      const parsed = JSON.parse(storedResult);
      setResult(parsed);

      // Clear from storage
      sessionStorage.removeItem("quizResult");

      // Fire confetti if passed or good score
      if (parsed.score >= 50) {
        fireConfetti(parsed.score);
      }
    } else {
      // No result, redirect back
      router.push("/courses");
    }
  }, [router]);

  const fireConfetti = (score: number) => {
    const duration = score >= 80 ? 3000 : 1500;
    const particleCount = score >= 80 ? 150 : 50;

    // Center burst
    confetti({
      particleCount,
      spread: 70,
      origin: { y: 0.6 },
      colors: ["#4f46e5", "#10b981", "#f59e0b", "#ec4899", "#8b5cf6"],
    });

    // If excellent score, continuous celebration
    if (score >= 80) {
      const end = Date.now() + duration;

      const frame = () => {
        confetti({
          particleCount: 3,
          angle: 60,
          spread: 55,
          origin: { x: 0 },
          colors: ["#4f46e5", "#10b981", "#f59e0b"],
        });
        confetti({
          particleCount: 3,
          angle: 120,
          spread: 55,
          origin: { x: 1 },
          colors: ["#4f46e5", "#10b981", "#f59e0b"],
        });

        if (Date.now() < end) {
          requestAnimationFrame(frame);
        }
      };

      frame();
    }
  };

  if (!result) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-slate-400">Loading results...</div>
      </div>
    );
  }

  const getMessage = () => {
    if (result.score >= 90) {
      return {
        title: "Outstanding!",
        subtitle: "You've demonstrated exceptional knowledge.",
        icon: Trophy,
        iconColor: "text-warning",
      };
    }
    if (result.score >= 70) {
      return {
        title: "Great job!",
        subtitle: "You've shown strong understanding of the material.",
        icon: Sparkles,
        iconColor: "text-primary",
      };
    }
    if (result.score >= 50) {
      return {
        title: "Good effort!",
        subtitle: "You're on the right track. Keep learning!",
        icon: Target,
        iconColor: "text-success",
      };
    }
    return {
      title: "Keep practicing!",
      subtitle: "Every expert was once a beginner.",
      icon: GraduationCap,
      iconColor: "text-slate-600",
    };
  };

  const message = getMessage();
  const Icon = message.icon;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-white py-12 px-4">
      <div className="max-w-lg mx-auto text-center">
        {/* Icon */}
        <div className="mb-6">
          <div
            className={`inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-100 ${message.iconColor}`}
          >
            <Icon className="h-8 w-8" />
          </div>
        </div>

        {/* Title */}
        <h1 className="text-3xl sm:text-4xl font-bold text-slate-900 mb-2">
          {message.title}
        </h1>
        <p className="text-slate-600 mb-8">{message.subtitle}</p>

        {/* Score Circle */}
        <div className="flex justify-center mb-8">
          <ScoreCircle score={result.score} size={200} />
        </div>

        {/* Points breakdown */}
        <div className="bg-white rounded-xl border border-slate-200 p-6 mb-8">
          <div className="flex items-center justify-between text-sm mb-4">
            <span className="text-slate-600">Points earned</span>
            <span className="font-semibold">
              {result.earnedPoints} / {result.totalPoints}
            </span>
          </div>

          {/* Track assignment */}
          <div className="pt-4 border-t border-slate-200">
            <p className="text-sm text-slate-600 mb-2">
              You&apos;ve been placed in the
            </p>
            <Badge
              variant={result.assignedTrack === "ADVANCED" ? "advanced" : "beginner"}
              className="text-base px-4 py-1"
            >
              {result.assignedTrack === "ADVANCED"
                ? "Advanced Track"
                : "Basic Track"}
            </Badge>
            <p className="text-xs text-slate-500 mt-3">
              {result.assignedTrack === "ADVANCED"
                ? "You&apos;ll get access to advanced content and challenges."
                : "Start with the fundamentals and build a strong foundation."}
            </p>
          </div>
        </div>

        {/* What this means */}
        <div className="bg-primary-50 rounded-xl p-6 mb-8 text-left">
          <h3 className="font-semibold text-slate-900 mb-2">
            What does this mean?
          </h3>
          <p className="text-sm text-slate-600">
            Based on your assessment results, we&apos;ve personalized your learning
            path. You&apos;ll see content tailored to your current skill level,
            helping you learn more effectively.
            {result.assignedTrack === "BASIC" &&
              " Don't worry - you can always upgrade to the Advanced track as you progress!"}
          </p>
        </div>

        {/* CTA */}
        <Link href={`/courses/${result.courseSlug}`}>
          <Button size="lg" className="w-full h-14 text-lg">
            Start Learning Now
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </Link>

        {/* Back to courses link */}
        <Link
          href="/courses"
          className="inline-block mt-4 text-sm text-slate-500 hover:text-primary"
        >
          Back to all courses
        </Link>
      </div>
    </div>
  );
}
