"use client";

import { Button } from "@repo/ui/components/button";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";

interface QuizNavigationProps {
  currentQuestion: number;
  totalQuestions: number;
  canGoBack: boolean;
  canGoForward: boolean;
  isSubmitting?: boolean;
  isLastQuestion: boolean;
  onPrevious: () => void;
  onNext: () => void;
  onSubmit: () => void;
}

export function QuizNavigation({
  currentQuestion,
  totalQuestions,
  canGoBack,
  canGoForward,
  isSubmitting,
  isLastQuestion,
  onPrevious,
  onNext,
  onSubmit,
}: QuizNavigationProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200">
      <div className="mx-auto max-w-3xl px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Previous button */}
          <Button
            variant="outline"
            onClick={onPrevious}
            disabled={!canGoBack || isSubmitting}
          >
            <ChevronLeft className="h-4 w-4 mr-1" />
            Previous
          </Button>

          {/* Question indicators */}
          <div className="hidden sm:flex items-center gap-1">
            {Array.from({ length: totalQuestions }).map((_, i) => (
              <div
                key={i}
                className={`w-2 h-2 rounded-full transition-colors ${
                  i + 1 === currentQuestion
                    ? "bg-primary w-4"
                    : i + 1 < currentQuestion
                    ? "bg-primary/40"
                    : "bg-slate-200"
                }`}
              />
            ))}
          </div>

          {/* Next/Submit button */}
          {isLastQuestion ? (
            <Button onClick={onSubmit} disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Quiz"
              )}
            </Button>
          ) : (
            <Button onClick={onNext} disabled={!canGoForward || isSubmitting}>
              Next
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          )}
        </div>

        {/* Keyboard shortcuts hint */}
        <p className="text-center text-xs text-slate-400 mt-2">
          Use <kbd className="px-1 bg-slate-100 rounded">←</kbd>{" "}
          <kbd className="px-1 bg-slate-100 rounded">→</kbd> arrow keys to
          navigate
        </p>
      </div>
    </div>
  );
}
