"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@repo/ui/components/accordion";
import { Badge } from "@repo/ui/components/badge";
import { FileText, Code, Lock, Clock, CheckCircle2 } from "lucide-react";
import Link from "next/link";

interface Lesson {
  id: string;
  title: string;
  duration: number | null;
  track: "BASIC" | "ADVANCED" | "BOTH";
  isFree: boolean;
  lessonType: "TEXT" | "VIDEO" | "INTERACTIVE" | "CODING";
  isCompleted?: boolean;
}

interface Module {
  id: string;
  title: string;
  description: string | null;
  track: "BASIC" | "ADVANCED" | "BOTH";
  lessons: Lesson[];
}

interface ModuleAccordionProps {
  modules: Module[];
  courseSlug: string;
  isEnrolled: boolean;
  enrolledTrack?: "BASIC" | "ADVANCED";
}

const lessonTypeIcons = {
  TEXT: FileText,
  VIDEO: FileText,
  INTERACTIVE: FileText,
  CODING: Code,
};

export function ModuleAccordion({
  modules,
  courseSlug,
  isEnrolled,
  enrolledTrack,
}: ModuleAccordionProps) {
  // Filter modules based on enrolled track (if applicable)
  const visibleModules = modules.filter((module) => {
    if (!isEnrolled) return true; // Show all when not enrolled
    if (module.track === "BOTH") return true;
    return module.track === enrolledTrack;
  });

  const getTotalDuration = (lessons: Lesson[]) => {
    const totalMinutes = lessons.reduce((sum, l) => sum + (l.duration || 0), 0);
    if (totalMinutes < 60) return `${totalMinutes}min`;
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
  };

  return (
    <div className="space-y-4">
      <Accordion type="multiple" className="space-y-3">
        {visibleModules.map((module, index) => {
          const completedCount = module.lessons.filter(
            (l) => l.isCompleted,
          ).length;
          const totalCount = module.lessons.length;

          return (
            <AccordionItem
              key={module.id}
              value={module.id}
              className="border border-border rounded-lg px-0 overflow-hidden bg-bg-primary"
            >
              <AccordionTrigger className="px-6 py-5 hover:no-underline hover:bg-bg-secondary transition-colors">
                <div className="flex items-start gap-4 text-left w-full">
                  {/* Module Badge */}
                  <div className="flex items-center justify-center h-10 px-3 rounded-lg bg-bg-tertiary text-text-secondary font-medium text-sm shrink-0">
                    Module {index + 1}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-text-primary text-base mb-1">
                          {module.title}
                        </h3>
                        {module.description && (
                          <p className="text-sm text-text-secondary line-clamp-1">
                            {module.description}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-text-secondary mt-3">
                      <span>
                        {totalCount} {totalCount === 1 ? "lesson" : "lessons"}
                      </span>
                      <span>•</span>
                      <span>{getTotalDuration(module.lessons)}</span>
                      {isEnrolled && (
                        <>
                          <span>•</span>
                          <span className="text-text-primary font-medium">
                            {completedCount} / {totalCount} completed
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              </AccordionTrigger>

              <AccordionContent className="px-6 pb-4">
                <div className="space-y-1 pt-2">
                  {module.lessons.map((lesson, lessonIndex) => {
                    const Icon = lessonTypeIcons[lesson.lessonType];
                    const isLocked = !isEnrolled && !lesson.isFree;
                    const isCompleted = lesson.isCompleted;

                    const lessonContent = (
                      <div
                        className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                          isLocked
                            ? "text-text-secondary cursor-not-allowed"
                            : "hover:bg-bg-secondary cursor-pointer"
                        }`}
                      >
                        {/* Icon */}
                        <div
                          className={`flex h-9 w-9 items-center justify-center rounded-lg shrink-0 ${
                            isCompleted
                              ? "bg-green-100 text-green-600"
                              : isLocked
                                ? "bg-bg-tertiary text-text-secondary"
                                : "bg-bg-tertiary text-text-primary"
                          }`}
                        >
                          {isCompleted ? (
                            <CheckCircle2 className="h-4 w-4" />
                          ) : isLocked ? (
                            <Lock className="h-4 w-4" />
                          ) : (
                            <Icon className="h-4 w-4" />
                          )}
                        </div>

                        {/* Title */}
                        <div className="flex-1 min-w-0">
                          <span
                            className={`text-sm font-medium ${
                              isLocked
                                ? "text-text-secondary"
                                : "text-text-primary"
                            }`}
                          >
                            {lessonIndex + 1}. {lesson.title}
                          </span>
                        </div>

                        {/* Free badge */}
                        {lesson.isFree && !isEnrolled && (
                          <Badge
                            variant="secondary"
                            className="text-xs bg-green-100 text-green-700 shrink-0"
                          >
                            Free
                          </Badge>
                        )}

                        {/* Duration */}
                        {lesson.duration && (
                          <div className="flex items-center gap-1 text-xs text-text-secondary shrink-0">
                            <Clock className="h-3 w-3" />
                            {lesson.duration}min
                          </div>
                        )}
                      </div>
                    );

                    if (isLocked) {
                      return <div key={lesson.id}>{lessonContent}</div>;
                    }

                    return (
                      <Link
                        key={lesson.id}
                        href={`/courses/${courseSlug}/lessons/${lesson.id}`}
                      >
                        {lessonContent}
                      </Link>
                    );
                  })}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}
