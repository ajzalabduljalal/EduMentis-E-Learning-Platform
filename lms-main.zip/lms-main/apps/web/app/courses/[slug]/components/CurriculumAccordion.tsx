"use client";

import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@repo/ui/components/accordion";
import { Badge } from "@repo/ui/components/badge";
import { PlayCircle, FileText, Code, Lock, Clock } from "lucide-react";

interface Lesson {
  id: string;
  title: string;
  duration: number | null;
  track: "BASIC" | "ADVANCED" | "BOTH";
  isFree: boolean;
  lessonType: "TEXT" | "VIDEO" | "INTERACTIVE" | "CODING";
}

interface Module {
  id: string;
  title: string;
  description: string | null;
  track: "BASIC" | "ADVANCED" | "BOTH";
  lessons: Lesson[];
}

interface CurriculumAccordionProps {
  modules: Module[];
  isEnrolled: boolean;
  enrolledTrack?: "BASIC" | "ADVANCED";
}

const lessonTypeIcons = {
  TEXT: FileText,
  VIDEO: PlayCircle,
  INTERACTIVE: PlayCircle,
  CODING: Code,
};

const trackColors = {
  BASIC: "bg-primary-100 text-primary-700",
  ADVANCED: "bg-error-50 text-error-700",
  BOTH: "bg-slate-100 text-slate-700",
};

export function CurriculumAccordion({
  modules,
  isEnrolled,
  enrolledTrack,
}: CurriculumAccordionProps) {
  // Filter modules based on enrolled track (if applicable)
  const visibleModules = modules.filter((module) => {
    if (!isEnrolled) return true; // Show all when not enrolled
    if (module.track === "BOTH") return true;
    return module.track === enrolledTrack;
  });

  const getTotalDuration = (lessons: Lesson[]) => {
    const totalMinutes = lessons.reduce((sum, l) => sum + (l.duration || 0), 0);
    if (totalMinutes < 60) return `${totalMinutes}min`;
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    return mins > 0 ? `${hours}h ${mins}min` : `${hours}h`;
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-slate-900">
          Course Curriculum
        </h3>
        <div className="text-sm text-slate-500">
          {modules.length} modules •{" "}
          {modules.reduce((sum, m) => sum + m.lessons.length, 0)} lessons
        </div>
      </div>

      <Accordion type="multiple" className="space-y-3">
        {visibleModules.map((module, index) => (
          <AccordionItem
            key={module.id}
            value={module.id}
            className="border border-slate-200 rounded-xl px-0 overflow-hidden"
          >
            <AccordionTrigger className="px-5 py-4 hover:no-underline hover:bg-slate-50">
              <div className="flex items-center gap-4 text-left">
                {/* Module number */}
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary-100 text-primary-700 font-semibold text-sm">
                  {index + 1}
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-base font-medium text-slate-900">
                      {module.title}
                    </span>
                    {module.track !== "BOTH" && (
                      <Badge
                        variant="secondary"
                        className={trackColors[module.track]}
                      >
                        {module.track}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-sm text-slate-500 mt-1">
                    <span>{module.lessons.length} lessons</span>
                    <span>•</span>
                    <span>{getTotalDuration(module.lessons)}</span>
                  </div>
                </div>
              </div>
            </AccordionTrigger>

            <AccordionContent className="px-5 pb-4">
              <div className="space-y-1 pt-2">
                {module.lessons.map((lesson) => {
                  const Icon = lessonTypeIcons[lesson.lessonType];
                  const isLocked = !isEnrolled && !lesson.isFree;

                  return (
                    <div
                      key={lesson.id}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                        isLocked
                          ? "text-slate-400"
                          : "text-slate-700 hover:bg-slate-50"
                      }`}
                    >
                      {/* Icon */}
                      <div
                        className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                          isLocked
                            ? "bg-slate-100"
                            : "bg-primary-50 text-primary"
                        }`}
                      >
                        {isLocked ? (
                          <Lock className="h-4 w-4" />
                        ) : (
                          <Icon className="h-4 w-4" />
                        )}
                      </div>

                      {/* Title */}
                      <span className="flex-1 text-sm">{lesson.title}</span>

                      {/* Track badge */}
                      {lesson.track !== "BOTH" && (
                        <Badge
                          variant="secondary"
                          className={`text-xs ${trackColors[lesson.track]}`}
                        >
                          {lesson.track}
                        </Badge>
                      )}

                      {/* Free badge */}
                      {lesson.isFree && !isEnrolled && (
                        <Badge variant="success" className="text-xs">
                          Free
                        </Badge>
                      )}

                      {/* Duration */}
                      {lesson.duration && (
                        <div className="flex items-center gap-1 text-xs text-slate-400">
                          <Clock className="h-3 w-3" />
                          {lesson.duration}min
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>
    </div>
  );
}
