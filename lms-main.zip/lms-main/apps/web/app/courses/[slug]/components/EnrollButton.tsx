"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@repo/ui/components/button";
import { Progress } from "@repo/ui/components/progress";
import { Loader2, Play, CheckCircle } from "lucide-react";
import { useToast } from "@repo/ui";

interface EnrollButtonProps {
  courseId: string;
  courseSlug: string;
  hasEntryQuiz: boolean;
  entryQuizId?: string;
  isEnrolled: boolean;
  progress?: number;
  price: number;
}

export function EnrollButton({
  courseId,
  courseSlug,
  hasEntryQuiz,
  entryQuizId,
  isEnrolled,
  progress = 0,
  price,
}: EnrollButtonProps) {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();

  const handleEnroll = async () => {
    setLoading(true);

    try {
      // If course has entry quiz, redirect to quiz
      if (hasEntryQuiz && entryQuizId) {
        router.push(`/courses/${courseSlug}/quiz`);
        return;
      }

      // Otherwise, enroll directly
      const response = await fetch("/api/enrollments", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ courseId }),
      });

      const data = await response.json();

      if (data.success) {
        toast({
          title: "Successfully enrolled!",
          description: "Your personalized learning path is ready.",
          variant: "success",
        });
        router.refresh();
      } else if (data.requiresQuiz) {
        router.push(`/courses/${courseSlug}/quiz`);
      } else {
        throw new Error(data.error || "Failed to enroll");
      }
    } catch {
      toast({
        title: "Enrollment failed",
        description: "Please try again or contact support.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = () => {
    router.push(`/courses/${courseSlug}/learn`);
  };

  if (isEnrolled) {
    return (
      <div className="space-y-4">
        {/* Progress indicator */}
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Your progress</span>
          <span className="font-semibold text-foreground">
            {progress}% complete
          </span>
        </div>
        <Progress value={progress} className="h-2" />

        {/* Continue button */}
        <Button
          size="lg"
          className="w-full h-12 text-base"
          onClick={handleContinue}
        >
          {progress === 100 ? (
            <>
              <CheckCircle className="mr-2 h-5 w-5" />
              View Certificate
            </>
          ) : (
            <>
              <Play className="mr-2 h-5 w-5" />
              Continue Learning
            </>
          )}
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Button
        size="lg"
        className="w-full h-12 text-base"
        onClick={handleEnroll}
        disabled={loading}
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            {hasEntryQuiz ? "Preparing Quiz..." : "Enrolling..."}
          </>
        ) : hasEntryQuiz ? (
          <>
            <Play className="mr-2 h-5 w-5" />
            Take Entry Quiz & Enroll
          </>
        ) : price === 0 ? (
          "Enroll for Free"
        ) : (
          `Enroll for $${price}`
        )}
      </Button>

      {hasEntryQuiz && (
        <p className="text-sm text-muted-foreground text-center">
          Complete a quick assessment to personalize your learning path
        </p>
      )}
    </div>
  );
}
