import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import { notFound, redirect } from "next/navigation";
import { AssessmentClient } from "./AssessmentClient";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default async function AssessmentPage({ params }: PageProps) {
  const { userId } = await auth();

  if (!userId) {
    redirect("/sign-in");
  }

  const { slug } = await params;

  // Get user from database
  const user = await prisma.user.findUnique({
    where: { clerkId: userId },
  });

  if (!user) {
    redirect("/sign-in");
  }

  // Get course with final exam
  const course = await prisma.course.findUnique({
    where: { slug },
    include: {
      finalExam: {
        include: {
          questions: {
            orderBy: { orderIndex: "asc" },
          },
        },
      },
    },
  });

  if (!course || !course.finalExam) {
    notFound();
  }

  // Check if user has completed the course (100% progress required)
  const progress = await prisma.userCourseProgress.findUnique({
    where: {
      userId_courseId: {
        userId: user.id,
        courseId: course.id,
      },
    },
  });

  if (!progress || progress.progressPercent < 100) {
    redirect(`/courses/${slug}/learn`);
  }

  // Check if already passed
  if (progress.isCompleted && progress.certificateUrl) {
    redirect(`/courses/${slug}/certificate`);
  }

  // Check remaining attempts
  const attempts = await prisma.assessmentAttempt.count({
    where: {
      userId: user.id,
      courseId: course.id,
    },
  });

  const maxAttempts = course.finalExam.maxAttempts;
  const remainingAttempts = maxAttempts - attempts;

  if (remainingAttempts <= 0) {
    // Check if any attempt passed
    const passedAttempt = await prisma.assessmentAttempt.findFirst({
      where: {
        userId: user.id,
        courseId: course.id,
        status: "PASSED",
      },
    });

    if (passedAttempt) {
      redirect(`/courses/${slug}/certificate`);
    } else {
      redirect(`/courses/${slug}/assessment/results?noAttempts=true`);
    }
  }

  // Transform questions for client
  const questions = course.finalExam.questions.map((q) => ({
    id: q.id,
    questionType: q.questionType as
      | "MULTIPLE_CHOICE"
      | "TEXT"
      | "CODE"
      | "FILE_UPLOAD",
    questionText: q.question,
    points: q.points,
    options:
      q.questionType === "MULTIPLE_CHOICE" && q.options
        ? Object.entries(q.options as Record<string, string>).map(
            ([key, value]) => ({
              id: key,
              text: value,
            }),
          )
        : [],
    starterCode: q.starterCode || undefined,
    maxLength: q.maxLength || undefined,
  }));

  return (
    <AssessmentClient
      course={{
        id: course.id,
        title: course.title,
        slug: course.slug,
      }}
      quiz={{
        id: course.finalExam.id,
        title: course.finalExam.title,
        description: course.finalExam.description || undefined,
        timeLimit: course.finalExam.timeLimit || undefined,
        passingScore: course.finalExam.passingScore,
      }}
      questions={questions}
      remainingAttempts={remainingAttempts}
    />
  );
}
