"use client";

import { Button } from "@repo/ui/components/button";
import { ArrowLeft, ArrowRight, Send } from "lucide-react";

interface AssessmentNavigationProps {
  currentQuestion: number;
  totalQuestions: number;
  canGoBack: boolean;
  canGoForward: boolean;
  isSubmitting: boolean;
  isLastQuestion: boolean;
  onPrevious: () => void;
  onNext: () => void;
  onSubmit: () => void;
}

export function AssessmentNavigation({
  currentQuestion,
  totalQuestions,
  canGoBack,
  canGoForward,
  isSubmitting,
  isLastQuestion,
  onPrevious,
  onNext,
  onSubmit,
}: AssessmentNavigationProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-border py-4 px-4 z-10">
      <div className="max-w-3xl mx-auto flex items-center justify-between">
        {/* Previous button */}
        <Button
          variant="outline"
          onClick={onPrevious}
          disabled={!canGoBack || isSubmitting}
          size="lg"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>

        {/* Question dots indicator */}
        <div className="flex items-center gap-2">
          {Array.from({ length: totalQuestions }, (_, i) => (
            <div
              key={i}
              className={`h-2 w-2 rounded-full transition-all ${
                i + 1 === currentQuestion
                  ? "bg-primary w-8"
                  : i + 1 < currentQuestion
                    ? "bg-primary/50"
                    : "bg-zinc-200"
              }`}
            />
          ))}
        </div>

        {/* Next or Submit button */}
        {isLastQuestion ? (
          <Button onClick={onSubmit} disabled={isSubmitting} size="lg">
            {isSubmitting ? "Submitting..." : "Submit Assessment"}
            <Send className="ml-2 h-4 w-4" />
          </Button>
        ) : (
          <Button
            onClick={onNext}
            disabled={!canGoForward || isSubmitting}
            size="lg"
          >
            Next
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  );
}
