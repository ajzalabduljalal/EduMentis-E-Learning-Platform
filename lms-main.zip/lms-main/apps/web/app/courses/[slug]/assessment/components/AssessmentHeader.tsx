"use client";

import { Clock, AlertCircle } from "lucide-react";
import { Badge } from "@repo/ui/components/badge";

interface AssessmentHeaderProps {
  courseName: string;
  assessmentTitle: string;
  currentQuestion: number;
  totalQuestions: number;
  timeRemaining?: number;
  remainingAttempts: number;
}

export function AssessmentHeader({
  courseName,
  assessmentTitle,
  currentQuestion,
  totalQuestions,
  timeRemaining,
  remainingAttempts,
}: AssessmentHeaderProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const progress = (currentQuestion / totalQuestions) * 100;
  const isLowTime = timeRemaining !== undefined && timeRemaining < 300; // Less than 5 minutes

  return (
    <div className="bg-white border-b border-border sticky top-0 z-10">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top section */}
        <div className="py-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-text-secondary">{courseName}</p>
            <h1 className="text-xl font-semibold text-text-primary">
              {assessmentTitle}
            </h1>
          </div>

          <div className="flex items-center gap-4">
            {/* Remaining attempts */}
            <Badge variant="secondary" className="text-sm">
              <AlertCircle className="h-3 w-3 mr-1" />
              {remainingAttempts}{" "}
              {remainingAttempts === 1 ? "attempt" : "attempts"} left
            </Badge>

            {/* Timer */}
            {timeRemaining !== undefined && (
              <div
                className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
                  isLowTime
                    ? "bg-red-50 text-red-700"
                    : "bg-zinc-100 text-zinc-700"
                }`}
              >
                <Clock className="h-4 w-4" />
                <span className="font-mono font-semibold">
                  {formatTime(timeRemaining)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Progress bar */}
        <div className="pb-4">
          <div className="flex items-center justify-between text-sm text-text-secondary mb-2">
            <span>
              Question {currentQuestion} of {totalQuestions}
            </span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
