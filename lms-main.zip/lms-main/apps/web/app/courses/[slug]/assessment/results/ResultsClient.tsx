"use client";

import { useEffect } from "react";
import Link from "next/link";
import confetti from "canvas-confetti";
import { Button } from "@repo/ui/components/button";
import { Badge } from "@repo/ui/components/badge";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@repo/ui/components/card";
import {
  XCircle,
  Trophy,
  AlertCircle,
  Clock,
  CheckCircle2,
  Download,
} from "lucide-react";

interface ResultsClientProps {
  courseSlug: string;
  noAttempts?: boolean;
  courseName?: string;
  status?: "PENDING" | "GRADING" | "PASSED" | "FAILED";
  score?: number | null;
  mcqScore?: number | null;
  mcqTotalPoints?: number | null;
  passingScore?: number;
  needsManualReview?: boolean;
  hasCertificate?: boolean;
}

export function ResultsClient({
  courseSlug,
  noAttempts,
  status,
  score,
  mcqScore,
  mcqTotalPoints,
  passingScore = 70,
  needsManualReview,
}: ResultsClientProps) {
  // Fire minimal confetti on pass (mint accent only)
  useEffect(() => {
    if (status !== "PASSED") return;

    confetti({
      particleCount: 50,
      spread: 50,
      origin: { y: 0.6 },
      colors: ["#7FFFC3"], // Minimal mint accent
    });
  }, [status]);

  // No attempts remaining
  if (noAttempts) {
    return (
      <div className="min-h-screen bg-white py-12 px-4">
        <div className="max-w-lg mx-auto text-center">
          <div className="mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 text-red-600">
              <XCircle className="h-8 w-8" />
            </div>
          </div>

          <h1 className="text-3xl font-bold text-zinc-900 mb-2">
            No Attempts Remaining
          </h1>
          <p className="text-zinc-600 mb-8">
            You&apos;ve used all available attempts for this assessment. Please
            contact your instructor for assistance.
          </p>

          <Link href="/courses">
            <Button size="lg">Back to Courses</Button>
          </Link>
        </div>
      </div>
    );
  }

  // Build status display
  const getStatusDisplay = () => {
    if (status === "PASSED") {
      return {
        title: "Congratulations!",
        subtitle: "You've successfully passed the final assessment!",
        icon: Trophy,
        iconBg: "bg-zinc-900",
        iconColor: "text-white",
        badgeVariant: "success" as const,
      };
    }

    if (status === "GRADING") {
      return {
        title: "Assessment Submitted",
        subtitle: "Your answers are being reviewed by the instructor.",
        icon: Clock,
        iconBg: "bg-zinc-100",
        iconColor: "text-zinc-600",
        badgeVariant: "warning" as const,
      };
    }

    if (status === "FAILED") {
      return {
        title: "Keep Practicing",
        subtitle: "Don't give up! Review the material and try again.",
        icon: AlertCircle,
        iconBg: "bg-red-100",
        iconColor: "text-red-600",
        badgeVariant: "error" as const,
      };
    }

    return {
      title: "Assessment Complete",
      subtitle: "Your submission has been received.",
      icon: CheckCircle2,
      iconBg: "bg-zinc-100",
      iconColor: "text-zinc-600",
      badgeVariant: "secondary" as const,
    };
  };

  const display = getStatusDisplay();
  const Icon = display.icon;

  return (
    <div className="min-h-screen bg-white py-12 px-4">
      <div className="max-w-2xl mx-auto">
        {/* Status icon */}
        <div className="text-center mb-8">
          <div
            className={`inline-flex items-center justify-center w-20 h-20 rounded-full ${display.iconBg} ${display.iconColor} mb-4`}
          >
            <Icon className="h-10 w-10" />
          </div>
          <h1 className="text-4xl font-bold text-zinc-900 mb-2">
            {display.title}
          </h1>
          <p className="text-zinc-600 text-lg">{display.subtitle}</p>
        </div>

        {/* Score card */}
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Assessment Results</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Status */}
            <div className="flex items-center justify-between">
              <span className="text-zinc-600">Status</span>
              <Badge variant={display.badgeVariant}>
                {status?.replace("_", " ") || "UNKNOWN"}
              </Badge>
            </div>

            {/* Score percentage */}
            {score !== null && score !== undefined && (
              <div className="flex items-center justify-between">
                <span className="text-zinc-600">Score</span>
                <span className="font-semibold text-2xl">{score}%</span>
              </div>
            )}

            {/* MCQ Score details */}
            {mcqTotalPoints !== null &&
              mcqTotalPoints !== undefined &&
              mcqTotalPoints > 0 && (
                <div className="flex items-center justify-between">
                  <span className="text-zinc-600">Multiple Choice Score</span>
                  <span className="font-semibold">
                    {mcqScore ?? 0} / {mcqTotalPoints} points
                  </span>
                </div>
              )}

            {/* Passing score */}
            <div className="pt-4 border-t border-zinc-200">
              <div className="flex items-center justify-between text-sm">
                <span className="text-zinc-600">Passing score required</span>
                <span className="font-medium">{passingScore}%</span>
              </div>
            </div>

            {/* Manual review notice */}
            {needsManualReview && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="font-medium text-yellow-900 text-sm mb-1">
                      Pending Manual Review
                    </p>
                    <p className="text-xs text-yellow-700">
                      Some questions require manual grading. You&apos;ll be
                      notified once your instructor completes the review.
                    </p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex flex-col gap-3 items-start">
          {status === "PASSED" && (
            <Link href={`/courses/${courseSlug}/certificate`}>
              <Button size="lg">
                <Download className="mr-2 h-5 w-5" />
                View & Download Certificate
              </Button>
            </Link>
          )}

          {status === "FAILED" && (
            <Link href={`/courses/${courseSlug}/assessment`}>
              <Button size="lg">Retry Assessment</Button>
            </Link>
          )}

          <Link href={`/courses/${courseSlug}/learn`}>
            <Button variant="secondary" size="lg">
              ← Back to Course
            </Button>
          </Link>

          <Link href="/courses">
            <Button variant="secondary" size="lg">
              All Courses
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
