import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import { redirect } from "next/navigation";
import { ResultsClient } from "./ResultsClient";

interface PageProps {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ attemptId?: string; noAttempts?: string }>;
}

export default async function AssessmentResultsPage({
  params,
  searchParams,
}: PageProps) {
  const { slug } = await params;
  const { attemptId, noAttempts } = await searchParams;

  // Handle "no attempts remaining" case
  if (noAttempts === "true") {
    return <ResultsClient courseSlug={slug} noAttempts />;
  }

  const { userId } = await auth();
  if (!userId) {
    redirect("/sign-in");
  }

  const user = await prisma.user.findUnique({
    where: { clerkId: userId },
  });

  if (!user) {
    redirect("/sign-in");
  }

  const course = await prisma.course.findUnique({
    where: { slug },
    include: {
      finalExam: true,
    },
  });

  if (!course) {
    redirect("/courses");
  }

  // Get the specific attempt or the latest one
  const attempt = attemptId
    ? await prisma.assessmentAttempt.findUnique({
        where: { id: attemptId },
      })
    : await prisma.assessmentAttempt.findFirst({
        where: {
          userId: user.id,
          courseId: course.id,
        },
        orderBy: { submittedAt: "desc" },
      });

  if (!attempt) {
    redirect(`/courses/${slug}/learn`);
  }

  // Get the quiz attempt for detailed MCQ scores
  const quizAttempt = course.finalExam
    ? await prisma.quizAttempt.findFirst({
        where: {
          userId: user.id,
          quizId: course.finalExam.id,
        },
        orderBy: { completedAt: "desc" },
      })
    : null;

  // Check if certificate was generated
  const progress = await prisma.userCourseProgress.findUnique({
    where: {
      userId_courseId: {
        userId: user.id,
        courseId: course.id,
      },
    },
  });

  return (
    <ResultsClient
      courseSlug={slug}
      courseName={course.title}
      status={attempt.status as "PENDING" | "GRADING" | "PASSED" | "FAILED"}
      score={attempt.score}
      mcqScore={quizAttempt?.score ?? null}
      mcqTotalPoints={quizAttempt?.totalPoints ?? null}
      passingScore={course.finalExam?.passingScore ?? 70}
      needsManualReview={attempt.status === "GRADING"}
      hasCertificate={!!progress?.certificateUrl}
    />
  );
}
