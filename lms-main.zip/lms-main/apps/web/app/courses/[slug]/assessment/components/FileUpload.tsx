"use client";

import { useState, useRef } from "react";
import { Button } from "@repo/ui/components/button";
import { Upload, File, X, Loader2 } from "lucide-react";

interface FileUploadProps {
  value?: string;
  onChange: (url: string) => void;
}

export function FileUpload({ value, onChange }: FileUploadProps) {
  const [uploading, setUploading] = useState(false);
  const [fileName, setFileName] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    setFileName(file.name);

    try {
      // Get presigned URL
      const presignResponse = await fetch("/api/upload/presigned", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          fileName: file.name,
          fileType: file.type,
          fileSize: file.size,
        }),
      });

      const presignData = await presignResponse.json();

      if (!presignData.success) {
        throw new Error(presignData.error || "Failed to get upload URL");
      }

      // Upload to R2
      const uploadResponse = await fetch(presignData.data.uploadUrl, {
        method: "PUT",
        body: file,
        headers: {
          "Content-Type": file.type,
        },
      });

      if (!uploadResponse.ok) {
        throw new Error("Failed to upload file");
      }

      // Save the public URL
      onChange(presignData.data.publicUrl);
    } catch (error) {
      console.error("File upload error:", error);
      alert("Failed to upload file. Please try again.");
      setFileName("");
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = () => {
    onChange("");
    setFileName("");
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div>
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileSelect}
        className="hidden"
        accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png"
      />

      {value || fileName ? (
        <div className="border border-border rounded-lg p-4 bg-zinc-50">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white rounded-lg border border-border">
                <File className="h-5 w-5 text-zinc-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-text-primary">
                  {fileName || "Uploaded file"}
                </p>
                {value && (
                  <p className="text-xs text-text-secondary">
                    File uploaded successfully
                  </p>
                )}
              </div>
            </div>
            <Button
              variant="secondary"
              size="sm"
              onClick={handleRemove}
              disabled={uploading}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="w-full border-2 border-dashed border-border rounded-lg p-8 hover:border-primary hover:bg-zinc-50 transition-colors"
        >
          <div className="flex flex-col items-center gap-2">
            {uploading ? (
              <>
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-sm text-text-secondary">Uploading...</p>
              </>
            ) : (
              <>
                <Upload className="h-8 w-8 text-zinc-400" />
                <p className="text-sm font-medium text-text-primary">
                  Click to upload file
                </p>
                <p className="text-xs text-text-secondary">
                  PDF, DOC, TXT, or images (max 10MB)
                </p>
              </>
            )}
          </div>
        </button>
      )}
    </div>
  );
}
