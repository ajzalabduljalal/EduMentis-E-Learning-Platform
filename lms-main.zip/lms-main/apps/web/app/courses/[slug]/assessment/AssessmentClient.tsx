"use client";

import { useState, useEffect, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";
import { QuestionCard } from "./components/QuestionCard";
import { AssessmentHeader } from "./components/AssessmentHeader";
import { AssessmentNavigation } from "./components/AssessmentNavigation";
import { Loader2 } from "lucide-react";

type QuestionType = "MULTIPLE_CHOICE" | "TEXT" | "CODE" | "FILE_UPLOAD";

interface Question {
  id: string;
  questionType: QuestionType;
  questionText: string;
  points: number;
  options: { id: string; text: string }[];
  starterCode?: string;
  maxLength?: number;
}

interface Quiz {
  id: string;
  title: string;
  description?: string;
  timeLimit?: number;
  passingScore: number;
}

interface Course {
  id: string;
  title: string;
  slug: string;
}

interface AssessmentClientProps {
  course: Course;
  quiz: Quiz;
  questions: Question[];
  remainingAttempts: number;
}

export function AssessmentClient({
  course,
  quiz,
  questions,
  remainingAttempts,
}: AssessmentClientProps) {
  const router = useRouter();
  const [currentQuestion, setCurrentQuestion] = useState(1);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [timeRemaining, setTimeRemaining] = useState<number | undefined>(
    quiz.timeLimit ? quiz.timeLimit * 60 : undefined,
  );
  const [isSubmitting, setIsSubmitting] = useState(false);
  const submitRef = useRef<() => void>(() => {});

  // Timer countdown
  useEffect(() => {
    if (timeRemaining === undefined || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev === undefined || prev <= 1) {
          clearInterval(timer);
          // Auto-submit when time runs out
          submitRef.current();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeRemaining]);

  // Keyboard navigation
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "ArrowLeft" && currentQuestion > 1) {
        setCurrentQuestion((prev) => prev - 1);
      } else if (e.key === "ArrowRight" && currentQuestion < questions.length) {
        setCurrentQuestion((prev) => prev + 1);
      }
    }

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentQuestion, questions.length]);

  const handleAnswerChange = useCallback(
    (questionId: string, answer: string | string[]) => {
      setAnswers((prev) => ({
        ...prev,
        [questionId]: answer,
      }));
    },
    [],
  );

  const handleSubmit = async () => {
    setIsSubmitting(true);

    try {
      // Format answers for submission
      const formattedAnswers = questions.map((q) => ({
        questionId: q.id,
        answer:
          answers[q.id] || (q.questionType === "MULTIPLE_CHOICE" ? [] : ""),
        questionType: q.questionType,
      }));

      const response = await fetch(`/api/assessments/${course.id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          answers: formattedAnswers,
          timeSpent: quiz.timeLimit
            ? quiz.timeLimit * 60 - (timeRemaining || 0)
            : undefined,
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Navigate to results page with attemptId — server component will fetch from DB
        router.push(
          `/courses/${course.slug}/assessment/results?attemptId=${data.data.attemptId}`,
        );
        // Don't reset isSubmitting — component will unmount on navigation
      } else {
        console.error("Failed to submit assessment:", data.error);
        alert("Failed to submit assessment. Please try again.");
        setIsSubmitting(false);
      }
    } catch (error) {
      console.error("Error submitting assessment:", error);
      alert("An error occurred. Please try again.");
      setIsSubmitting(false);
    }
  };

  // Keep the ref updated with latest handleSubmit
  submitRef.current = handleSubmit;

  if (isSubmitting) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-zinc-600">Submitting your assessment...</p>
        </div>
      </div>
    );
  }

  const currentQ = questions[currentQuestion - 1];
  if (!currentQ) {
    return null;
  }

  const currentAnswer = answers[currentQ.id];

  return (
    <div className="min-h-screen bg-zinc-50 pb-24">
      {/* Header with progress */}
      <AssessmentHeader
        courseName={course.title}
        assessmentTitle={quiz.title}
        currentQuestion={currentQuestion}
        totalQuestions={questions.length}
        timeRemaining={timeRemaining}
        remainingAttempts={remainingAttempts}
      />

      {/* Question */}
      <div className="py-12 px-4">
        <QuestionCard
          question={currentQ}
          questionNumber={currentQuestion}
          totalQuestions={questions.length}
          answer={currentAnswer}
          onAnswerChange={(answer) => handleAnswerChange(currentQ.id, answer)}
        />
      </div>

      {/* Navigation */}
      <AssessmentNavigation
        currentQuestion={currentQuestion}
        totalQuestions={questions.length}
        canGoBack={currentQuestion > 1}
        canGoForward={true}
        isSubmitting={isSubmitting}
        isLastQuestion={currentQuestion === questions.length}
        onPrevious={() => setCurrentQuestion((prev) => prev - 1)}
        onNext={() => setCurrentQuestion((prev) => prev + 1)}
        onSubmit={handleSubmit}
      />
    </div>
  );
}
