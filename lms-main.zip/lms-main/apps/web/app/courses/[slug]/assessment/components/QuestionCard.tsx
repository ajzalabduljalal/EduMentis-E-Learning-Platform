"use client";

import { Card } from "@repo/ui/components/card";
import { Textarea } from "@repo/ui/components/textarea";
import { cn } from "@repo/ui";
import { Circle } from "lucide-react";
import { CodeEditor } from "./CodeEditor";
import { FileUpload } from "./FileUpload";

type QuestionType = "MULTIPLE_CHOICE" | "TEXT" | "CODE" | "FILE_UPLOAD";

interface Question {
  id: string;
  questionType: QuestionType;
  questionText: string;
  points: number;
  options: { id: string; text: string }[];
  starterCode?: string;
  maxLength?: number;
}

interface QuestionCardProps {
  question: Question;
  questionNumber: number;
  totalQuestions: number;
  answer: string | string[] | undefined;
  onAnswerChange: (answer: string | string[]) => void;
}

export function QuestionCard({
  question,
  questionNumber,
  totalQuestions,
  answer,
  onAnswerChange,
}: QuestionCardProps) {
  return (
    <div className="max-w-3xl mx-auto">
      <Card className="p-8 border-border bg-white">
        {/* Question header */}
        <div className="mb-6">
          <p className="text-sm text-text-secondary mb-2">
            Question {questionNumber} of {totalQuestions}
          </p>
          <h2 className="text-xl font-semibold text-text-primary mb-2">
            {question.questionText}
          </h2>
          <p className="text-sm text-text-secondary">
            {question.points} {question.points === 1 ? "point" : "points"}
          </p>
        </div>

        {/* Answer input based on question type */}
        {question.questionType === "MULTIPLE_CHOICE" && (
          <div className="space-y-3">
            {question.options.map((option) => {
              const currentAnswer = Array.isArray(answer) ? answer[0] : answer;
              const isSelected = currentAnswer === option.id;
              return (
                <div
                  key={option.id}
                  role="radio"
                  aria-checked={isSelected}
                  tabIndex={0}
                  onClick={() => {
                    if (isSelected) {
                      onAnswerChange([]);
                    } else {
                      onAnswerChange([option.id]);
                    }
                  }}
                  onKeyDown={(e) => {
                    if (e.key === " " || e.key === "Enter") {
                      e.preventDefault();
                      if (isSelected) {
                        onAnswerChange([]);
                      } else {
                        onAnswerChange([option.id]);
                      }
                    }
                  }}
                  className={cn(
                    "flex items-start space-x-3 p-4 rounded-lg border cursor-pointer transition-colors",
                    isSelected
                      ? "border-primary bg-primary/5"
                      : "border-border hover:bg-zinc-50"
                  )}
                >
                  <span
                    className={cn(
                      "mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                      isSelected
                        ? "border-primary bg-primary"
                        : "border-slate-300"
                    )}
                  >
                    {isSelected && <Circle className="h-2 w-2 fill-white text-white" />}
                  </span>
                  <span className="flex-1 font-normal text-base">
                    {option.text}
                  </span>
                </div>
              );
            })}
          </div>
        )}

        {question.questionType === "TEXT" && (
          <div>
            <Textarea
              value={typeof answer === "string" ? answer : ""}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) =>
                onAnswerChange(e.target.value)
              }
              placeholder="Type your answer here..."
              className="min-h-[200px] text-base"
              maxLength={question.maxLength}
            />
            {question.maxLength && (
              <p className="text-sm text-text-secondary mt-2">
                {typeof answer === "string" ? answer.length : 0} /{" "}
                {question.maxLength} characters
              </p>
            )}
          </div>
        )}

        {question.questionType === "CODE" && (
          <CodeEditor
            value={
              typeof answer === "string" ? answer : question.starterCode || ""
            }
            onChange={onAnswerChange}
          />
        )}

        {question.questionType === "FILE_UPLOAD" && (
          <FileUpload
            value={typeof answer === "string" ? answer : undefined}
            onChange={onAnswerChange}
          />
        )}
      </Card>
    </div>
  );
}
