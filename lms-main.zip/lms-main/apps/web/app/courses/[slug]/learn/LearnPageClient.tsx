"use client";

import { useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  Lock,
  FileText,
} from "lucide-react";
import { Progress } from "@repo/ui/components/progress";
import { Button } from "@repo/ui/components/button";
import { ModuleAccordion } from "../components/ModuleAccordion";
import { getCategoryConfig } from "../../../lib/category-config";

interface Course {
  id: string;
  slug: string;
  title: string;
  shortDescription: string | null;
  category: string | null;
}

interface Enrollment {
  enrolledTrack: "BASIC" | "ADVANCED";
  progressPercent: number;
}

interface Lesson {
  id: string;
  title: string;
  duration: number | null;
  track: "BASIC" | "ADVANCED" | "BOTH";
  isFree: boolean;
  lessonType: "TEXT" | "VIDEO" | "INTERACTIVE" | "CODING";
  isCompleted: boolean;
}

interface Module {
  id: string;
  title: string;
  description: string | null;
  track: "BASIC" | "ADVANCED" | "BOTH";
  lessons: Lesson[];
}

interface Stats {
  totalLessons: number;
  completedCount: number;
}

interface AssessmentInfo {
  status: "PASSED" | "FAILED" | "NOT_STARTED";
  score: number | null;
  attemptDate: Date | null;
  passedScore: number;
  hasPassed: boolean;
  maxAttempts: number;
  attemptCount: number;
}

interface LearnPageClientProps {
  course: Course;
  enrollment: Enrollment;
  modules: Module[];
  stats: Stats;
  lastAccessedLesson?: Lesson;
  assessmentInfo?: AssessmentInfo | null;
}

export function LearnPageClient({
  course,
  enrollment,
  modules,
  stats,
  lastAccessedLesson,
  assessmentInfo,
}: LearnPageClientProps) {
  const [activeTab, setActiveTab] = useState<
    "learning-path" | "assessments" | "about"
  >("learning-path");

  // Resolve category config on the client side
  const categoryConfig = getCategoryConfig(course.category);
  const CategoryIcon = categoryConfig.icon;
  const progressPercent = enrollment.progressPercent;
  const masteryPercent = Math.round(
    (stats.completedCount / stats.totalLessons) * 100,
  );

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Back button */}
      <div className="border-b border-border">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-4">
          <Link
            href="/dashboard"
            className="inline-flex items-center gap-2 text-sm text-text-secondary hover:text-text-primary transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Link>
        </div>
      </div>

      {/* Course Header */}
      <div className="border-b border-border bg-bg-primary">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex items-start justify-between gap-6">
            {/* Left: Course info */}
            <div className="flex items-start gap-4">
              <div
                className={`flex h-14 w-14 items-center justify-center rounded-lg ${categoryConfig.bgColor} ${categoryConfig.color} shrink-0`}
              >
                <CategoryIcon className="h-7 w-7" />
              </div>
              <div>
                <h1 className="text-2xl font-semibold text-text-primary">
                  {course.title}
                </h1>
                <p className="mt-1 text-sm text-text-secondary">
                  {enrollment.enrolledTrack === "ADVANCED"
                    ? "Advanced Track"
                    : "Basic Track"}
                </p>
              </div>
            </div>

            {/* Right: Progress */}
            <div className="flex flex-col items-end gap-3 min-w-[200px]">
              <div className="w-full">
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="text-text-secondary">Completed</span>
                  <span className="font-semibold text-text-primary">
                    {Math.round(progressPercent)}%
                  </span>
                </div>
                <Progress value={progressPercent} className="h-2" />
              </div>
              <div className="w-full">
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="text-text-secondary">Mastery</span>
                  <span className="font-semibold text-text-primary">
                    {masteryPercent}%
                  </span>
                </div>
                <Progress value={masteryPercent} className="h-2" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-border bg-bg-primary sticky top-0 z-10">
        <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
          <nav className="flex gap-8">
            <button
              onClick={() => setActiveTab("learning-path")}
              className={`py-4 text-sm font-medium border-b-2 transition-colors ${
                activeTab === "learning-path"
                  ? "border-primary text-primary"
                  : "border-transparent text-text-secondary hover:text-text-primary"
              }`}
            >
              Learning Path
            </button>
            <button
              onClick={() => setActiveTab("assessments")}
              className={`py-4 text-sm font-medium border-b-2 transition-colors ${
                activeTab === "assessments"
                  ? "border-primary text-primary"
                  : "border-transparent text-text-secondary hover:text-text-primary"
              }`}
            >
              Assessments
            </button>
            <button
              onClick={() => setActiveTab("about")}
              className={`py-4 text-sm font-medium border-b-2 transition-colors ${
                activeTab === "about"
                  ? "border-primary text-primary"
                  : "border-transparent text-text-secondary hover:text-text-primary"
              }`}
            >
              About
            </button>
          </nav>
        </div>
      </div>

      {/* Tab Content */}
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === "learning-path" && (
          <div className="space-y-8">
            {/* Continue from where you left off */}
            {lastAccessedLesson && (
              <div>
                <h2 className="text-sm font-medium text-text-secondary mb-3">
                  Continue from where you left off
                </h2>
                <Link
                  href={`/courses/${course.slug}/lessons/${lastAccessedLesson.id}`}
                  className="block group"
                >
                  <div className="bg-bg-secondary border border-border rounded-lg p-6 hover:-translate-y-1 transition-all duration-200">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="text-base font-semibold text-text-primary group-hover:text-primary transition-colors">
                          {lastAccessedLesson.title}
                        </h3>
                        <p className="mt-1 text-sm text-text-secondary">
                          {lastAccessedLesson.lessonType === "CODING"
                            ? "Coding lesson"
                            : "Text lesson"}
                        </p>
                      </div>
                      <div className="ml-4">
                        <div className="h-10 w-10 rounded-full bg-bg-primary flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                          <ArrowRight className="h-5 w-5" />
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              </div>
            )}

            {/* Module List */}
            <div>
              <h2 className="text-lg font-semibold text-text-primary mb-4">
                Course Modules
              </h2>
              <ModuleAccordion
                modules={modules}
                courseSlug={course.slug}
                isEnrolled={true}
                enrolledTrack={enrollment.enrolledTrack}
              />
            </div>
          </div>
        )}

        {activeTab === "assessments" && (
          <div className="space-y-6">
            {progressPercent >= 100 ? (
              <div className="space-y-4">
                {/* Show failed attempt details if applicable */}
                {assessmentInfo?.status === "FAILED" && (
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-red-900">
                          Assessment Not Passed
                        </p>
                        <p className="text-sm text-red-700">
                          Score: {assessmentInfo.score}% (Need{" "}
                          {assessmentInfo.passedScore}%)
                        </p>
                        {assessmentInfo.attemptDate && (
                          <p className="text-xs text-red-600 mt-1">
                            Last attempt:{" "}
                            {new Date(
                              assessmentInfo.attemptDate,
                            ).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      {assessmentInfo.attemptCount <
                        assessmentInfo.maxAttempts && (
                        <Link href={`/courses/${course.slug}/assessment`}>
                          <Button size="sm">Retry Assessment</Button>
                        </Link>
                      )}
                    </div>
                  </div>
                )}

                {/* Show passed status */}
                {assessmentInfo?.status === "PASSED" && (
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium text-green-900">
                          Assessment Passed!
                        </p>
                        <p className="text-sm text-green-700">
                          Score: {assessmentInfo.score}%
                        </p>
                        {assessmentInfo.attemptDate && (
                          <p className="text-xs text-green-600 mt-1">
                            Completed:{" "}
                            {new Date(
                              assessmentInfo.attemptDate,
                            ).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                      <Link href={`/courses/${course.slug}/certificate`}>
                        <Button size="sm">View Certificate</Button>
                      </Link>
                    </div>
                  </div>
                )}

                {/* Show not started or ready to take */}
                {(!assessmentInfo ||
                  assessmentInfo.status === "NOT_STARTED") && (
                  <div className="border border-zinc-200 rounded-lg p-8 text-center space-y-4">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-zinc-100 rounded-full mx-auto">
                      <CheckCircle2 className="h-8 w-8 text-zinc-600" />
                    </div>
                    <h2 className="text-lg font-semibold text-zinc-900">
                      Ready to take the assessment!
                    </h2>
                    <p className="text-sm text-zinc-600">
                      Complete all lessons and demonstrate your knowledge to
                      earn your certificate.
                    </p>
                    <div className="pt-2">
                      <Link href={`/courses/${course.slug}/assessment`}>
                        <Button size="lg" className="gap-2">
                          <FileText className="h-4 w-4" />
                          Take Final Assessment
                        </Button>
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="border border-zinc-200 rounded-lg p-8 text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-zinc-100 rounded-full mx-auto">
                  <Lock className="h-8 w-8 text-zinc-400" />
                </div>
                <h2 className="text-lg font-medium text-zinc-900">
                  Final Assessment Locked
                </h2>
                <p className="text-sm text-zinc-600">
                  Complete all modules to unlock the final assessment.
                </p>
                <div className="max-w-xs mx-auto space-y-2">
                  <Progress value={progressPercent} className="h-2" />
                  <p className="text-xs text-zinc-500">
                    {stats.completedCount} of {stats.totalLessons} lessons
                    completed
                  </p>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === "about" && (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-text-primary mb-2">
                About this course
              </h2>
              <p className="text-sm text-text-secondary">
                {course.shortDescription || "No description available."}
              </p>
            </div>
            <div>
              <h3 className="text-base font-semibold text-text-primary mb-2">
                Your Track
              </h3>
              <p className="text-sm text-text-secondary">
                You are enrolled in the{" "}
                <span className="font-medium text-text-primary">
                  {enrollment.enrolledTrack === "ADVANCED"
                    ? "Advanced"
                    : "Basic"}
                </span>{" "}
                track based on your entry assessment score.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
