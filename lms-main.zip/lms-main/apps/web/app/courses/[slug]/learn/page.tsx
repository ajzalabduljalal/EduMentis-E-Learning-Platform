import { auth } from "@clerk/nextjs/server";
import { redirect, notFound } from "next/navigation";
import { prisma } from "@repo/db";
import { LearnPageClient } from "./LearnPageClient";

export default async function LearnPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { userId: clerkId } = await auth();
  const { slug } = await params;

  if (!clerkId) {
    redirect("/sign-in");
  }

  // Find the internal user
  const dbUser = await prisma.user.findUnique({
    where: { clerkId },
  });

  if (!dbUser) {
    redirect("/sign-in");
  }

  // Fetch the course
  const course = await prisma.course.findUnique({
    where: { slug },
    include: {
      modules: {
        include: {
          lessons: {
            orderBy: { orderIndex: "asc" },
          },
        },
        orderBy: { orderIndex: "asc" },
      },
      finalExam: {
        select: {
          id: true,
          passingScore: true,
          maxAttempts: true,
        },
      },
    },
  });

  if (!course) {
    notFound();
  }

  // Check if user is enrolled
  const enrollment = await prisma.userCourseProgress.findUnique({
    where: {
      userId_courseId: {
        userId: dbUser.id,
        courseId: course.id,
      },
    },
  });

  if (!enrollment) {
    redirect(`/courses/${slug}`);
  }

  // Fetch lesson progress separately
  const lessonProgress = await prisma.lessonProgress.findMany({
    where: {
      userId: dbUser.id,
      lessonId: {
        in: course.modules.flatMap((m) => m.lessons.map((l) => l.id)),
      },
    },
    select: {
      lessonId: true,
      isCompleted: true,
    },
  });

  // Filter modules based on enrolled track
  const visibleModules = course.modules.filter((module) => {
    if (module.track === "BOTH") return true;
    return module.track === enrollment.enrolledTrack;
  });

  // Calculate total lessons and completed lessons
  const totalLessons = visibleModules.reduce(
    (acc, m) => acc + m.lessons.length,
    0,
  );

  const completedLessonIds = new Set(
    lessonProgress.filter((lp) => lp.isCompleted).map((lp) => lp.lessonId),
  );

  const completedCount = lessonProgress.filter((lp) => lp.isCompleted).length;

  // Prepare modules data with completion status
  const modulesData = visibleModules.map((module) => ({
    id: module.id,
    title: module.title,
    description: module.description,
    track: module.track,
    lessons: module.lessons.map((lesson) => ({
      id: lesson.id,
      title: lesson.title,
      duration: lesson.duration,
      track: lesson.track,
      isFree: lesson.isFree,
      lessonType: lesson.lessonType as
        | "TEXT"
        | "VIDEO"
        | "INTERACTIVE"
        | "CODING",
      isCompleted: completedLessonIds.has(lesson.id),
    })),
  }));

  // Find the last accessed lesson or first incomplete lesson
  const lastAccessedLesson = modulesData
    .flatMap((m) => m.lessons)
    .find((l) => !l.isCompleted);

  // Fetch assessment attempts to show history
  const finalExam = course.finalExam;
  let assessmentInfo = null;

  if (finalExam) {
    const lastAttempt = await prisma.quizAttempt.findFirst({
      where: {
        userId: dbUser.id,
        quizId: finalExam.id,
      },
      orderBy: {
        completedAt: "desc",
      },
    });

    if (lastAttempt) {
      assessmentInfo = {
        status: lastAttempt.isPassed
          ? ("PASSED" as const)
          : ("FAILED" as const),
        score:
          lastAttempt.totalPoints > 0
            ? Math.round((lastAttempt.score / lastAttempt.totalPoints) * 100)
            : null,
        attemptDate: lastAttempt.completedAt,
        passedScore: finalExam.passingScore,
        hasPassed: lastAttempt.isPassed,
        maxAttempts: finalExam.maxAttempts,
        attemptCount: await prisma.quizAttempt.count({
          where: {
            userId: dbUser.id,
            quizId: finalExam.id,
          },
        }),
      };
    } else {
      assessmentInfo = {
        status: "NOT_STARTED" as const,
        score: null,
        attemptDate: null,
        passedScore: finalExam.passingScore,
        hasPassed: false,
        maxAttempts: finalExam.maxAttempts,
        attemptCount: 0,
      };
    }
  }

  return (
    <LearnPageClient
      course={{
        id: course.id,
        slug: course.slug,
        title: course.title,
        shortDescription: course.shortDescription,
        category: course.category,
      }}
      enrollment={{
        enrolledTrack: enrollment.enrolledTrack as "BASIC" | "ADVANCED",
        progressPercent: enrollment.progressPercent,
      }}
      modules={modulesData}
      stats={{
        totalLessons,
        completedCount,
      }}
      lastAccessedLesson={lastAccessedLesson}
      assessmentInfo={assessmentInfo}
    />
  );
}
