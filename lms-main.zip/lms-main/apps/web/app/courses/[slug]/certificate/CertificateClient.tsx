"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@repo/ui/components/button";
import { Card, CardContent } from "@repo/ui/components/card";
import {
  Download,
  Share2,
  CheckCircle2,
  Award,
  ArrowLeft,
  ExternalLink,
} from "lucide-react";

interface CertificateClientProps {
  studentName: string;
  courseName: string;
  courseSlug: string;
  instructorName: string;
  completionDate: string;
  certificateId: string;
  certificateUrl: string;
}

export function CertificateClient({
  studentName,
  courseName,
  courseSlug,
  instructorName,
  completionDate,
  certificateId,
  certificateUrl,
}: CertificateClientProps) {
  const [copied, setCopied] = useState(false);

  const handleDownload = () => {
    // Create a temporary link and trigger download
    const link = document.createElement("a");
    link.href = certificateUrl;
    link.download = `certificate-${courseName.replace(/\s+/g, "-").toLowerCase()}.pdf`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleShare = async () => {
    const shareUrl = window.location.href;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `${courseName} - Certificate of Completion`,
          text: `I just completed ${courseName}!`,
          url: shareUrl,
        });
      } catch (error) {
        // Fallback to copying link
        copyLink(shareUrl);
      }
    } else {
      copyLink(shareUrl);
    }
  };

  const copyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Back link - OUTSIDE centered container, at left edge */}
      <div className="px-4 sm:px-8 lg:px-16 py-6">
        <Link
          href={`/courses/${courseSlug}/learn`}
          className="inline-flex items-center text-sm text-zinc-600 hover:text-zinc-900"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to course
        </Link>
      </div>

      {/* Centered content container */}
      <div className="px-4 pb-12">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-3 bg-zinc-100 rounded-lg">
                <Award className="h-6 w-6 text-zinc-900" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-zinc-900">
                  Certificate of Completion
                </h1>
                <p className="text-zinc-600">
                  Congratulations on completing the course!
                </p>
              </div>
            </div>
          </div>

          {/* Certificate preview */}
          <Card className="mb-6 overflow-hidden">
            <div className="bg-white p-8 border-b border-zinc-200">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-zinc-100 rounded-full mb-4">
                  <CheckCircle2 className="h-8 w-8 text-zinc-900" />
                </div>
                <h2 className="text-2xl font-bold text-zinc-900 mb-2">
                  {courseName}
                </h2>
                <p className="text-zinc-600 mb-6">
                  Successfully completed by {studentName}
                </p>

                {/* Certificate details */}
                <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
                  <div className="text-center">
                    <p className="text-xs text-zinc-500 mb-1">Completed On</p>
                    <p className="font-semibold text-zinc-900">
                      {completionDate}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-zinc-500 mb-1">Instructor</p>
                    <p className="font-semibold text-zinc-900">
                      {instructorName}
                    </p>
                  </div>
                  <div className="text-center">
                    <p className="text-xs text-zinc-500 mb-1">Certificate ID</p>
                    <p className="font-semibold text-zinc-900 font-mono text-sm">
                      {certificateId}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* PDF Viewer */}
            <CardContent className="p-0">
              <div className="bg-zinc-100 p-4">
                <div className="bg-white rounded-lg overflow-hidden shadow-sm">
                  <iframe
                    src={certificateUrl}
                    className="w-full h-[600px] border-0"
                    title="Certificate PDF"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
            <Button size="lg" onClick={handleDownload}>
              <Download className="mr-2 h-5 w-5" />
              Download Certificate
            </Button>
            <Button variant="secondary" size="lg" onClick={handleShare}>
              <Share2 className="mr-2 h-5 w-5" />
              {copied ? "Link Copied!" : "Share Certificate"}
            </Button>
          </div>

          {/* Info card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-3">
                <ExternalLink className="h-5 w-5 text-zinc-600 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-zinc-900 mb-1">
                    Verification
                  </h3>
                  <p className="text-sm text-zinc-600">
                    This certificate can be verified using the Certificate ID:{" "}
                    <span className="font-mono font-semibold">
                      {certificateId}
                    </span>
                    . Employers and institutions can contact us to verify
                    authenticity.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Back to courses */}
          <div className="mt-8">
            <Link
              href="/courses"
              className="text-zinc-600 hover:text-zinc-900 inline-flex items-center"
            >
              ← Explore more courses
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
