import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import { notFound, redirect } from "next/navigation";
import { CertificateClient } from "./CertificateClient";
import { generateCertificate } from "../../../lib/generate-certificate";

interface PageProps {
  params: Promise<{ slug: string }>;
}

export default async function CertificatePage({ params }: PageProps) {
  const { userId } = await auth();

  if (!userId) {
    redirect("/sign-in");
  }

  const { slug } = await params;

  // Get user from database
  const user = await prisma.user.findUnique({
    where: { clerkId: userId },
  });

  if (!user) {
    redirect("/sign-in");
  }

  // Get course
  const course = await prisma.course.findUnique({
    where: { slug },
    include: {
      instructor: true,
    },
  });

  if (!course) {
    notFound();
  }

  // Get user progress with certificate
  let progress = await prisma.userCourseProgress.findUnique({
    where: {
      userId_courseId: {
        userId: user.id,
        courseId: course.id,
      },
    },
  });

  // If no certificate yet, check if user has a passed attempt and generate on-the-fly
  if (!progress?.certificateUrl) {
    const passedAttempt = await prisma.assessmentAttempt.findFirst({
      where: {
        userId: user.id,
        courseId: course.id,
        status: "PASSED",
      },
      orderBy: { submittedAt: "desc" },
    });

    if (passedAttempt) {
      try {
        await generateCertificate(user.id, course.id, passedAttempt.id);
        // Re-fetch progress after generation
        progress = await prisma.userCourseProgress.findUnique({
          where: {
            userId_courseId: {
              userId: user.id,
              courseId: course.id,
            },
          },
        });
      } catch (error) {
        console.error("On-the-fly certificate generation failed:", error);
      }
    }
  }

  if (!progress || !progress.certificateUrl || !progress.isCompleted) {
    redirect(`/courses/${slug}/learn`);
  }

  // Get the most recent passed assessment attempt for certificate ID
  let certificateId = "N/A";
  const passedAttempt = await prisma.assessmentAttempt.findFirst({
    where: {
      userId: user.id,
      courseId: course.id,
      status: "PASSED",
    },
    orderBy: { submittedAt: "desc" },
  });

  if (passedAttempt) {
    certificateId = `CERT-${passedAttempt.submittedAt?.getTime() || Date.now()}-${user.id.substring(0, 8).toUpperCase()}`;
  }

  return (
    <CertificateClient
      studentName={user.name || user.email}
      courseName={course.title}
      courseSlug={course.slug}
      instructorName={course.instructor.name || "Course Instructor"}
      completionDate={
        progress.completedAt?.toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
        }) || "N/A"
      }
      certificateId={certificateId}
      certificateUrl={progress.certificateUrl}
    />
  );
}
