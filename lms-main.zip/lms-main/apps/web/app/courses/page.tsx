"use client";

import { useState, useEffect, useCallback } from "react";
import { Search as SearchIcon } from "lucide-react";
import { CourseCard } from "./components/CourseCard";
import { FilterBar } from "./components/FilterBar";
import { CourseGridSkeleton } from "./components/CourseCardSkeleton";
import { Sidebar, SidebarCategory } from "../components/Sidebar";
import { Navbar } from "../components/Navbar";
import { getCategoryConfig } from "../lib/category-config";

// Course type from API
interface Course {
  id: string;
  slug: string;
  title: string;
  shortDescription: string | null;
  imageUrl: string | null;
  level: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
  duration: number | null;
  price: number;
  category: string | null;
  _count?: {
    modules: number;
    userProgress: number;
    lessons?: number;
  };
}

function EmptyState({
  search,
  onReset,
}: {
  search: string;
  onReset: () => void;
}) {
  return (
    <div className="text-center py-20">
      <div className="mx-auto w-14 h-14 rounded-full bg-bg-tertiary flex items-center justify-center mb-5">
        <SearchIcon className="h-6 w-6 text-text-secondary" />
      </div>
      <h3 className="text-base font-medium text-text-primary mb-2">
        No courses found
      </h3>
      <p className="text-sm text-text-secondary max-w-sm mx-auto mb-5">
        {search
          ? `No results for "${search}". Try a different search term.`
          : "No courses match your filters."}
      </p>
      <button
        onClick={onReset}
        className="text-sm font-medium text-primary hover:text-primary/80 underline underline-offset-4 transition-colors"
      >
        Clear filters
      </button>
    </div>
  );
}

function CourseGrid({ courses }: { courses: Course[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
      {courses.map((course) => {
        // Calculate total lesson count from modules
        const lessonCount = course._count?.lessons || 0;

        return (
          <CourseCard
            key={course.id}
            id={course.id}
            slug={course.slug}
            title={course.title}
            shortDescription={course.shortDescription}
            imageUrl={course.imageUrl}
            level={course.level}
            duration={course.duration}
            price={course.price}
            category={course.category}
            moduleCount={course._count?.modules}
            enrolledCount={course._count?.userProgress}
            lessonCount={lessonCount}
          />
        );
      })}
    </div>
  );
}

export default function CoursesPage() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("all");
  const [level, setLevel] = useState("all");
  const [sort, setSort] = useState("popular");
  const [categories, setCategories] = useState<SidebarCategory[]>([]);

  // Fetch unique categories from courses
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch("/api/courses");
        const data = await response.json();

        if (data.success && data.data) {
          const uniqueCategories = Array.from(
            new Set(
              data.data
                .map((c: Course) => c.category)
                .filter((cat: string | null): cat is string => cat !== null),
            ),
          ) as string[];

          const categoryList: SidebarCategory[] = uniqueCategories.map(
            (cat: string) => {
              const config = getCategoryConfig(cat);
              return {
                name: cat,
                slug: cat.toLowerCase().replace(/\s+/g, "-"),
                icon: config.icon,
                color: config.color,
                bgColor: config.bgColor,
              };
            },
          );

          setCategories(categoryList);
        }
      } catch (error) {
        console.error("Failed to fetch categories:", error);
      }
    };

    fetchCategories();
  }, []);

  const fetchCourses = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (search) params.set("search", search);
      if (category !== "all") {
        // Find the actual category name from slug
        const categoryObj = categories.find((c) => c.slug === category);
        if (categoryObj) {
          params.set("category", categoryObj.name);
        }
      }
      if (level !== "all") params.set("level", level);
      if (sort) params.set("sort", sort);

      const response = await fetch(`/api/courses?${params.toString()}`);
      const data = await response.json();

      if (data.success) {
        setCourses(data.data || []);
      }
    } catch (error) {
      console.error("Failed to fetch courses:", error);
    } finally {
      setLoading(false);
    }
  }, [search, category, level, sort, categories]);

  useEffect(() => {
    if (categories.length > 0 || category === "all") {
      fetchCourses();
    }
  }, [fetchCourses, categories, category]);

  const handleReset = () => {
    setSearch("");
    setCategory("all");
    setLevel("all");
    setSort("popular");
  };

  const handleCategoryChange = (newCategory: string) => {
    setCategory(newCategory);
  };

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Navbar */}
      <Navbar />

      {/* Sidebar */}
      <Sidebar
        categories={categories}
        activeCategory={category}
        onCategoryChange={handleCategoryChange}
      />

      {/* Main Content */}
      <div className="lg:pl-64 transition-all duration-300">
        {/* Header Section - Clean & Minimal */}
        <section className="border-b border-border">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
            <div className="max-w-xl">
              {/* Title */}
              <h1 className="text-2xl sm:text-3xl font-semibold tracking-tight text-text-primary">
                Courses
              </h1>

              {/* Subtitle */}
              <p className="mt-2 text-base text-text-secondary">
                Find the right course for your learning goals.
              </p>
            </div>
          </div>
        </section>

        {/* Filter Bar */}
        <FilterBar
          category={category}
          level={level}
          sort={sort}
          onCategoryChange={setCategory}
          onLevelChange={setLevel}
          onSortChange={setSort}
          onReset={handleReset}
        />

        {/* Course Grid */}
        <section className="py-8 sm:py-10">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            {/* Results count */}
            {!loading && courses.length > 0 && (
              <p className="text-sm text-text-secondary mb-6">
                {courses.length} {courses.length === 1 ? "course" : "courses"}
              </p>
            )}

            {/* Loading state */}
            {loading && <CourseGridSkeleton count={6} />}

            {/* Empty state */}
            {!loading && courses.length === 0 && (
              <EmptyState search={search} onReset={handleReset} />
            )}

            {/* Course grid */}
            {!loading && courses.length > 0 && <CourseGrid courses={courses} />}
          </div>
        </section>
      </div>
    </div>
  );
}
