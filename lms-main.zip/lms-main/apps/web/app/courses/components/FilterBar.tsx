"use client";

import { useEffect, useState } from "react";
import { Button } from "@repo/ui/components/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@repo/ui/components/select";
import { Skeleton } from "@repo/ui/components/skeleton";
import { SlidersHorizontal } from "lucide-react";

const categories = [
  { value: "all", label: "All Categories" },
  { value: "programming", label: "Programming" },
  { value: "design", label: "Design" },
  { value: "business", label: "Business" },
  { value: "data-science", label: "Data Science" },
  { value: "marketing", label: "Marketing" },
];

const levels = [
  { value: "all", label: "All Levels" },
  { value: "BEGINNER", label: "Beginner" },
  { value: "INTERMEDIATE", label: "Intermediate" },
  { value: "ADVANCED", label: "Advanced" },
];

const sortOptions = [
  { value: "popular", label: "Most Popular" },
  { value: "newest", label: "Newest" },
  { value: "price-low", label: "Price: Low to High" },
  { value: "price-high", label: "Price: High to Low" },
];

interface FilterBarProps {
  category: string;
  level: string;
  sort: string;
  onCategoryChange: (value: string) => void;
  onLevelChange: (value: string) => void;
  onSortChange: (value: string) => void;
  onReset: () => void;
}

export function FilterBar({
  category,
  level,
  sort,
  onCategoryChange,
  onLevelChange,
  onSortChange,
  onReset,
}: FilterBarProps) {
  const [mounted, setMounted] = useState(false);
  const hasFilters = category !== "all" || level !== "all";

  // Prevent hydration mismatch from Radix UI's random ID generation
  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <div className="sticky top-16 z-40 bg-bg-primary/80 backdrop-blur-md border-b border-border">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-wrap items-center gap-3">
          {/* Filter icon */}
          <div className="flex items-center gap-2 text-sm font-medium text-text-secondary">
            <SlidersHorizontal className="h-4 w-4" />
            <span className="hidden sm:inline">Filters:</span>
          </div>

          {/* Category filter */}
          {mounted ? (
            <Select value={category} onValueChange={onCategoryChange}>
              <SelectTrigger className="w-[160px]">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map((cat) => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <Skeleton className="h-10 w-[160px] rounded-lg" />
          )}

          {/* Level filter */}
          {mounted ? (
            <Select value={level} onValueChange={onLevelChange}>
              <SelectTrigger className="w-[140px]">
                <SelectValue placeholder="Level" />
              </SelectTrigger>
              <SelectContent>
                {levels.map((lvl) => (
                  <SelectItem key={lvl.value} value={lvl.value}>
                    {lvl.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          ) : (
            <Skeleton className="h-10 w-[140px] rounded-lg" />
          )}

          {/* Clear filters */}
          {hasFilters && (
            <Button variant="ghost" size="sm" onClick={onReset}>
              Clear filters
            </Button>
          )}

          {/* Spacer */}
          <div className="flex-1" />

          {/* Sort */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-text-secondary hidden sm:inline">
              Sort by:
            </span>
            {mounted ? (
              <Select value={sort} onValueChange={onSortChange}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  {sortOptions.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Skeleton className="h-10 w-[160px] rounded-lg" />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
