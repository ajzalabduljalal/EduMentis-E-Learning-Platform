"use client";

import Image from "next/image";
import Link from "next/link";
import { Heart, Folder, Layers } from "lucide-react";
import { getCategoryConfig } from "../../lib/category-config";

interface CourseCardProps {
  id: string;
  slug: string;
  title: string;
  shortDescription: string | null;
  imageUrl: string | null;
  level: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
  duration: number | null;
  price: number;
  category: string | null;
  moduleCount?: number;
  enrolledCount?: number;
  lessonCount?: number;
  // If user is enrolled
  isEnrolled?: boolean;
  progress?: number;
}

// Placeholder images for courses without images
const placeholderImages = [
  "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&h=450&fit=crop",
  "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=450&fit=crop",
  "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=450&fit=crop",
  "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=800&h=450&fit=crop",
];

export function CourseCard({
  id,
  slug,
  title,
  shortDescription,
  imageUrl,
  category,
  moduleCount = 0,
  enrolledCount = 0,
  lessonCount = 0,
  isEnrolled = false,
  progress = 0,
}: CourseCardProps) {
  // Use a consistent placeholder based on the id
  const placeholderIndex = id ? id.charCodeAt(0) % placeholderImages.length : 0;
  const placeholderImage = placeholderImages[placeholderIndex] as string;

  // Validate and use imageUrl only if it's a valid absolute URL
  const isValidUrl = (url: string | null | undefined): boolean => {
    if (!url || url.trim() === "") return false;
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  };
  const displayImage = isValidUrl(imageUrl) ? imageUrl! : placeholderImage;

  // Get category icon config
  const categoryConfig = getCategoryConfig(category);
  const CategoryIcon = categoryConfig.icon;

  return (
    <Link href={`/courses/${slug}`} className="block group">
      <div className="bg-bg-primary border border-border rounded-lg p-6 hover:-translate-y-1 transition-all duration-200 h-full flex flex-col">
        {/* Category Icon */}
        <div className="mb-4">
          <div
            className={`inline-flex h-12 w-12 items-center justify-center rounded-lg ${categoryConfig.bgColor} ${categoryConfig.color}`}
          >
            <CategoryIcon className="h-6 w-6" />
          </div>
        </div>

        {/* Title */}
        <h3 className="text-lg font-semibold text-text-primary mb-2 line-clamp-2 group-hover:text-primary transition-colors">
          {title}
        </h3>

        {/* Description */}
        <p className="text-sm text-text-secondary line-clamp-2 mb-6 flex-1">
          {shortDescription || "No description available"}
        </p>

        {/* Metadata Row */}
        <div className="flex items-center gap-4 text-sm text-text-secondary">
          {/* Likes/Enrollment count */}
          <div className="flex items-center gap-1.5">
            <Heart className="h-4 w-4" />
            <span>{enrolledCount}</span>
          </div>

          {/* Modules count */}
          {moduleCount > 0 && (
            <div className="flex items-center gap-1.5">
              <Folder className="h-4 w-4" />
              <span>{moduleCount}</span>
            </div>
          )}

          {/* Lessons count */}
          {lessonCount > 0 && (
            <div className="flex items-center gap-1.5">
              <Layers className="h-4 w-4" />
              <span>{lessonCount}</span>
            </div>
          )}

          {/* Progress indicator (if enrolled) */}
          {isEnrolled && (
            <>
              <div className="flex items-center gap-1.5 ml-auto">
                <div className="h-2 w-2 rounded-full bg-green-500"></div>
                <span className="font-medium text-text-primary">
                  {Math.round(progress)}%
                </span>
              </div>
            </>
          )}
        </div>
      </div>
    </Link>
  );
}
