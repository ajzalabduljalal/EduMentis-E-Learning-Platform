import { NextRequest, NextResponse } from "next/server";
import { prisma, CourseStatus, Prisma } from "@repo/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") || "";
    const category = searchParams.get("category");
    const level = searchParams.get("level");
    const sort = searchParams.get("sort") || "popular";
    const page = parseInt(searchParams.get("page") || "1");
    const pageSize = parseInt(searchParams.get("pageSize") || "12");

    // Build where clause
    const where: Prisma.CourseWhereInput = {
      status: CourseStatus.PUBLISHED,
    };

    // Search filter
    if (search) {
      where.OR = [
        { title: { contains: search, mode: "insensitive" } },
        { description: { contains: search, mode: "insensitive" } },
        { shortDescription: { contains: search, mode: "insensitive" } },
      ];
    }

    // Category filter
    if (category && category !== "all") {
      where.category = { contains: category, mode: "insensitive" };
    }

    // Level filter
    if (level && level !== "all") {
      where.level = level as Prisma.EnumCourseLevelFilter;
    }

    // Build orderBy based on sort option
    let orderBy: Prisma.CourseOrderByWithRelationInput = { createdAt: "desc" };
    switch (sort) {
      case "newest":
        orderBy = { createdAt: "desc" };
        break;
      case "popular":
        orderBy = { userProgress: { _count: "desc" } };
        break;
      case "price-low":
        orderBy = { price: "asc" };
        break;
      case "price-high":
        orderBy = { price: "desc" };
        break;
      case "rating":
        // For now, use enrollment count as a proxy for rating
        orderBy = { userProgress: { _count: "desc" } };
        break;
      default:
        orderBy = { createdAt: "desc" };
    }

    // Fetch courses with counts
    const courses = await prisma.course.findMany({
      where,
      orderBy,
      skip: (page - 1) * pageSize,
      take: pageSize,
      select: {
        id: true,
        slug: true,
        title: true,
        shortDescription: true,
        imageUrl: true,
        level: true,
        duration: true,
        price: true,
        category: true,
        createdAt: true,
        _count: {
          select: {
            modules: true,
            userProgress: true,
          },
        },
      },
    });

    // Get total count for pagination
    const total = await prisma.course.count({ where });

    return NextResponse.json({
      success: true,
      data: courses,
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    });
  } catch (error) {
    console.error("Error fetching courses:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch courses" },
      { status: 500 }
    );
  }
}
