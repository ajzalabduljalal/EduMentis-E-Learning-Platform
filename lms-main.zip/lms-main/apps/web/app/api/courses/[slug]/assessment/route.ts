import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma, AssessmentStatus } from "@repo/db";
import { getOrCreateUser } from "@repo/auth";

/**
 * GET /api/courses/[slug]/assessment
 * Get final assessment for a course (only if 100% progress)
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get or create user - this ensures the user exists in our database
    const user = await getOrCreateUser();

    if (!user) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get course with final exam
    const course = await prisma.course.findUnique({
      where: { slug },
      include: {
        finalExam: {
          include: {
            questions: {
              orderBy: { orderIndex: "asc" },
              select: {
                id: true,
                question: true,
                questionType: true,
                options: true,
                points: true,
                starterCode: true,
                maxLength: true,
              },
            },
          },
        },
      },
    });

    if (!course || !course.finalExam) {
      return NextResponse.json(
        { success: false, error: "Final assessment not found" },
        { status: 404 },
      );
    }

    // Check if user has completed the course (100% progress)
    const progress = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: user.id,
          courseId: course.id,
        },
      },
    });

    if (!progress) {
      return NextResponse.json(
        { success: false, error: "You must enroll in this course first" },
        { status: 403 },
      );
    }

    if (progress.progressPercent < 100) {
      return NextResponse.json(
        {
          success: false,
          error:
            "You must complete all lessons before taking the final assessment",
        },
        { status: 403 },
      );
    }

    // Check previous attempts
    const attemptCount = await prisma.quizAttempt.count({
      where: {
        userId: user.id,
        quizId: course.finalExam.id,
      },
    });

    if (attemptCount >= course.finalExam.maxAttempts) {
      return NextResponse.json(
        {
          success: false,
          error: "You have reached the maximum number of attempts",
        },
        { status: 403 },
      );
    }

    // Parse options for MCQ questions
    const questionsWithParsedOptions = course.finalExam.questions.map((q) => {
      let parsedOptions: { id: string; text: string }[] = [];
      if (
        q.options &&
        typeof q.options === "object" &&
        !Array.isArray(q.options)
      ) {
        parsedOptions = Object.entries(q.options as Record<string, string>).map(
          ([key, value]) => ({
            id: key,
            text: value,
          }),
        );
      }

      return {
        id: q.id,
        questionText: q.question,
        questionType: q.questionType,
        options: parsedOptions,
        points: q.points,
        starterCode: q.starterCode,
        maxLength: q.maxLength,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        quiz: {
          id: course.finalExam.id,
          title: course.finalExam.title,
          description: course.finalExam.description,
          timeLimit: course.finalExam.timeLimit,
          passingScore: course.finalExam.passingScore,
          maxAttempts: course.finalExam.maxAttempts,
          attemptCount,
        },
        course: {
          id: course.id,
          title: course.title,
          slug: course.slug,
        },
        questions: questionsWithParsedOptions,
      },
    });
  } catch (error) {
    console.error("Error fetching assessment:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch assessment" },
      { status: 500 },
    );
  }
}

/**
 * POST /api/courses/[slug]/assessment
 * Submit final assessment answers
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get or create user - this ensures the user exists in our database
    const user = await getOrCreateUser();

    if (!user) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { answers } = body; // Array of { questionId, answer, questionType }

    // Get course with final exam and all questions (including correct answers)
    const course = await prisma.course.findUnique({
      where: { slug },
      include: {
        finalExam: {
          include: {
            questions: {
              orderBy: { orderIndex: "asc" },
            },
          },
        },
      },
    });

    if (!course || !course.finalExam) {
      return NextResponse.json(
        { success: false, error: "Final assessment not found" },
        { status: 404 },
      );
    }

    // Check if user has 100% progress
    const progress = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: user.id,
          courseId: course.id,
        },
      },
    });

    if (!progress || progress.progressPercent < 100) {
      return NextResponse.json(
        { success: false, error: "You must complete all lessons first" },
        { status: 403 },
      );
    }

    // Check max attempts
    const attemptCount = await prisma.quizAttempt.count({
      where: {
        userId: user.id,
        quizId: course.finalExam.id,
      },
    });

    if (attemptCount >= course.finalExam.maxAttempts) {
      return NextResponse.json(
        { success: false, error: "Maximum attempts reached" },
        { status: 403 },
      );
    }

    // Grade the assessment
    let totalPoints = 0;
    let earnedPoints = 0;
    const gradedAnswers = [];
    let needsManualReview = false;

    for (const question of course.finalExam.questions) {
      totalPoints += question.points;

      const userAnswer = answers.find(
        (a: { questionId: string; answer: string; questionType: string }) =>
          a.questionId === question.id,
      );

      if (!userAnswer) {
        gradedAnswers.push({
          questionId: question.id,
          answer: "",
          isCorrect: false,
          pointsEarned: 0,
        });
        continue;
      }

      // Auto-grade MCQ
      if (question.questionType === "MULTIPLE_CHOICE") {
        const isCorrect = userAnswer.answer === question.correctAnswer;
        const points = isCorrect ? question.points : 0;
        earnedPoints += points;

        gradedAnswers.push({
          questionId: question.id,
          answer: userAnswer.answer,
          isCorrect,
          pointsEarned: points,
        });
      } else {
        // TEXT, CODE, FILE_UPLOAD need manual review
        needsManualReview = true;
        gradedAnswers.push({
          questionId: question.id,
          answer: JSON.stringify(userAnswer.answer),
          isCorrect: null, // Will be graded manually
          pointsEarned: 0,
        });
      }
    }

    // Calculate score percentage (only from auto-graded questions for now)
    const scorePercentage =
      totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
    const isPassed =
      scorePercentage >= course.finalExam.passingScore && !needsManualReview;

    // Create quiz attempt
    const attempt = await prisma.quizAttempt.create({
      data: {
        userId: user.id,
        quizId: course.finalExam.id,
        score: earnedPoints,
        totalPoints,
        isPassed,
        completedAt: new Date(),
        answers: {
          create: gradedAnswers,
        },
      },
      include: {
        answers: {
          include: {
            question: {
              select: {
                id: true,
                question: true,
                questionType: true,
                correctAnswer: true,
                explanation: true,
              },
            },
          },
        },
      },
    });

    // Create assessment attempt for manual review if needed
    if (needsManualReview) {
      await prisma.assessmentAttempt.create({
        data: {
          userId: user.id,
          courseId: course.id,
          status: AssessmentStatus.GRADING,
          score: null,
        },
      });
    }

    // If passed and no manual review needed, mark course as completed
    if (isPassed && !needsManualReview) {
      await prisma.userCourseProgress.update({
        where: {
          userId_courseId: {
            userId: user.id,
            courseId: course.id,
          },
        },
        data: {
          isCompleted: true,
          completedAt: new Date(),
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        attemptId: attempt.id,
        score: earnedPoints,
        totalPoints,
        scorePercentage,
        isPassed,
        needsManualReview,
        passingScore: course.finalExam.passingScore,
        answers: attempt.answers,
      },
    });
  } catch (error) {
    console.error("Error submitting assessment:", error);
    return NextResponse.json(
      { success: false, error: "Failed to submit assessment" },
      { status: 500 },
    );
  }
}
