import { NextRequest, NextResponse } from "next/server";
import { prisma, CourseStatus } from "@repo/db";
import { auth } from "@clerk/nextjs/server";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params;
    const { userId } = await auth();

    // Fetch the course with full details
    const course = await prisma.course.findFirst({
      where: {
        slug,
        status: CourseStatus.PUBLISHED,
      },
      include: {
        instructor: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        modules: {
          orderBy: { orderIndex: "asc" },
          include: {
            lessons: {
              orderBy: { orderIndex: "asc" },
              select: {
                id: true,
                title: true,
                duration: true,
                track: true,
                isFree: true,
                lessonType: true,
              },
            },
          },
        },
        entryQuiz: {
          select: {
            id: true,
            title: true,
            description: true,
            passingScore: true,
            timeLimit: true,
            _count: {
              select: { questions: true },
            },
          },
        },
        _count: {
          select: {
            modules: true,
            userProgress: true,
          },
        },
      },
    });

    if (!course) {
      return NextResponse.json(
        { success: false, error: "Course not found" },
        { status: 404 }
      );
    }

    // Check if user is enrolled (if authenticated)
    let enrollment = null;
    if (userId) {
      const user = await prisma.user.findUnique({
        where: { clerkId: userId },
      });

      if (user) {
        enrollment = await prisma.userCourseProgress.findUnique({
          where: {
            userId_courseId: {
              userId: user.id,
              courseId: course.id,
            },
          },
          select: {
            enrolledTrack: true,
            progressPercent: true,
            isCompleted: true,
            updatedAt: true,
          },
        });
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        ...course,
        enrollment,
      },
    });
  } catch (error) {
    console.error("Error fetching course:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch course" },
      { status: 500 }
    );
  }
}
