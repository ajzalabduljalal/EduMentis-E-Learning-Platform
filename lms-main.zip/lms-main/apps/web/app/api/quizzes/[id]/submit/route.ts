import { NextRequest, NextResponse } from "next/server";
import { prisma, Track, QuizType } from "@repo/db";
import { auth } from "@clerk/nextjs/server";
import { getOrCreateUser } from "@repo/auth";

interface Answer {
  questionId: string;
  selectedAnswers: string[];
}

interface QuestionResult {
  questionId: string;
  selectedAnswers: string[];
  isCorrect: boolean;
  pointsEarned: number;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id: quizId } = await params;
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get or create user - this ensures the user exists in our database
    const user = await getOrCreateUser();

    if (!user) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { answers } = body as {
      answers: Answer[];
      timeSpent?: number;
    };

    // Fetch quiz with questions and correct answers
    const quiz = await prisma.quiz.findUnique({
      where: { id: quizId },
      include: {
        course: true,
        questions: {
          select: {
            id: true,
            question: true,
            correctAnswer: true,
            points: true,
          },
        },
      },
    });

    if (!quiz) {
      return NextResponse.json(
        { success: false, error: "Quiz not found" },
        { status: 404 },
      );
    }

    // Calculate score
    let earnedPoints = 0;
    let totalPoints = 0;

    const questionResults = quiz.questions.map((question) => {
      totalPoints += question.points;
      const userAnswer = answers.find((a) => a.questionId === question.id);
      const selectedAnswers = userAnswer?.selectedAnswers || [];

      // Parse correctAnswer - could be a string or an array stored as JSON
      let correctAnswers: string[] = [];
      if (question.correctAnswer) {
        try {
          const parsed = JSON.parse(question.correctAnswer);
          correctAnswers = Array.isArray(parsed) ? parsed : [parsed];
        } catch {
          correctAnswers = [question.correctAnswer];
        }
      }

      // Check if answer is correct
      const isCorrect =
        selectedAnswers.length === correctAnswers.length &&
        selectedAnswers.every((ans) => correctAnswers.includes(ans));

      if (isCorrect) {
        earnedPoints += question.points;
      }

      return {
        questionId: question.id,
        selectedAnswers,
        isCorrect,
        pointsEarned: isCorrect ? question.points : 0,
      };
    });

    const scorePercent =
      totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
    const isPassed = scorePercent >= (quiz.passingScore || 70);

    // Determine track based on score (for entry quizzes)
    let assignedTrack: Track = Track.BASIC;
    if (quiz.quizType === QuizType.ENTRY_QUIZ) {
      // If score >= passing score, assign to ADVANCED track
      assignedTrack = isPassed ? Track.ADVANCED : Track.BASIC;
    }

    // Create quiz attempt record
    const attempt = await prisma.quizAttempt.create({
      data: {
        userId: user.id,
        quizId,
        score: scorePercent,
        totalPoints,
        isPassed,
        trackAssigned:
          quiz.quizType === QuizType.ENTRY_QUIZ ? assignedTrack : null,
        completedAt: new Date(),
        answers: {
          create: questionResults.map((result: QuestionResult) => ({
            questionId: result.questionId,
            answer: JSON.stringify(result.selectedAnswers),
            isCorrect: result.isCorrect,
            pointsEarned: result.pointsEarned,
          })),
        },
      },
    });

    // If entry quiz, create enrollment with the assigned track
    if (quiz.quizType === QuizType.ENTRY_QUIZ && quiz.courseId) {
      // Check if already enrolled
      const existingEnrollment = await prisma.userCourseProgress.findUnique({
        where: {
          userId_courseId: {
            userId: user.id,
            courseId: quiz.courseId,
          },
        },
      });

      if (!existingEnrollment) {
        await prisma.userCourseProgress.create({
          data: {
            userId: user.id,
            courseId: quiz.courseId,
            enrolledTrack: assignedTrack,
            progressPercent: 0,
          },
        });
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        attemptId: attempt.id,
        score: scorePercent,
        earnedPoints,
        totalPoints,
        isPassed,
        assignedTrack: assignedTrack as "BASIC" | "ADVANCED",
        questionResults: questionResults.map((r: QuestionResult) => ({
          questionId: r.questionId,
          isCorrect: r.isCorrect,
        })),
      },
    });
  } catch (error) {
    console.error("Error submitting quiz:", error);
    return NextResponse.json(
      { success: false, error: "Failed to submit quiz" },
      { status: 500 },
    );
  }
}
