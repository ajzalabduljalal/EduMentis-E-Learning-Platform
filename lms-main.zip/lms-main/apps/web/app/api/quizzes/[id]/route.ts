import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@repo/db";
import { auth } from "@clerk/nextjs/server";

interface QuizQuestion {
  id: string;
  question: string;
  questionType: string;
  options: unknown;
  points: number;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Fetch quiz with questions (but not correct answers)
    const quiz = await prisma.quiz.findUnique({
      where: { id },
      include: {
        course: {
          select: {
            id: true,
            title: true,
            slug: true,
          },
        },
        questions: {
          orderBy: { orderIndex: "asc" },
          select: {
            id: true,
            question: true,
            questionType: true,
            options: true, // JSON field with answer options
            points: true,
            // Note: NOT including correctAnswer
          },
        },
      },
    });

    if (!quiz) {
      return NextResponse.json(
        { success: false, error: "Quiz not found" },
        { status: 404 },
      );
    }

    // Parse options for each question
    const questionsWithParsedOptions = quiz.questions.map((q: QuizQuestion) => {
      // Convert options from { "A": "text1", "B": "text2" } to [{ id: "A", text: "text1" }, ...]
      let parsedOptions: { id: string; text: string }[] = [];
      if (
        q.options &&
        typeof q.options === "object" &&
        !Array.isArray(q.options)
      ) {
        parsedOptions = Object.entries(q.options as Record<string, string>).map(
          ([key, value]) => ({
            id: key,
            text: value,
          }),
        );
      }

      return {
        id: q.id,
        questionText: q.question,
        questionType: q.questionType,
        options: parsedOptions,
        points: q.points,
      };
    });

    return NextResponse.json({
      success: true,
      data: {
        ...quiz,
        questions: questionsWithParsedOptions,
      },
    });
  } catch (error) {
    console.error("Error fetching quiz:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch quiz" },
      { status: 500 },
    );
  }
}
