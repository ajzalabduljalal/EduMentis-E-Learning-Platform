import { NextRequest, NextResponse } from "next/server";
import { prisma, QuestionType, AssessmentStatus } from "@repo/db";
import { auth } from "@clerk/nextjs/server";
import { getOrCreateUser } from "@repo/auth";
import { generateCertificate } from "../../../../lib/generate-certificate";

interface Answer {
  questionId: string;
  answer: string | string[];
  questionType: QuestionType;
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ courseId: string }> },
) {
  try {
    const { courseId } = await params;
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get or create user - this ensures the user exists in our database
    const user = await getOrCreateUser();

    if (!user) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { answers } = body as {
      answers: Answer[];
      timeSpent?: number;
    };

    // Get course with final exam
    const course = await prisma.course.findUnique({
      where: { id: courseId },
      include: {
        finalExam: {
          include: {
            questions: true,
          },
        },
      },
    });

    if (!course || !course.finalExam) {
      return NextResponse.json(
        { success: false, error: "Course or final exam not found" },
        { status: 404 },
      );
    }

    // Check if user has completed the course
    const progress = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: user.id,
          courseId: course.id,
        },
      },
    });

    if (!progress || progress.progressPercent < 100) {
      return NextResponse.json(
        { success: false, error: "Course not completed" },
        { status: 403 },
      );
    }

    // Check remaining attempts
    const attemptCount = await prisma.assessmentAttempt.count({
      where: {
        userId: user.id,
        courseId: course.id,
      },
    });

    if (attemptCount >= course.finalExam.maxAttempts) {
      return NextResponse.json(
        { success: false, error: "No attempts remaining" },
        { status: 403 },
      );
    }

    // Calculate score for MCQ questions only
    let mcqScore = 0;
    let mcqTotalPoints = 0;
    let needsManualReview = false;

    const answerResults = course.finalExam.questions.map((question) => {
      const userAnswer = answers.find((a) => a.questionId === question.id);
      const answer = userAnswer?.answer || "";

      let isCorrect: boolean | null = null;
      let pointsEarned = 0;

      if (question.questionType === QuestionType.MULTIPLE_CHOICE) {
        mcqTotalPoints += question.points;

        // Parse correct answer
        let correctAnswers: string[] = [];
        if (question.correctAnswer) {
          try {
            const parsed = JSON.parse(question.correctAnswer);
            correctAnswers = Array.isArray(parsed) ? parsed : [parsed];
          } catch {
            correctAnswers = [question.correctAnswer];
          }
        }

        // Check if answer is correct
        const selectedAnswers = Array.isArray(answer) ? answer : [answer];
        isCorrect =
          selectedAnswers.length === correctAnswers.length &&
          selectedAnswers.every((ans) => correctAnswers.includes(ans));

        if (isCorrect) {
          pointsEarned = question.points;
          mcqScore += question.points;
        }
      } else {
        // Text, code, or file upload - needs manual review
        needsManualReview = true;
        isCorrect = null; // Will be set during manual review
      }

      return {
        questionId: question.id,
        answer: typeof answer === "string" ? answer : JSON.stringify(answer),
        isCorrect,
        pointsEarned,
      };
    });

    // Calculate partial score (MCQ only)
    const mcqPercentage =
      mcqTotalPoints > 0 ? Math.round((mcqScore / mcqTotalPoints) * 100) : 0;

    // Determine status
    const status = needsManualReview
      ? AssessmentStatus.GRADING
      : mcqPercentage >= course.finalExam.passingScore
        ? AssessmentStatus.PASSED
        : AssessmentStatus.FAILED;

    // Create assessment attempt
    const attempt = await prisma.assessmentAttempt.create({
      data: {
        userId: user.id,
        courseId: course.id,
        status,
        score: needsManualReview ? null : mcqPercentage,
        submittedAt: new Date(),
      },
    });

    // Store answers in QuizAttempt format for compatibility
    await prisma.quizAttempt.create({
      data: {
        userId: user.id,
        quizId: course.finalExam.id,
        score: mcqPercentage,
        totalPoints: mcqTotalPoints,
        isPassed: status === AssessmentStatus.PASSED,
        completedAt: new Date(),
        answers: {
          create: answerResults.map((result) => ({
            questionId: result.questionId,
            answer: result.answer,
            isCorrect: result.isCorrect,
            pointsEarned: result.pointsEarned,
          })),
        },
      },
    });

    // If passed (and no manual review needed), generate certificate directly
    if (status === AssessmentStatus.PASSED) {
      try {
        await generateCertificate(user.id, course.id, attempt.id);
      } catch (error) {
        console.error("Certificate generation error:", error);
      }
    }

    return NextResponse.json({
      success: true,
      data: {
        attemptId: attempt.id,
        status,
        mcqScore,
        mcqTotalPoints,
        mcqPercentage,
        needsManualReview,
      },
    });
  } catch (error) {
    console.error("Error submitting assessment:", error);
    return NextResponse.json(
      { success: false, error: "Failed to submit assessment" },
      { status: 500 },
    );
  }
}
