import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";

/**
 * POST /api/lessons/[lessonId]/quiz/submit
 * Submit quiz attempt for a lesson
 */
export async function POST(
  request: NextRequest,
  context: { params: Promise<{ lessonId: string }> },
): Promise<NextResponse> {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const { lessonId } = await context.params;
    const body = await request.json();
    const { answers } = body as {
      answers: Record<string, string>; // questionId -> answer
    };

    // Find the user
    const user = await prisma.user.findUnique({
      where: { clerkId },
    });

    if (!user) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 },
      );
    }

    // Get lesson with quiz and module
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      select: {
        id: true,
        moduleId: true,
        isFree: true,
        module: {
          select: {
            courseId: true,
          },
        },
        quiz: {
          include: {
            questions: {
              orderBy: { orderIndex: "asc" },
            },
          },
        },
      },
    });

    if (!lesson) {
      return NextResponse.json(
        { success: false, error: "Lesson not found" },
        { status: 404 },
      );
    }

    if (!lesson.quiz) {
      return NextResponse.json(
        { success: false, error: "Quiz not found for this lesson" },
        { status: 404 },
      );
    }

    // Check enrollment
    const enrollment = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: user.id,
          courseId: lesson.module.courseId,
        },
      },
    });

    if (!enrollment && !lesson.isFree) {
      return NextResponse.json(
        { success: false, error: "Not enrolled in course" },
        { status: 403 },
      );
    }

    // Grade the quiz
    let totalPoints = 0;
    let earnedPoints = 0;
    const gradedAnswers: Array<{
      questionId: string;
      answer: string;
      isCorrect: boolean;
      pointsEarned: number;
      correctAnswer?: string;
      explanation?: string;
    }> = [];

    for (const question of lesson.quiz.questions) {
      totalPoints += question.points || 1;
      const userAnswer = answers[question.id];

      if (question.questionType === "MULTIPLE_CHOICE") {
        const isCorrect = userAnswer === question.correctAnswer;
        const points = isCorrect ? question.points || 1 : 0;
        earnedPoints += points;

        gradedAnswers.push({
          questionId: question.id,
          answer: userAnswer || "",
          isCorrect,
          pointsEarned: points,
          correctAnswer: question.correctAnswer || undefined,
          explanation: question.explanation || undefined,
        });
      }
    }

    // Calculate score percentage
    const scorePercentage = Math.round((earnedPoints / totalPoints) * 100);
    const isPassed = scorePercentage >= (lesson.quiz.passingScore || 70);

    // Create quiz attempt
    const attempt = await prisma.quizAttempt.create({
      data: {
        userId: user.id,
        quizId: lesson.quiz.id,
        score: scorePercentage,
        totalPoints,
        isPassed,
        completedAt: new Date(),
        answers: {
          create: gradedAnswers.map((ga) => ({
            questionId: ga.questionId,
            answer: ga.answer,
            isCorrect: ga.isCorrect,
            pointsEarned: ga.pointsEarned,
          })),
        },
      },
    });

    return NextResponse.json({
      success: true,
      data: {
        attemptId: attempt.id,
        score: scorePercentage,
        totalPoints,
        earnedPoints,
        isPassed,
        passingScore: lesson.quiz.passingScore,
        results: gradedAnswers,
      },
    });
  } catch (error) {
    console.error("Error submitting quiz:", error);
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}
