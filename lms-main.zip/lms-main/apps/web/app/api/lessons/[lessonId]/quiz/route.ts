import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";

/**
 * GET /api/lessons/[lessonId]/quiz
 * Get quiz for a lesson
 */
export async function GET(
  request: NextRequest,
  context: { params: Promise<{ lessonId: string }> },
): Promise<NextResponse> {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const { lessonId } = await context.params;

    // Find the user
    const user = await prisma.user.findUnique({
      where: { clerkId },
    });

    if (!user) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 },
      );
    }

    // Get lesson with quiz
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      include: {
        module: {
          include: {
            course: true,
          },
        },
        quiz: {
          include: {
            questions: {
              orderBy: { orderIndex: "asc" },
            },
          },
        },
      },
    });

    if (!lesson) {
      return NextResponse.json(
        { success: false, error: "Lesson not found" },
        { status: 404 },
      );
    }

    // Check enrollment
    const enrollment = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: user.id,
          courseId: lesson.module.courseId,
        },
      },
    });

    if (!enrollment && !lesson.isFree) {
      return NextResponse.json(
        { success: false, error: "Not enrolled in course" },
        { status: 403 },
      );
    }

    // Check if quiz exists
    if (!lesson.quiz) {
      return NextResponse.json({
        success: true,
        data: null,
      });
    }

    // Get user's previous attempts for this quiz
    const attempts = await prisma.quizAttempt.findMany({
      where: {
        userId: user.id,
        quizId: lesson.quiz.id,
      },
      orderBy: {
        startedAt: "desc",
      },
      take: 5,
      include: {
        answers: true,
      },
    });

    return NextResponse.json({
      success: true,
      data: {
        quiz: {
          id: lesson.quiz.id,
          title: lesson.quiz.title,
          description: lesson.quiz.description,
          passingScore: lesson.quiz.passingScore,
          maxAttempts: lesson.quiz.maxAttempts,
          timeLimit: lesson.quiz.timeLimit,
          questions: lesson.quiz.questions.map((q) => ({
            id: q.id,
            questionType: q.questionType,
            question: q.question,
            options: q.options,
            orderIndex: q.orderIndex,
            points: q.points,
            // Don't send correct answer or explanation yet
          })),
        },
        attempts: attempts.map((a) => ({
          id: a.id,
          score: a.score,
          totalPoints: a.totalPoints,
          isPassed: a.isPassed,
          startedAt: a.startedAt,
          completedAt: a.completedAt,
        })),
      },
    });
  } catch (error) {
    console.error("Error fetching lesson quiz:", error);
    return NextResponse.json(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}
