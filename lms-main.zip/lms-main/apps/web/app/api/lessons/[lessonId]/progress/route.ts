import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";
import type { ApiResponse } from "@repo/types";

interface RouteParams {
  lessonId: string;
}

/**
 * POST /api/lessons/[lessonId]/progress
 * Update lesson progress (mark as complete/incomplete)
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<RouteParams> },
) {
  try {
    const { userId: clerkId } = await auth();
    const { lessonId } = await params;

    if (!clerkId) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Find the internal user
    const dbUser = await prisma.user.findUnique({
      where: { clerkId },
    });

    if (!dbUser) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "User not found" },
        { status: 404 },
      );
    }

    // Get lesson to verify it exists and get module/course info
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      include: {
        module: {
          include: {
            course: true,
          },
        },
      },
    });

    if (!lesson) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Lesson not found" },
        { status: 404 },
      );
    }

    // Check enrollment
    const enrollment = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: dbUser.id,
          courseId: lesson.module.courseId,
        },
      },
    });

    if (!enrollment) {
      return NextResponse.json<ApiResponse>(
        { success: false, error: "Not enrolled in this course" },
        { status: 403 },
      );
    }

    // Parse request body
    const body = await request.json();
    const { isCompleted } = body;

    if (typeof isCompleted !== "boolean") {
      return NextResponse.json<ApiResponse>(
        {
          success: false,
          error: "Invalid request: isCompleted must be a boolean",
        },
        { status: 400 },
      );
    }

    // Upsert lesson progress
    const lessonProgress = await prisma.lessonProgress.upsert({
      where: {
        userId_lessonId: {
          userId: dbUser.id,
          lessonId,
        },
      },
      update: {
        isCompleted,
        completedAt: isCompleted ? new Date() : null,
      },
      create: {
        userId: dbUser.id,
        lessonId,
        isCompleted,
        completedAt: isCompleted ? new Date() : null,
      },
    });

    // Recalculate overall course progress
    // Get all lessons visible to user's track
    const allModules = await prisma.module.findMany({
      where: {
        courseId: lesson.module.courseId,
      },
      include: {
        lessons: {
          select: { id: true, track: true },
        },
      },
    });

    const visibleLessonIds = allModules
      .filter((m) => m.track === "BOTH" || m.track === enrollment.enrolledTrack)
      .flatMap((m) => m.lessons.map((l) => l.id));

    // Get completed lessons count
    const completedCount = await prisma.lessonProgress.count({
      where: {
        userId: dbUser.id,
        lessonId: { in: visibleLessonIds },
        isCompleted: true,
      },
    });

    // Update course progress
    const progressPercent =
      visibleLessonIds.length > 0
        ? Math.round((completedCount / visibleLessonIds.length) * 100)
        : 0;

    await prisma.userCourseProgress.update({
      where: {
        userId_courseId: {
          userId: dbUser.id,
          courseId: lesson.module.courseId,
        },
      },
      data: {
        progressPercent,
        isCompleted: progressPercent === 100,
        completedAt: progressPercent === 100 ? new Date() : null,
      },
    });

    return NextResponse.json<ApiResponse<typeof lessonProgress>>({
      success: true,
      data: lessonProgress,
    });
  } catch (error) {
    console.error("Error updating lesson progress:", error);
    return NextResponse.json<ApiResponse>(
      { success: false, error: "Internal server error" },
      { status: 500 },
    );
  }
}
