import { NextRequest, NextResponse } from "next/server";
import { prisma, Track } from "@repo/db";
import { auth } from "@clerk/nextjs/server";

// POST - Enroll in a course
export async function POST(request: NextRequest) {
  try {
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 }
      );
    }

    const body = await request.json();
    const { courseId, track } = body;

    if (!courseId) {
      return NextResponse.json(
        { success: false, error: "Course ID is required" },
        { status: 400 }
      );
    }

    // Get or create user
    let user = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!user) {
      // Create user if doesn't exist
      const clerkUser = await fetch(
        `https://api.clerk.com/v1/users/${userId}`,
        {
          headers: {
            Authorization: `Bearer ${process.env.CLERK_SECRET_KEY}`,
          },
        }
      ).then((res) => res.json());

      user = await prisma.user.create({
        data: {
          clerkId: userId,
          email: clerkUser.email_addresses?.[0]?.email_address || "",
          name: `${clerkUser.first_name || ""} ${clerkUser.last_name || ""}`.trim(),
        },
      });
    }

    // Check if already enrolled
    const existingEnrollment = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: user.id,
          courseId,
        },
      },
    });

    if (existingEnrollment) {
      return NextResponse.json({
        success: true,
        data: existingEnrollment,
        message: "Already enrolled",
      });
    }

    // Check if course exists and has an entry quiz
    const course = await prisma.course.findUnique({
      where: { id: courseId },
      include: { entryQuiz: true },
    });

    if (!course) {
      return NextResponse.json(
        { success: false, error: "Course not found" },
        { status: 404 }
      );
    }

    // If course has entry quiz and no track specified, return error
    if (course.entryQuiz && !track) {
      return NextResponse.json({
        success: false,
        error: "This course requires an entry quiz",
        requiresQuiz: true,
        quizId: course.entryQuiz.id,
      });
    }

    // Create enrollment
    const enrollment = await prisma.userCourseProgress.create({
      data: {
        userId: user.id,
        courseId,
        enrolledTrack: track || Track.BASIC,
        progressPercent: 0,
      },
    });

    return NextResponse.json({
      success: true,
      data: enrollment,
      message: "Successfully enrolled",
    });
  } catch (error) {
    console.error("Error enrolling in course:", error);
    return NextResponse.json(
      { success: false, error: "Failed to enroll" },
      { status: 500 }
    );
  }
}

// GET - Get user's enrollments
export async function GET() {
  try {
    const { userId } = await auth();

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 }
      );
    }

    const user = await prisma.user.findUnique({
      where: { clerkId: userId },
    });

    if (!user) {
      return NextResponse.json({
        success: true,
        data: [],
      });
    }

    const enrollments = await prisma.userCourseProgress.findMany({
      where: { userId: user.id },
      include: {
        course: {
          select: {
            id: true,
            slug: true,
            title: true,
            shortDescription: true,
            imageUrl: true,
            level: true,
            duration: true,
            category: true,
            _count: {
              select: { modules: true },
            },
          },
        },
      },
      orderBy: { updatedAt: "desc" },
    });

    return NextResponse.json({
      success: true,
      data: enrollments,
    });
  } catch (error) {
    console.error("Error fetching enrollments:", error);
    return NextResponse.json(
      { success: false, error: "Failed to fetch enrollments" },
      { status: 500 }
    );
  }
}
