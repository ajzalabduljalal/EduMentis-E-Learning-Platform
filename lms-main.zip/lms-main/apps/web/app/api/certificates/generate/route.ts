import { NextRequest, NextResponse } from "next/server";
import { generateCertificate } from "../../../lib/generate-certificate";

/**
 * POST /api/certificates/generate
 * External-facing endpoint for certificate generation (used by admin app).
 * For same-server calls, use generateCertificate() directly.
 */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, courseId, attemptId } = body as {
      userId: string;
      courseId: string;
      attemptId: string;
    };

    if (!userId || !courseId || !attemptId) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    const result = await generateCertificate(userId, courseId, attemptId);

    return NextResponse.json({
      success: true,
      data: {
        certificateUrl: result.certificateUrl,
        certificateId: result.certificateId,
      },
    });
  } catch (error) {
    console.error("Error generating certificate:", error);
    return NextResponse.json(
      { success: false, error: "Failed to generate certificate" },
      { status: 500 },
    );
  }
}
