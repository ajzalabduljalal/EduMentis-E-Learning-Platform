import { NextRequest, NextResponse } from "next/server";
import { auth } from "@repo/auth";
import { prisma, QuizType, QuestionType } from "@repo/db";
import {
  generateModuleReviewQuiz,
  type GeneratedQuiz,
  type GeneratedQuestion,
} from "@repo/ai";

/**
 * POST /api/ai/generate-review
 *
 * Generate a module-level review quiz
 */
export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const authResult = await auth();
    if (!authResult?.userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get user from database to check role
    const user = await prisma.user.findUnique({
      where: { clerkId: authResult.userId },
    });

    // Only instructors and admins can generate review quizzes
    if (!user || user.role === "STUDENT") {
      return NextResponse.json(
        {
          success: false,
          error: "Only instructors can generate review quizzes",
        },
        { status: 403 },
      );
    }

    // Parse request body
    const body = await request.json();
    const { moduleId, numQuestions, difficulty, saveToDatabase } = body as {
      moduleId: string;
      numQuestions?: number;
      difficulty?: "easy" | "medium" | "hard";
      saveToDatabase?: boolean;
    };

    // Validate moduleId
    if (!moduleId) {
      return NextResponse.json(
        { success: false, error: "Module ID is required" },
        { status: 400 },
      );
    }

    // Fetch module with lessons
    const module = await prisma.module.findUnique({
      where: { id: moduleId },
      include: {
        course: true,
        lessons: {
          select: {
            id: true,
            title: true,
            content: true,
          },
          orderBy: {
            orderIndex: "asc",
          },
        },
      },
    });

    if (!module) {
      return NextResponse.json(
        { success: false, error: "Module not found" },
        { status: 404 },
      );
    }

    if (module.lessons.length === 0) {
      return NextResponse.json(
        {
          success: false,
          error: "Module has no lessons to generate quiz from",
        },
        { status: 400 },
      );
    }

    // Generate review quiz from all lessons in module
    const lessons = module.lessons.map((lesson) => ({
      title: lesson.title,
      content: lesson.content,
    }));

    const generatedQuiz = await generateModuleReviewQuiz(
      module.title,
      lessons,
      {
        numQuestions: numQuestions ?? Math.min(10, lessons.length * 2),
        difficulty: difficulty ?? "medium",
      },
    );

    // Optionally save to database
    if (saveToDatabase) {
      const quiz = await prisma.quiz.create({
        data: {
          title: generatedQuiz.title,
          description: generatedQuiz.description,
          quizType: QuizType.PRACTICE,
          courseId: module.courseId,
          questions: {
            create: generatedQuiz.questions.map(
              (q: GeneratedQuestion, index: number) => ({
                questionType: QuestionType.MULTIPLE_CHOICE,
                question: q.question,
                orderIndex: index,
                options: q.options,
                correctAnswer: q.correctAnswer,
                explanation: q.explanation,
              }),
            ),
          },
        },
      });

      return NextResponse.json({
        success: true,
        data: {
          generated: generatedQuiz,
          saved: {
            quizId: quiz.id,
            quizTitle: quiz.title,
          },
          moduleId: module.id,
          moduleTitle: module.title,
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        generated: generatedQuiz,
        moduleId: module.id,
        moduleTitle: module.title,
        lessonsCount: module.lessons.length,
      },
    });
  } catch (error) {
    console.error("Review quiz generation error:", error);

    if (error instanceof Error) {
      if (error.message.includes("GEMINI_API_KEY")) {
        return NextResponse.json(
          { success: false, error: "AI service is not configured" },
          { status: 503 },
        );
      }
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 },
      );
    }

    return NextResponse.json(
      { success: false, error: "Failed to generate review quiz" },
      { status: 500 },
    );
  }
}
