import { NextRequest, NextResponse } from "next/server";
import { auth } from "@repo/auth";
import { prisma, UserRole } from "@repo/db";

/**
 * POST /api/ai/rebuild-index
 *
 * Rebuild the semantic search index (admin only)
 * DISABLED: Semantic search is currently not available
 */
export async function POST(request: NextRequest) {
  return NextResponse.json(
    {
      success: false,
      error:
        "Semantic search is currently disabled. This feature will be re-enabled in a future update.",
    },
    { status: 503 },
  );
}
