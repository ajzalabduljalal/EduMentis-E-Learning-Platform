import { NextRequest, NextResponse } from "next/server";
import { auth } from "@repo/auth";
import { prisma, QuizType, QuestionType } from "@repo/db";
import {
  generateQuizFromLesson,
  type GeneratedQuiz,
  type GeneratedQuestion,
} from "@repo/ai";

/**
 * POST /api/ai/generate-quiz
 *
 * Generate a quiz from lesson content
 */
export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const authResult = await auth();
    if (!authResult?.userId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Get user from database to check role
    const user = await prisma.user.findUnique({
      where: { clerkId: authResult.userId },
    });

    // Only instructors and admins can generate quizzes
    if (!user || user.role === "STUDENT") {
      return NextResponse.json(
        { success: false, error: "Only instructors can generate quizzes" },
        { status: 403 },
      );
    }

    // Parse request body
    const body = await request.json();
    const { lessonId, numQuestions, difficulty, saveToDatabase } = body as {
      lessonId: string;
      numQuestions?: number;
      difficulty?: "easy" | "medium" | "hard";
      saveToDatabase?: boolean;
    };

    // Validate lessonId
    if (!lessonId) {
      return NextResponse.json(
        { success: false, error: "Lesson ID is required" },
        { status: 400 },
      );
    }

    // Fetch lesson content
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      include: {
        module: {
          include: {
            course: true,
          },
        },
      },
    });

    if (!lesson) {
      return NextResponse.json(
        { success: false, error: "Lesson not found" },
        { status: 404 },
      );
    }

    // Generate quiz
    const generatedQuiz = await generateQuizFromLesson(
      lesson.title,
      lesson.content,
      {
        numQuestions: numQuestions ?? 5,
        difficulty: difficulty ?? "medium",
      },
    );

    // Optionally save to database
    if (saveToDatabase) {
      const quiz = await prisma.quiz.create({
        data: {
          title: generatedQuiz.title,
          description: generatedQuiz.description,
          quizType: QuizType.LESSON_QUIZ,
          courseId: lesson.module.courseId,
          questions: {
            create: generatedQuiz.questions.map(
              (q: GeneratedQuestion, index: number) => ({
                questionType: QuestionType.MULTIPLE_CHOICE,
                question: q.question,
                orderIndex: index,
                options: q.options,
                correctAnswer: q.correctAnswer,
                explanation: q.explanation,
              }),
            ),
          },
        },
      });

      return NextResponse.json({
        success: true,
        data: {
          generated: generatedQuiz,
          saved: {
            quizId: quiz.id,
            quizTitle: quiz.title,
          },
        },
      });
    }

    return NextResponse.json({
      success: true,
      data: {
        generated: generatedQuiz,
      },
    });
  } catch (error) {
    console.error("Quiz generation error:", error);

    if (error instanceof Error) {
      if (error.message.includes("GEMINI_API_KEY")) {
        return NextResponse.json(
          { success: false, error: "AI service is not configured" },
          { status: 503 },
        );
      }
      return NextResponse.json(
        { success: false, error: error.message },
        { status: 500 },
      );
    }

    return NextResponse.json(
      { success: false, error: "Failed to generate quiz" },
      { status: 500 },
    );
  }
}
