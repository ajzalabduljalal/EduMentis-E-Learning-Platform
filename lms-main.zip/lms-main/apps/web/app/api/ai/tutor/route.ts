import { auth } from "@clerk/nextjs/server";
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@repo/db";
import { GoogleGenerativeAI } from "@google/generative-ai";
import { MODEL_CONFIG } from "@repo/ai";

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

if (!GEMINI_API_KEY) {
  console.error("GEMINI_API_KEY not configured");
}

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp?: string;
}

interface TutorRequest {
  message: string;
  lessonId: string;
  courseId: string;
  conversationHistory: Message[];
}

// Rate limiting: Track user request timestamps (in-memory)
const userRequestTimestamps = new Map<string, number[]>();

function checkRateLimit(userId: string): {
  allowed: boolean;
  retryAfter?: number;
} {
  const now = Date.now();
  const timestamps = userRequestTimestamps.get(userId) || [];

  // Remove timestamps older than 60 seconds
  const recentTimestamps = timestamps.filter((ts) => now - ts < 60000);

  if (recentTimestamps.length >= 10) {
    const oldestTimestamp = Math.min(...recentTimestamps);
    const retryAfter = Math.ceil((60000 - (now - oldestTimestamp)) / 1000);
    return { allowed: false, retryAfter };
  }

  // Add current timestamp
  recentTimestamps.push(now);
  userRequestTimestamps.set(userId, recentTimestamps);

  return { allowed: true };
}

/**
 * AI Tutor API Route
 * Provides context-aware tutoring based on lesson content
 * Features: Rate limiting (10 req/min), conversation history persistence
 */
export async function POST(request: NextRequest) {
  try {
    // Check authentication
    const { userId: clerkId } = await auth();
    if (!clerkId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    // Find the internal user
    const dbUser = await prisma.user.findUnique({
      where: { clerkId },
    });

    if (!dbUser) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 },
      );
    }

    // Check rate limit (10 requests per minute per user)
    const rateLimit = checkRateLimit(dbUser.id);
    if (!rateLimit.allowed) {
      return NextResponse.json(
        {
          success: false,
          error: `Rate limit exceeded. Please wait ${rateLimit.retryAfter} seconds before trying again.`,
        },
        { status: 429 },
      );
    }

    // Parse request body
    const body: TutorRequest = await request.json();
    const { message, lessonId, courseId, conversationHistory } = body;

    // Validate input
    if (!message || !lessonId || !courseId) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 },
      );
    }

    // Verify enrollment
    const enrollment = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: dbUser.id,
          courseId: courseId,
        },
      },
    });

    if (!enrollment) {
      return NextResponse.json(
        { success: false, error: "Not enrolled in this course" },
        { status: 403 },
      );
    }

    // Get lesson content for context
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      select: {
        id: true,
        title: true,
        content: true,
        description: true,
        module: {
          select: {
            title: true,
          },
        },
      },
    });

    if (!lesson) {
      return NextResponse.json(
        { success: false, error: "Lesson not found" },
        { status: 404 },
      );
    }

    // Check API key
    if (!GEMINI_API_KEY) {
      return NextResponse.json(
        { success: false, error: "AI service not configured" },
        { status: 503 },
      );
    }

    // Load or create conversation history from database
    let conversation = await prisma.tutorConversation.findFirst({
      where: {
        userId: dbUser.id,
        courseId,
        lessonId,
      },
    });

    if (!conversation) {
      conversation = await prisma.tutorConversation.create({
        data: {
          userId: dbUser.id,
          courseId,
          lessonId,
          messages: [],
        },
      });
    }

    // Get existing messages from database (cast safely from JSON)
    const existingMessages = Array.isArray(conversation.messages)
      ? (conversation.messages as unknown as Message[])
      : [];

    // Strip HTML tags from lesson content for cleaner context
    const cleanContent = lesson.content
      .replace(/<[^>]*>/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .substring(0, 8000); // Limit to ~8k chars to leave room for conversation

    // Build system instruction with lesson context
    const systemInstruction = `You are an AI tutor helping students understand a specific lesson in an online course.

CURRENT LESSON CONTEXT:
Module: ${lesson.module.title}
Lesson: ${lesson.title}
${lesson.description ? `Description: ${lesson.description}` : ""}

LESSON CONTENT:
${cleanContent}

INSTRUCTIONS:
- Answer questions ONLY about the lesson content above
- If asked about topics outside this lesson, politely redirect students to focus on the current lesson material
- Provide clear, concise explanations suitable for students learning this topic
- Use examples from the lesson content when possible
- Be encouraging and supportive in your responses
- Break down complex concepts into simpler terms
- If you need to reason through a problem, think step-by-step before answering

CONSTRAINTS:
- Stay focused on this specific lesson
- Don't provide direct answers to assessments or quiz questions
- Don't make up information not present in the lesson
- If something is unclear in the lesson, acknowledge it and explain what IS covered
- Encourage students to engage with the material actively

Remember: Your role is to help students understand the lesson, not to do their work for them.`;

    // Initialize Gemini with systemInstruction at model level
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({
      model: MODEL_CONFIG.chat, // Uses gemini-2.5-flash
      systemInstruction: {
        role: "system",
        parts: [{ text: systemInstruction }],
      },
    });

    // Build conversation history for Gemini (use existing from DB + new from request)
    const history = existingMessages.slice(-10).map((msg) => ({
      role: msg.role === "assistant" ? "model" : "user",
      parts: [{ text: msg.content }],
    }));

    // Start chat session
    const chat = model.startChat({
      history: history,
      generationConfig: {
        temperature: 0.7,
        topP: 0.95,
        topK: 40,
        maxOutputTokens: 1024,
      },
    });

    // Send message and stream response
    const result = await chat.sendMessageStream(message);

    // Collect the full response for saving to database
    let fullResponse = "";

    // Create a readable stream for the response
    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of result.stream) {
            const text = chunk.text();
            fullResponse += text;
            controller.enqueue(encoder.encode(text));
          }
          controller.close();

          // After streaming is complete, save conversation to database
          const userMessage: Message = {
            role: "user",
            content: message,
            timestamp: new Date().toISOString(),
          };

          const assistantMessage: Message = {
            role: "assistant",
            content: fullResponse,
            timestamp: new Date().toISOString(),
          };

          const updatedMessages = [
            ...existingMessages,
            userMessage,
            assistantMessage,
          ];

          // Update conversation in database
          await prisma.tutorConversation.update({
            where: { id: conversation.id },
            data: {
              messages: updatedMessages as any,
              updatedAt: new Date(),
            },
          });
        } catch (error) {
          console.error("Streaming error:", error);
          controller.error(error);
        }
      },
    });

    // Return streaming response
    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Transfer-Encoding": "chunked",
      },
    });
  } catch (error) {
    console.error("AI Tutor error:", error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Internal server error",
      },
      { status: 500 },
    );
  }
}
