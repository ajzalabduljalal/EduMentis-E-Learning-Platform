import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { prisma } from "@repo/db";

interface Message {
  role: "user" | "assistant";
  content: string;
  timestamp?: string;
}

/**
 * GET AI Tutor Conversation History
 * Loads existing conversation history for a specific lesson
 */
export async function GET(req: NextRequest) {
  try {
    const { userId: clerkId } = await auth();
    if (!clerkId) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 },
      );
    }

    const { searchParams } = new URL(req.url);
    const courseId = searchParams.get("courseId");
    const lessonId = searchParams.get("lessonId");

    if (!courseId) {
      return NextResponse.json(
        { success: false, error: "courseId required" },
        { status: 400 },
      );
    }

    // Get database user
    const dbUser = await prisma.user.findUnique({
      where: { clerkId },
    });

    if (!dbUser) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 },
      );
    }

    // Verify enrollment
    const enrollment = await prisma.userCourseProgress.findUnique({
      where: {
        userId_courseId: {
          userId: dbUser.id,
          courseId,
        },
      },
    });

    if (!enrollment) {
      return NextResponse.json(
        { success: false, error: "Not enrolled in this course" },
        { status: 403 },
      );
    }

    // Find or create conversation
    let conversation = await prisma.tutorConversation.findFirst({
      where: {
        userId: dbUser.id,
        courseId,
        lessonId: lessonId || null,
      },
    });

    if (!conversation) {
      conversation = await prisma.tutorConversation.create({
        data: {
          userId: dbUser.id,
          courseId,
          lessonId: lessonId || null,
          messages: [],
        },
      });
    }

    // Cast messages safely
    const messages = Array.isArray(conversation.messages)
      ? (conversation.messages as unknown as Message[])
      : [];

    return NextResponse.json({
      success: true,
      data: {
        conversationId: conversation.id,
        messages: messages,
      },
    });
  } catch (error) {
    console.error("Error loading conversation history:", error);
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Internal server error",
      },
      { status: 500 },
    );
  }
}
