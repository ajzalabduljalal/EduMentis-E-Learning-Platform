import { SignIn } from "@clerk/nextjs";
import Link from "next/link";
import { BookOpen, Brain, TrendingUp, Award } from "lucide-react";

export default function SignInPage() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-[40%_60%] h-screen overflow-hidden">
      {/* Left Side - Marketing Content */}
      <div
        className="hidden lg:flex flex-col justify-between p-12 xl:p-16 overflow-hidden"
        style={{
          backgroundImage: "url('/signup-bg.png')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          backgroundRepeat: "no-repeat",
        }}
      >
        {/* Logo */}
        <div>
          <Link
            href="/"
            className="inline-block text-2xl font-normal text-text-primary hover:opacity-80 transition-opacity"
          >
            Edumentis
          </Link>
        </div>

        {/* Hero Content */}
        <div className="max-w-md">
          <h1 className="text-4xl xl:text-5xl font-light tracking-tight text-text-primary mb-6">
            Welcome back to{" "}
            <span className="font-normal">smarter learning</span>
          </h1>
          <p className="text-lg text-text-secondary leading-relaxed font-light mb-12">
            Continue your personalized learning journey where you left off.
          </p>

          {/* Features List */}
          <div className="space-y-6">
            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white border border-zinc-200">
                <BookOpen className="h-5 w-5 text-text-primary" />
              </div>
              <div>
                <h3 className="text-base font-normal text-text-primary mb-1">
                  Adaptive learning paths
                </h3>
                <p className="text-sm text-text-secondary font-light leading-relaxed">
                  Entry quiz places you in the right track—basic or advanced
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white border border-zinc-200">
                <Brain className="h-5 w-5 text-text-primary" />
              </div>
              <div>
                <h3 className="text-base font-normal text-text-primary mb-1">
                  Context-aware AI tutor
                </h3>
                <p className="text-sm text-text-secondary font-light leading-relaxed">
                  Get help specific to each lesson as you learn
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white border border-zinc-200">
                <TrendingUp className="h-5 w-5 text-text-primary" />
              </div>
              <div>
                <h3 className="text-base font-normal text-text-primary mb-1">
                  Track your progress
                </h3>
                <p className="text-sm text-text-secondary font-light leading-relaxed">
                  See completion across all your enrolled courses
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonial */}
        <div className="max-w-md">
          <div className="rounded-lg border border-zinc-200 bg-white p-6">
            <p className="text-sm text-text-secondary leading-relaxed mb-4 font-light italic">
              &ldquo;The AI tutor understands exactly what I&rsquo;m learning.
              When I&rsquo;m stuck on a lesson, it gives me context-aware help
              instead of generic answers.&rdquo;
            </p>
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center shrink-0">
                <span className="text-sm font-medium text-text-primary">
                  SM
                </span>
              </div>
              <div>
                <div className="text-sm font-medium text-text-primary">
                  Sarah Mitchell
                </div>
                <div className="text-xs text-text-secondary">
                  Web Development Student
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Side - Sign In Form */}
      <div className="flex flex-col items-center justify-center p-6 sm:p-12 bg-white overflow-y-auto min-w-0">
        {/* Mobile Logo */}
        <div className="lg:hidden mb-8">
          <Link
            href="/"
            className="inline-block text-2xl font-normal text-text-primary hover:opacity-80 transition-opacity"
          >
            Edumentis
          </Link>
        </div>

        {/* Sign In Component */}
        <div className="w-full max-w-md">
          <div className="mb-8 text-center">
            <h2 className="text-3xl font-light text-text-primary mb-3">
              Sign in to your account
            </h2>
            <p className="text-base text-text-secondary font-light">
              Enter your credentials to continue learning
            </p>
          </div>

          <SignIn
            appearance={{
              elements: {
                rootBox: "mx-auto",
                card: "shadow-none border border-zinc-200",
                formButtonPrimary:
                  "bg-text-primary hover:bg-text-primary/90 text-sm font-medium",
                footerActionLink:
                  "text-text-primary hover:text-text-primary/80",
                footer: {
                  display: "none",
                },
              },
            }}
          />

          {/* Sign Up Link */}
          <div className="mt-8 text-center">
            <p className="text-sm text-text-secondary font-light">
              Don&apos;t have an account?{" "}
              <Link
                href="/sign-up"
                className="font-medium text-text-primary hover:underline"
              >
                Sign up for free
              </Link>
            </p>
          </div>
        </div>

        {/* Back to Home Link */}
        <div className="mt-8">
          <Link
            href="/"
            className="text-sm text-text-secondary hover:text-text-primary transition-colors font-light"
          >
            ← Back to home
          </Link>
        </div>
      </div>
    </div>
  );
}
