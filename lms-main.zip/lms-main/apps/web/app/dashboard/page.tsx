import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { prisma } from "@repo/db";
import { Progress } from "@repo/ui/components/progress";
import { Button } from "@repo/ui/components/button";
import {
  BookOpen,
  Clock,
  CheckCircle2,
  ArrowRight,
  ArrowUpRight,
} from "lucide-react";
import { DashboardClient } from "./DashboardClient";

// Placeholder images for courses without thumbnails
const placeholderImages = [
  "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=800&h=400&fit=crop",
  "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=800&h=400&fit=crop",
  "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=400&fit=crop",
];

export default async function DashboardPage() {
  const { userId: clerkId } = await auth();

  if (!clerkId) {
    redirect("/sign-in");
  }

  const user = await currentUser();

  // Find the internal user by Clerk ID
  const dbUser = await prisma.user.findUnique({
    where: { clerkId },
  });

  // If user doesn't exist in DB yet, redirect to courses
  // This handles brand new users who haven't enrolled yet
  if (!dbUser) {
    redirect("/courses");
  }

  // Fetch user's enrollments with course details
  const enrollments = await prisma.userCourseProgress.findMany({
    where: { userId: dbUser.id },
    include: {
      course: {
        include: {
          modules: {
            include: {
              lessons: true,
            },
          },
        },
      },
    },
    orderBy: { updatedAt: "desc" },
  });

  // Calculate stats
  const totalCourses = enrollments.length;
  const inProgress = enrollments.filter(
    (e) => e.progressPercent > 0 && e.progressPercent < 100,
  ).length;
  const completed = enrollments.filter((e) => e.progressPercent >= 100).length;

  // Get the most recently accessed course (last updated)
  const lastAccessedCourse =
    enrollments.length > 0 && enrollments[0]!.progressPercent < 100
      ? enrollments[0]
      : null;

  // Get recent courses (up to 6 for 3-column grid)
  const recentCourses = enrollments.slice(0, 6);

  // Helper to get course image
  const getCourseImage = (course: { id: string; imageUrl: string | null }) => {
    if (course.imageUrl) {
      try {
        new URL(course.imageUrl);
        return course.imageUrl;
      } catch {
        // Invalid URL
      }
    }
    return placeholderImages[
      course.id.charCodeAt(0) % placeholderImages.length
    ];
  };

  // Prepare data for client component
  const coursesData = recentCourses.map((enrollment) => ({
    id: enrollment.course.id,
    slug: enrollment.course.slug,
    title: enrollment.course.title,
    shortDescription: enrollment.course.shortDescription,
    imageUrl: getCourseImage(enrollment.course) || null,
    category: enrollment.course.category,
    enrolledTrack: enrollment.enrolledTrack,
    progressPercent: enrollment.progressPercent,
    moduleCount: enrollment.course.modules.length,
    lessonCount: enrollment.course.modules.reduce(
      (acc, m) => acc + m.lessons.length,
      0,
    ),
    enrolledCount: 0, // We don't have this data here
  }));

  const lastAccessedData = lastAccessedCourse
    ? {
        slug: lastAccessedCourse.course.slug,
        title: lastAccessedCourse.course.title,
        progressPercent: lastAccessedCourse.progressPercent,
      }
    : null;

  return (
    <DashboardClient
      userName={user?.firstName || "there"}
      stats={{
        totalCourses,
        inProgress,
        completed,
      }}
      courses={coursesData}
      lastAccessedCourse={lastAccessedData}
    />
  );
}
