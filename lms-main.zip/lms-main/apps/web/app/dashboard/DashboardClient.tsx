"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  BookOpen,
  Clock,
  CheckCircle2,
  ArrowRight,
  ArrowUpRight,
  Loader2,
} from "lucide-react";
import { Button } from "@repo/ui/components/button";
import { Sidebar, SidebarCategory } from "../components/Sidebar";
import { Navbar } from "../components/Navbar";
import { getCategoryConfig } from "../lib/category-config";
import { CourseCard } from "../courses/components/CourseCard";

interface Stats {
  totalCourses: number;
  inProgress: number;
  completed: number;
}

interface Course {
  id: string;
  slug: string;
  title: string;
  shortDescription: string | null;
  imageUrl: string | null;
  category: string | null;
  enrolledTrack: "BASIC" | "ADVANCED" | "BOTH";
  progressPercent: number;
  moduleCount: number;
  lessonCount: number;
  enrolledCount: number;
}

interface LastAccessedCourse {
  slug: string;
  title: string;
  progressPercent: number;
}

interface DashboardClientProps {
  userName: string;
  stats: Stats;
  courses: Course[];
  lastAccessedCourse: LastAccessedCourse | null;
}

export function DashboardClient({
  userName,
  stats,
  courses,
  lastAccessedCourse,
}: DashboardClientProps) {
  const router = useRouter();
  const [categories, setCategories] = useState<SidebarCategory[]>([]);
  const [activeCategory, setActiveCategory] = useState("all");
  const [isRedirecting, setIsRedirecting] = useState(false);

  // Auto-redirect to courses if no courses enrolled
  useEffect(() => {
    if (courses.length === 0 && !isRedirecting) {
      setIsRedirecting(true);
      // Wait 2.5 seconds before redirecting for smooth UX
      const timer = setTimeout(() => {
        router.push("/courses");
      }, 2500);

      return () => clearTimeout(timer);
    }
  }, [courses.length, isRedirecting, router]);

  // Extract unique categories from enrolled courses
  useEffect(() => {
    const uniqueCategories = Array.from(
      new Set(
        courses
          .map((c) => c.category)
          .filter((cat): cat is string => cat !== null),
      ),
    ) as string[];

    const categoryList: SidebarCategory[] = uniqueCategories.map((cat) => {
      const config = getCategoryConfig(cat);
      return {
        name: cat,
        slug: cat.toLowerCase().replace(/\s+/g, "-"),
        icon: config.icon,
        color: config.color,
        bgColor: config.bgColor,
      };
    });

    setCategories(categoryList);
  }, [courses]);

  // Filter courses by active category
  const filteredCourses =
    activeCategory === "all"
      ? courses
      : courses.filter(
          (c) =>
            c.category?.toLowerCase().replace(/\s+/g, "-") === activeCategory,
        );

  // Show loading screen when redirecting with empty state
  if (isRedirecting && courses.length === 0) {
    return (
      <div className="min-h-screen bg-bg-primary flex items-center justify-center">
        <div className="text-center max-w-md mx-auto px-6">
          <div className="mb-6 flex justify-center">
            <div className="relative">
              <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center">
                <Loader2 className="h-8 w-8 text-accent animate-spin" />
              </div>
              {/* Pulse ring animation */}
              <div className="absolute inset-0 rounded-full bg-accent/20 animate-ping" />
            </div>
          </div>
          <h2 className="text-xl font-semibold text-text-primary mb-3">
            Welcome to your learning journey
          </h2>
          <p className="text-base text-text-secondary leading-relaxed">
            You haven't enrolled in any courses yet. Let's explore our catalog
            and find the perfect course for you...
          </p>
          {/* Progress dots */}
          <div className="mt-6 flex justify-center gap-2">
            <div
              className="h-2 w-2 rounded-full bg-accent animate-pulse"
              style={{ animationDelay: "0ms" }}
            />
            <div
              className="h-2 w-2 rounded-full bg-accent animate-pulse"
              style={{ animationDelay: "150ms" }}
            />
            <div
              className="h-2 w-2 rounded-full bg-accent animate-pulse"
              style={{ animationDelay: "300ms" }}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-bg-primary">
      {/* Navbar */}
      <Navbar />

      {/* Sidebar */}
      <Sidebar
        categories={categories}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
      />

      {/* Main Content */}
      <div className="lg:pl-64 transition-all duration-300">
        {/* Header */}
        <div className="border-b border-border">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-10">
            <h1 className="text-2xl font-semibold tracking-tight text-text-primary">
              Welcome back, {userName}
            </h1>
            <p className="mt-1 text-text-secondary">
              Continue your learning journey
            </p>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
          {/* Stats */}
          <div className="grid gap-6 md:grid-cols-3 mb-10">
            <div className="bg-bg-primary border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-text-secondary">Enrolled</p>
                  <p className="mt-2 text-3xl font-semibold text-text-primary">
                    {stats.totalCourses}
                  </p>
                </div>
                <div className="h-12 w-12 rounded-full bg-bg-tertiary flex items-center justify-center">
                  <BookOpen className="h-6 w-6 text-text-secondary" />
                </div>
              </div>
            </div>

            <div className="bg-bg-primary border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-text-secondary">In progress</p>
                  <p className="mt-2 text-3xl font-semibold text-text-primary">
                    {stats.inProgress}
                  </p>
                </div>
                <div className="h-12 w-12 rounded-full bg-bg-tertiary flex items-center justify-center">
                  <Clock className="h-6 w-6 text-text-secondary" />
                </div>
              </div>
            </div>

            <div className="bg-bg-primary border border-border rounded-lg p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-text-secondary">Completed</p>
                  <p className="mt-2 text-3xl font-semibold text-text-primary">
                    {stats.completed}
                  </p>
                </div>
                <div className="h-12 w-12 rounded-full bg-bg-tertiary flex items-center justify-center">
                  <CheckCircle2 className="h-6 w-6 text-text-secondary" />
                </div>
              </div>
            </div>
          </div>

          {/* Continue from where you left off */}
          {lastAccessedCourse && (
            <div className="mb-10">
              <h2 className="text-lg font-semibold text-text-primary mb-4">
                Continue from where you left off
              </h2>
              <Link
                href={`/courses/${lastAccessedCourse.slug}/learn`}
                className="block group"
              >
                <div className="bg-bg-secondary border border-border rounded-lg p-6 hover:-translate-y-1 transition-all duration-200">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-base font-semibold text-text-primary group-hover:text-primary transition-colors">
                        {lastAccessedCourse.title}
                      </h3>
                      <p className="mt-1 text-sm text-text-secondary">
                        {Math.round(lastAccessedCourse.progressPercent)}%
                        completed
                      </p>
                    </div>
                    <div className="ml-4">
                      <div className="h-10 w-10 rounded-full bg-bg-primary flex items-center justify-center group-hover:bg-primary group-hover:text-white transition-colors">
                        <ArrowRight className="h-5 w-5" />
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          )}

          {/* Courses Section */}
          {filteredCourses.length > 0 ? (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-lg font-semibold text-text-primary">
                  Your courses
                </h2>
                <Link
                  href="/courses"
                  className="text-sm text-text-secondary hover:text-text-primary flex items-center gap-1 transition-colors"
                >
                  Browse all courses
                  <ArrowUpRight className="h-3 w-3" />
                </Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredCourses.map((course) => (
                  <CourseCard
                    key={course.id}
                    id={course.id}
                    slug={course.slug}
                    title={course.title}
                    shortDescription={course.shortDescription}
                    imageUrl={course.imageUrl}
                    level="BEGINNER" // We don't have level in the data, using default
                    duration={null}
                    price={0}
                    category={course.category}
                    moduleCount={course.moduleCount}
                    enrolledCount={course.enrolledCount}
                    lessonCount={course.lessonCount}
                    isEnrolled={true}
                    progress={course.progressPercent}
                  />
                ))}
              </div>
            </div>
          ) : (
            /* Empty State */
            <div className="border border-border rounded-lg p-8 text-center bg-bg-primary">
              <h2 className="text-lg font-medium text-text-primary">
                No courses yet
              </h2>
              <p className="mt-2 text-sm text-text-secondary max-w-sm mx-auto">
                Browse our courses, take an entry assessment to find your
                learning track, and start your personalized learning experience.
              </p>
              <Link href="/courses">
                <Button className="mt-6">
                  Browse courses
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
