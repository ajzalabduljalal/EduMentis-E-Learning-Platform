"use client";

import { useState, useEffect } from "react";
import { Search } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@repo/ui/components/dialog";
import Link from "next/link";

interface Course {
  id: string;
  slug: string;
  title: string;
  shortDescription: string | null;
  category: string | null;
  level: "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
}

interface SearchModalProps {
  open: boolean;
  onClose: () => void;
}

export function SearchModal({ open, onClose }: SearchModalProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<Course[]>([]);
  const [loading, setLoading] = useState(false);

  // Keyboard shortcut: Ctrl+K / Cmd+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "k") {
        e.preventDefault();
        if (typeof window !== "undefined") {
          const event = new CustomEvent("openSearch");
          window.dispatchEvent(event);
        }
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, []);

  // Search courses when query changes
  useEffect(() => {
    const searchCourses = async () => {
      if (!query.trim()) {
        setResults([]);
        return;
      }

      setLoading(true);
      try {
        const response = await fetch(
          `/api/courses?search=${encodeURIComponent(query)}&pageSize=5`,
        );
        const data = await response.json();

        if (data.success) {
          setResults(data.data?.items || data.data || []);
        }
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setLoading(false);
      }
    };

    // Debounce search
    const timeoutId = setTimeout(searchCourses, 300);
    return () => clearTimeout(timeoutId);
  }, [query]);

  // Reset state when modal closes
  useEffect(() => {
    if (!open) {
      setQuery("");
      setResults([]);
    }
  }, [open]);

  const handleResultClick = () => {
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0 top-[15%] translate-y-0 sm:top-[15%] [&>button]:hidden">
        <DialogHeader className="sr-only">
          <DialogTitle>Search Courses</DialogTitle>
        </DialogHeader>

        {/* Search Input */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border">
          <Search className="h-4 w-4 text-text-tertiary shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search courses..."
            className="flex-1 bg-transparent text-base text-text-primary placeholder:text-text-tertiary outline-none"
            autoFocus
          />
        </div>

        {/* Results */}
        <div className="max-h-[500px] overflow-y-auto">
          {loading && (
            <div className="flex items-center justify-center py-16">
              <div className="text-sm text-text-tertiary">Searching...</div>
            </div>
          )}

          {!loading && query && results.length > 0 && (
            <div className="py-2">
              <div className="px-5 py-2">
                <p className="text-xs font-medium text-text-tertiary uppercase tracking-wide">
                  Found {results.length} result{results.length !== 1 ? "s" : ""}
                  :
                </p>
              </div>
              <div className="space-y-0.5 px-2">
                {results.map((course) => (
                  <Link
                    key={course.id}
                    href={`/courses/${course.slug}`}
                    onClick={handleResultClick}
                    className="block px-3 py-3 rounded-lg hover:bg-bg-secondary transition-colors"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <h3 className="text-base font-medium text-text-primary">
                          {course.title}
                        </h3>
                        {course.category && (
                          <span className="inline-block mt-1.5 text-xs text-text-tertiary px-2 py-0.5 bg-bg-tertiary rounded">
                            Learning Unit
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {!loading && query && results.length === 0 && (
            <div className="flex items-center justify-center py-16">
              <div className="text-center">
                <p className="text-sm text-text-tertiary">
                  No courses found for &quot;{query}&quot;
                </p>
              </div>
            </div>
          )}

          {!loading && !query && (
            <div className="flex items-center justify-center py-16">
              <div className="text-center">
                <p className="text-sm text-text-tertiary">
                  Start typing to search courses
                </p>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
