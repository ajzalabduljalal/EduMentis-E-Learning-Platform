"use client";

import { ReactNode } from "react";
import { Sidebar, SidebarCategory } from "../Sidebar";

interface AppLayoutProps {
  children: ReactNode;
  categories: SidebarCategory[];
  activeCategory?: string;
  onCategoryChange?: (category: string) => void;
  showSidebar?: boolean;
}

export function AppLayout({
  children,
  categories,
  activeCategory,
  onCategoryChange,
  showSidebar = true,
}: AppLayoutProps) {
  return (
    <div className="min-h-screen bg-bg-primary">
      {showSidebar && (
        <Sidebar
          categories={categories}
          activeCategory={activeCategory}
          onCategoryChange={onCategoryChange}
        />
      )}
      <main
        className={`${
          showSidebar ? "lg:pl-64" : ""
        } transition-all duration-300`}
      >
        {children}
      </main>
    </div>
  );
}
