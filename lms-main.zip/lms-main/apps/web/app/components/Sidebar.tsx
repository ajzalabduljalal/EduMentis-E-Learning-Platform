"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { GraduationCap, ChevronLeft, ChevronRight } from "lucide-react";
import type { LucideIcon } from "lucide-react";

export interface SidebarCategory {
  name: string;
  slug: string;
  icon: LucideIcon;
  color: string;
  bgColor: string;
}

interface SidebarProps {
  categories: SidebarCategory[];
  activeCategory?: string;
  onCategoryChange?: (category: string) => void;
}

export function Sidebar({
  categories,
  activeCategory = "all",
  onCategoryChange,
}: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const pathname = usePathname();

  const handleCategoryClick = (slug: string) => {
    if (onCategoryChange) {
      onCategoryChange(slug);
    }
  };

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:block fixed left-0 top-16 h-[calc(100vh-4rem)] bg-bg-primary border-r border-border transition-all duration-300 ${
          isCollapsed ? "w-20" : "w-64"
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Collapse Toggle */}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="absolute -right-3 top-6 h-6 w-6 rounded-full bg-bg-primary border border-border flex items-center justify-center hover:bg-bg-secondary transition-colors z-10"
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {isCollapsed ? (
              <ChevronRight className="h-3 w-3 text-text-secondary" />
            ) : (
              <ChevronLeft className="h-3 w-3 text-text-secondary" />
            )}
          </button>

          {/* Navigation */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            {/* All Courses */}
            <button
              onClick={() => handleCategoryClick("all")}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                activeCategory === "all"
                  ? "bg-amber-50 text-text-primary"
                  : "text-text-secondary hover:bg-bg-secondary"
              }`}
            >
              <div
                className={`flex h-8 w-8 items-center justify-center rounded-full shrink-0 ${
                  activeCategory === "all"
                    ? "bg-amber-100 text-amber-600"
                    : "bg-bg-tertiary text-text-secondary"
                }`}
              >
                <GraduationCap className="h-4 w-4" />
              </div>
              {!isCollapsed && (
                <span className="text-sm font-medium">All Courses</span>
              )}
            </button>

            {/* Divider */}
            {!isCollapsed && (
              <div className="py-2">
                <div className="border-t border-border"></div>
              </div>
            )}

            {/* Category List */}
            {categories.map((category) => {
              const Icon = category.icon;
              const isActive = activeCategory === category.slug;

              return (
                <button
                  key={category.slug}
                  onClick={() => handleCategoryClick(category.slug)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                    isActive
                      ? "bg-amber-50 text-text-primary"
                      : "text-text-secondary hover:bg-bg-secondary"
                  }`}
                  title={isCollapsed ? category.name : undefined}
                >
                  <div
                    className={`flex h-8 w-8 items-center justify-center rounded-full shrink-0 ${
                      isActive
                        ? `${category.bgColor} ${category.color}`
                        : "bg-bg-tertiary text-text-secondary"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                  {!isCollapsed && (
                    <span className="text-sm font-medium truncate">
                      {category.name}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </aside>

      {/* Mobile Category Dropdown (shown on mobile) */}
      <div className="lg:hidden px-4 py-4 border-b border-border bg-bg-primary">
        <label htmlFor="category-select" className="sr-only">
          Select Category
        </label>
        <select
          id="category-select"
          value={activeCategory}
          onChange={(e) => handleCategoryClick(e.target.value)}
          className="w-full px-4 py-2.5 text-sm font-medium rounded-lg border border-border bg-bg-primary text-text-primary focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
        >
          <option value="all">All Courses</option>
          {categories.map((category) => (
            <option key={category.slug} value={category.slug}>
              {category.name}
            </option>
          ))}
        </select>
      </div>
    </>
  );
}
