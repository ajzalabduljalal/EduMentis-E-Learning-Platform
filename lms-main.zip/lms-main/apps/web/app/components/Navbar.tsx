"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { Search, GraduationCap } from "lucide-react";
import { UserButton } from "@clerk/nextjs";
import { SearchModal } from "./SearchModal";

export function Navbar() {
  const [searchOpen, setSearchOpen] = useState(false);

  // Listen for custom search open event (from Ctrl+K)
  useEffect(() => {
    const handleOpenSearch = () => setSearchOpen(true);
    window.addEventListener("openSearch", handleOpenSearch);
    return () => window.removeEventListener("openSearch", handleOpenSearch);
  }, []);

  return (
    <>
      <nav className="fixed top-0 left-0 right-0 z-50 h-16 bg-bg-primary border-b border-border">
        <div className="mx-auto max-w-full px-6 h-full">
          <div className="flex items-center justify-between h-full">
            {/* Logo */}
            <Link
              href="/dashboard"
              className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-200 bg-white hover:bg-zinc-50 transition-colors"
            >
              <GraduationCap className="h-5 w-5 text-accent" />
              <span className="font-semibold text-text-primary">Edumentis</span>
            </Link>

            {/* Right side - Search + User Menu */}
            <div className="flex items-center gap-3">
              {/* Search Button - Rectangular */}
              <button
                onClick={() => setSearchOpen(true)}
                className="flex items-center gap-2 px-8 py-1 rounded-sm bg-white border border-border text-text-secondary hover:bg-bg-secondary transition-colors"
                aria-label="Search courses"
              >
                <Search className="h-4 w-4 shrink-0" />
                <span className="hidden sm:inline text-sm text-text-tertiary">
                  Ctrl K
                </span>
              </button>

              {/* User Menu */}
              <UserButton
                afterSignOutUrl="/"
                appearance={{
                  elements: {
                    avatarBox: "h-8 w-8",
                    userButtonPopoverFooter: { display: "none" },
                    footer: { display: "none" },
                    popoverFooter: { display: "none" },
                  },
                }}
              />
            </div>
          </div>
        </div>
      </nav>

      {/* Add padding to body to account for fixed navbar */}
      <div className="h-16" />

      {/* Search Modal */}
      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} />
    </>
  );
}
