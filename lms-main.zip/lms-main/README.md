# LMS Platform - AI-Powered Learning Management System

This is a modern LMS (Learning Management System) monorepo built for adaptive learning with AI-powered features.

## 🏗️ Architecture

Built with:

- **[Turborepo](https://turbo.build/)** - Monorepo build system
- **[Next.js 16](https://nextjs.org/)** - React framework with App Router
- **[TypeScript](https://www.typescriptlang.org/)** - Type-safe development
- **[Prisma](https://www.prisma.io/)** - Database ORM with PostgreSQL
- **[Clerk](https://clerk.com/)** - Authentication & user management
- **[Tailwind CSS](https://tailwindcss.com/)** - Utility-first styling
- **[shadcn/ui](https://ui.shadcn.com/)** - Radix UI components
- **[Google Gemini](https://ai.google.dev/gemini-api)** - AI tutoring & content generation


## 📁 Monorepo Structure

```
lms-platform/
├── apps/
│   ├── web/                    # Student-facing Next.js app (port 3000)
│   └── admin/                  # Admin panel Next.js app (port 3001)
└── packages/
    ├── auth/                   # @repo/auth - Clerk configuration
    ├── config/                 # @repo/config - Shared Tailwind & configs
    ├── database/               # @repo/db - Prisma schema & client
    ├── eslint-config/          # @repo/eslint-config - ESLint rules
    ├── types/                  # @repo/types - Shared TypeScript types
    ├── typescript-config/      # @repo/typescript-config - TS configs
    └── ui/                     # @repo/ui - Shared UI components
```

## 🚀 Quick Start

### Prerequisites

- **Node.js 18+** (we recommend using [mise](https://mise.jdx.dev/) or [nvm](https://github.com/nvm-sh/nvm))
- **npm 11.6.2+**
- **PostgreSQL** database (local, Docker, or hosted)

### 1. Clone & Install

```bash
git clone <REPO_URL> lms-platform
cd lms-platform
npm install
```

### 2. Environment Setup

Copy the example env files for both apps:

```bash
cp apps/web/.env.example apps/web/.env
cp apps/admin/.env.example apps/admin/.env
cp packages/database/.env.example packages/database/.env
```

Update the `.env` files with your credentials:

**Required variables:**

- `DATABASE_URL` - PostgreSQL connection string
- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` & `CLERK_SECRET_KEY` - Clerk auth keys
- `GEMINI_API_KEY` - Google Gemini API key

See `.env.example` files for complete list and format.

### 3. Database Setup

Generate Prisma client and run migrations:

```bash
npm run db:generate
npm run db:migrate
```

### 4. Start Development

Start both apps (web + admin) concurrently:

```bash
npm run dev
```

Or run individual apps:

```bash
npm run dev -w web      # Student app only (http://localhost:3000)
npm run dev -w admin    # Admin panel only (http://localhost:3001)
```

## 📦 Workspace Packages

### `@repo/auth`

Shared Clerk authentication configuration and utilities. Provides pre-configured middleware, components, and helpers.

**Import examples:**

```ts
import { ClerkProvider, SignInButton, auth } from "@repo/auth";
import { authMiddleware } from "@repo/auth/middleware";
```

### `@repo/config`

Shared Tailwind CSS and PostCSS configuration for consistent styling across apps.

**Import examples:**

```ts
import sharedConfig from "@repo/config/tailwind";
import postcssConfig from "@repo/config/postcss";
```

### `@repo/db`

Prisma schema, migrations, and type-safe database client.

**Import examples:**

```ts
import { prisma, User, Course } from "@repo/db";
```

### `@repo/types`

Shared TypeScript interfaces and types for API responses, entities, and common patterns.

**Import examples:**

```ts
import type { ApiResponse, User, Course } from "@repo/types";
import type { PaginatedResponse } from "@repo/types/common";
```

### `@repo/ui`

Reusable React components built with Radix UI and Tailwind CSS (shadcn/ui).

**Import examples:**

```ts
import { Button, Card, Input, Label } from "@repo/ui";
import { Badge, Skeleton } from "@repo/ui";
```

## 🛠️ Common Commands

```bash
# Development
npm run dev                  # Start all apps in dev mode
npm run dev -w web          # Start only web app
npm run dev -w admin        # Start only admin app

# Building
npm run build               # Build all apps
npm run build --filter=web  # Build only web app

# Code Quality
npm run lint                # Lint all workspaces
npm run check-types         # TypeScript type checking
npm run format              # Format code with Prettier

# Database
npm run db:generate         # Generate Prisma client
npm run db:migrate          # Run migrations (development)
npm run db:deploy           # Deploy migrations (production)
```

## 🎯 Key Features

### Adaptive Learning Paths

- **Entry Quiz** - Automatic placement into Basic or Advanced tracks based on quiz score
- **Dual-Track Content** - Separate learning paths for different skill levels
- **Progress Tracking** - Real-time completion tracking per lesson/module

### AI-Powered Features

- **AI Tutor** - Context-aware chat assistant powered by Gemini


### Assessment System

- **Multiple Question Types** - MCQ, text, code, file upload
- **Auto-grading** - Instant feedback for multiple-choice questions
- **Manual Review** - Admin interface for reviewing open-ended submissions
- **Certificates** - Auto-generated PDF certificates on completion

### Admin Panel

- **Content Management** - WYSIWYG editors for courses, modules, lessons
- **Drag-and-Drop** - Reorder modules and lessons easily
- **Quiz Builder** - Create entry quizzes and final assessments
- **User Management** - Track enrollments, progress, and performance

## 📚 Documentation

- [AGENTS.md](./AGENTS.md) - Coding guidelines and architecture for AI agents
- [Capstone Project Proposal](./Capstone%20Project%20-%20Cost%20Proposal.md) - Project requirements

## 🧪 Tech Stack Details

| Category      | Technology           | Version |
| ------------- | -------------------- | ------- |
| Framework     | Next.js              | 16.1.0  |
| Language      | TypeScript           | 5.9.2   |
| React         | React                | 19.2.0  |
| Database      | PostgreSQL + Prisma  | Latest  |
| Auth          | Clerk                | Latest  |
| Styling       | Tailwind CSS         | 3.4+    |
| UI Components | Radix UI (shadcn/ui) | Latest  |
| AI            | Google Gemini API    | Latest  |
| Monorepo      | Turborepo            | 2.8.3   |

## 🔧 Troubleshooting

### Database Connection Issues

- Verify `DATABASE_URL` is correct in all `.env` files
- Ensure PostgreSQL is running and accessible
- Check firewall rules if using remote database

### TypeScript Errors After Pulling

```bash
npm install                  # Reinstall dependencies
npm run db:generate         # Regenerate Prisma client
npm run check-types         # Verify types are correct
```

### Build Failures

- Clear Turbo cache: `rm -rf .turbo`
- Clear Next.js cache: `rm -rf apps/web/.next apps/admin/.next`
- Reinstall: `rm -rf node_modules && npm install`

### Port Already in Use

Change ports in package.json:

- Web app: `apps/web/package.json` → `"dev": "next dev --port 3002"`
- Admin app: `apps/admin/package.json` → `"dev": "next dev --port 3003"`

## 📄 License

This is a capstone project for educational purposes.

## 🤝 Contributing

This is a college capstone project. Contributions are welcome after the project is completed.
